<?php





$fb = array('app_id' => 358510268151781,'app_secret' => '43f95c7db156e4a05bd11f1d9da3a218','page_access_token' => 'EAAFGEC0udZBUBACzZAGGm0N88j8EhzASzX2HX5RhPIIURShtQBgQZAv07SvbRg7REb4Sx9HPtwMcf88prAaXlSLyCxbJX75Tzi6EZApBrIdBhqDvwcByNPwsMe1FfPzWgUFN279ds7v92iNfQDdGPICZAOm4MeRrnGxWC0oJf9PAK2qYWH7aC9jzQNM0SmT47BhSBzNLqYgZDZD','page_id' => 109837207017592);







?>