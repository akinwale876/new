<?php

session_start();





?>
<!DOCTYPE html>

<html lang="en-US" prefix="og: http://ogp.me/ns#" class="no-js"> 
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php 


require 'postdata.php';


if(!isset($_COOKIE[$comment_id])){
    
    
    
    $cookie_name = $comment_id;
    

if(setcookie($cookie_name,$title,time() + (8600 * 30) , "/")){
    
}


if($conn->query("UPDATE posts SET `views` =`views` +1 WHERE id=$id")){
    
}

    
}





include 'head.php';


?>

 <title><?php echo $title;?> - Naija Ramz <?php echo $category;?></title>


<?php 


include 'cookie.php';


?>

		
<meta http-equiv="x-ua-compatible" content="IE=edge,chrome=1" />

<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="description" content="<?php echo $description;?>" />
<meta property="og:site_name" content="NaijaRamz Entertainment & learning tips" />
<meta property="og:url" content="<?php echo 'https://naijaramz.com/'. $cleanurl;?>" />
<meta property="og:title" content="<?php echo $title;?>"/>
<meta property="og:description" content="<?php echo $description;?>" />
<meta property="og:image" content="<?php echo str_replace('http','https',$image); ?>"/>
<meta property="og:type" content="article" />
<meta name="title" content="<?php echo $title;?>"/>
<meta name="medium" content="article" />
<!-- Indicate preferred brand name for Google to display -->




<style>
    
    
#table-list li {
    
    color:white;
    list-style:none;
}

    
    
    
    
    @import 'https://fonts.googleapis.com/css?family=Lato';

* {
	outline: none;
}

body {
	font-family: 'Lato';
}

</style>
</head>



<body>
<?php



include 'header.php';



?>

    <h6 style="display:inline-block;margin:3px;margin:15px;padding:15px;">
        
        <?php echo '<a style="" href="https://'. $_SERVER["SERVER_NAME"] .'"><i class="fa fa-home"></i></a>' .' / <a href="http://'. $_SERVER["SERVER_NAME"]. '/category/'.$category .'">' . $category .'</a> / ' . $cleanurl .'</span>';?></h6>



    <span style="font-size:12px;font-weight: 700;padding-top:4px;padding-bottom:4px;color:white;">
        
    <?php echo date("d-M-Y",$date);?> </span>
    
    
<b style="margin-left:45px;">Share this post</b>

         
         
         
         
<?php

include 'sharer2.php';

?>
   

<span onclick="addCom()" style="float:right;font-family:Lato;font-size:10px;margin-top:15px;margin-right:10px;cursor:pointer;">
    <i class="fa fa-comment"></i>Add Comment</span>



<div class="wrapper" style="box-shadow:0;">
    
<h1 class="post-h1"><?php echo ucfirst($title);?> </h1>

    <br>
<div id="table-content"><h5 id="table-header"><i class="fa fa-table"></i>Tables of content</h5>
    
    <ul  id="table-list">
        
        
        
    </ul>
    
    

</div>
<div class="main" style="margin-bottom:30px;position:relative;">
    
<?php

if(isset($_SESSION['access'])){
    
   echo '<a href="http://naijaramz.com/update_post.php?q='.$id.'" title="Edit post" style="position:absolute;top3px;right:3px;font-size:10px;">Edit</a>';  }
        
        ?>
<h6 style="margin-top:2px;color:black;display:inline-block;padding-top:2px;padding:6px;font-weight:bold;">
    Category :<span style="color:black;margin-left:3px;background:white;padding:2px;display:inline-block;">
    <?php echo $category;?></span></h6>
    
<a href="#comment"><h6 style="display:inline-block;padding-top:2px;padding:3px;"><i class="fa fa-comment"></i>
<span style="color:red;margin-left:3px;background:white;padding:4px;display:inline-block;">
    comments <?php 
$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$comment_id'");


$num_post_query = mysqli_num_rows($comment_post_query);

 echo $num_post_query;?></span></h6></a>
    
    
<h6 style="display:inline-block;padding-top:2px;padding:3px;"><i class="fa fa-eye"></i><span style="color:black;margin-left:3px;background:white;padding:4px;display:inline-block;">
    views <?php echo $views;?></span></h6>



    <?php  
    
    echo '<h6 style="font-size:12px;color:brown;margin-left:2px;color:black;display:inline-block;padding-top:2px;padding:6px;">by <span style="color:brown;"><a href="http://naijaramz.com/author/'.$author . '">'.$author . '</a></span></h6>';
    
    ?>
    



<center>
<div style="width:95%;color:rgb(100,100,100);padding: 6px;">




<img src="<?php echo str_replace('http','https', $image); ?>" alt="<?php echo $title;?>" width="99%" style="height:auto;"  />








</div>

</center>

<div >
    
    
<center style="margin-bottom:60px;color:rgb(80,80,100);color:black;font-weight:bold;">


<?php 
echo  $description;
?>


</center>
    
</div>


</p>

<div id="cont" class="cont" style="position:relative;">
    
    
    
<?php 
echo $content;
?>

</div>







<br>
<br>



<?php


include 'related_post.php';



?>






<div  style="position:relative;height:180px;">
    


<div class="prev-post" >
    
    
<?php

$idd = $id -1;



$post_queryn = mysqli_query($conn,"SELECT * FROM posts WHERE `id`=$idd ORDER BY id DESC LIMIT 1");

$fetch_data = mysqli_fetch_array($post_queryn);

$ntitle = $fetch_data['title'];
$ncategory = $fetch_data['category'];
$ndescription= substr($fetch_data['description'],0,60);

$nimage = $fetch_data['picture_url'];

$ncleanurl = $fetch_data['cleanurl'];

$fdate = $fetch_data['date'];

$date = date('m:ha   l d-M-Y', $fdate);


echo   '
<h6 style="margin-bottom:8px;
padding:6px;width:90%;text-align:center;">&#10094;&#10094; Previous Post <span style="text-indent: 10px;"></span></h6>
<div style="background:white;margin-bottom:8px;box-shadow: 0px 0px 10px rgb(170,170,170);
padding:6px;width:90%;text-align:center;"><a style="text-decoration:none;" href="https://naijaramz.com/'. $ncleanurl .'">

<img src="'.str_replace('http','https',$nimage).'" width="98%" height="auto">

<h6>'.$ntitle .'</h6></a></div>';






?>


    
    
</div>



<br>



<div class="next-post" >
    
    
<?php

$idd = $id +1;



$post_queryn = mysqli_query($conn,"SELECT * FROM posts WHERE `id`=$idd ORDER BY id DESC LIMIT 1");

$fetch_data = mysqli_fetch_array($post_queryn);

$ntitle = $fetch_data['title'];
$ncategory = $fetch_data['category'];
$ndescription= substr($fetch_data['description'],0,60);

$nimage = $fetch_data['picture_url'];

$ncleanurl = $fetch_data['cleanurl'];

$fdate = $fetch_data['date'];

$date = date('m:ha   l d-M-Y', $fdate);


echo   '
<h6 style="margin-bottom:8px;
padding:6px;width:90%;text-align:center;">Next Post &#10095;&#10095;<span style="text-indent: 10px;"></span></h6>
<div style="background:white;margin-bottom:8px;box-shadow: 0px 0px 10px rgb(170,170,170);
padding:6px;width:90%;text-align:center;"><a style="text-decoration:none;" href="http://naijaramz.com/'. $ncleanurl .'">
<img src="'. str_replace('http','https',$nimage).'" width="98%" height="auto">

<h6>'.$ntitle .'</h6></a></div>';






?>


    
    
</div>


</div>


<br>

<br>


     <div style="margin-top:80px;">
         


<p>Share this post to any of the social media platform</p>

         
         
         
         
<?php

include 'sharer2.php';

?>
   
    
     </div>


<br>
<br>

<?php


include 'also_read.php';

include 'comment.php';



?>













</div>



<!--     ending of main-->

<?php




include 'sidebar.php';



?>



</div>
<br><br><br><br>

<?php




include 'footer.php';



?>

<style>



body{
    

    background:rgb(10,10,10);
    color:white;
}

center img{
    
    margin-top:20px;
}


p img{
    
    width:80%;
}



.wrapper{
    

    padding-left:1px;
    background:white;
    
}
    
    
    p{
     
    
    @import 'https://fonts.googleapis.com/css?family=Lato';


	font-family: 'Lato';

        color:rgb(40,40,30);
      font-size:17px;
      	margin:8px;
 
    }
    
    
    
    li{
        
        
	font-family: 'Lato';

        color:rgb(40,40,60);
      font-size:13px;
      
    margin-top:19px;
    }
    
    
    li p{
        
        
        
	font-family: 'Lato';

        color:rgb(40,40,30);
      font-size:14px;
      	margin:8px;
 
    }
    
    
    
    .cont h1,.cont h2,.cont h3,.cont h4{
        
             	font-family: 'Lato';
      font-size:20px;

        margin-top:60px;
    }
    
    
   .cont{
        width:97%;
        margin-left:auto;
        margin-right:auto;	margin:8px;
     
    }
   .cont p{
        
             	font-family: ;
             	font-size:19px;
             	margin:10px;
font-family: Arial;
    line-height: 40px;
    font-weight: normal;
     
    }
    
   .cont{
        
             background:white;
     
    }
    
    
    
    

    
    
    #table-content li{
        
        color:black;
    }
    
    
    h1,h2,h3,h4,h5,h6{
        
        margin:8px;
    }
    
    
    .main{
        
        background:white;
    }
    
    
    p{
    line-height: 32px;
    font-size: 25px;
    color: #3b4246;
    
        text-rendering: optimizeLegibility;
        font-family:ProximaNova-Regular;
        
    }

</style>



<script>







    
    var pelem = document.getElementById('cont');
    
    
    var elem = pelem.getElementsByTagName('H2');
    
    
    var ulElem = document.getElementById('table-list');
    
    
    
    if(elem.length < 1){
        
        document.getElementById('table-header').style.display ='none';
    }
    
    
    for(var i = 0;i < elem.length;i++){
        
        
        var yy = '<li style="color:black;">'+elem[i].innerHTML + '</li>';
        
          ulElem.innerHTML += yy;
          
          if(i > 3){
              break;
          }
    }
    
    
    
</script>



<script>
    
    function addCom(){
        
        var x = document.getElementById('comment');
        
        
        
        x.focus();
        
        
    }
    
    
</script>


</body>

</html>