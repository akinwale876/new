<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Music Video <?php
if(isset($_GET['page'])){
    
   echo ' Page ' . $_GET['page'];
    
}



?>- Naija Ramz Video</title>


<?php

include  $_SERVER['DOCUMENT_ROOT'] . "/head.php";

?>


<meta name="description" content="watch latest music videos " />

<link rel="canonical" href="https://naijaramz.com/MusicVideo.php" />
    

<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Music Video - Watch latest music videos" />
<meta property="og:description" content=" Watch latest music videos " />
<meta property="og:url" content="http://naijaramz.com/MusicVideo.php" />





</head>

<body>

<?php

include $_SERVER['DOCUMENT_ROOT'] . "/header.php";

?>

<div class="wrapper">
<h2>Category: Music Video</h2>


<div class="main" style="background:white;color:black;">
<?php


require $_SERVER['DOCUMENT_ROOT'] . '/connection.php';


$p = 0;


if(isset($_GET['page'])){
    
   $p =  $_GET['page'] * 16;
    
}



$list_post_query = mysqli_query($conn,"SELECT * FROM movies WHERE category= 'Music Video' ORDER BY id DESC LIMIT $p,18 ");

$f_post_query = mysqli_query($conn,"SELECT * FROM movies WHERE category= 'Music Video' ORDER BY id DESC LIMIT 1 ");

$mov1 = mysqli_fetch_array($f_post_query);

$f = $mov1['video_id'];



echo '<center><iframe width="95%" height="300"
src="https://www.youtube.com/embed/'.$f.'">
</iframe></center>';



while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];
$list_cleanurl = $mov['cleanurl'];
$list_image = $mov['picture_url'];
$list_discription = $mov['short_story'];
$list_video_id = $mov['video_id'];
$list_category = $mov['category'];
$list_date = date('l  d-M-Y',$mov['date']);





/*echo   '<a style="text-decoration:none;"  href="https://'.$_SERVER["SERVER_NAME"] .'/movie/'.$list_cleanurl.'">
<p style="font-size:14px;">Download: '.preg_replace("/[^:a-zA-Z0-9\-|]/",' ',ucfirst($list_title)) .'</p></a>';*/



echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/Music_Video/'.$list_cleanurl.'">
<div class="post" style="position:relative;">


<img alt="'. preg_replace("/[^:a-zA-Z0-9\-|]/",' ',$list_title).'" class="img" src="'.str_replace('http','https',$list_image).'">


<div class="post-title">
<h4 style="margin-bottom:8px;">Watch: '.preg_replace("/[^:a-zA-Z0-9\-|]/",' ',ucfirst($list_title)).'</h4>

<small style="color:rgb(190,190,190);"><em><span style="color:rgb(140,140,100);font-size:9px;"><i class="fa fa-clock">'. $list_date .'</i></span></em> <span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span></small>

</div>

    
    
</div></a>';



}











?>


</h2>

</div>


















<?php

include $_SERVER['DOCUMENT_ROOT'] . "/sidebar.php";

?>

</div>


<?php

include  $_SERVER['DOCUMENT_ROOT'] . "/footer.php";

?>


</body>

</html>