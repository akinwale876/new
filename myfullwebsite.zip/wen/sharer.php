<div style="margin-left:6px;display:inline-block;">
    
    
<a style="font-size:11px;display:inline-block;color:#3b5998;line-height:5px;text-decoration:none;" 
target="blank" href="https://www.facebook.com/sharer/sharer.php?u=https://<?php echo $_SERVER['HTTP_HOST'] .  $_SERVER['REQUEST_URI']?>&t=<?php echo $title;?>">
    <img src="https://naijaramz.com/icons/fbb.png" height="20px" />

    </a>
    
    
<a style="font-size:11px;display:inline-block;line-height:5px;text-decoration:none;" 

target="blank" href="https://www.twitter.com/sharer/sharer.php?u=<?php echo 'https://'. $_SERVER["SERVER_NAME"] .'/video/' . $cleanurl;?>&t=<?php echo $title;?>">
    
    <img  src="https://naijaramz.com/icons/twitt.png 
" style="border-radius:50%;" height="20px" />
</a>




<a style="font-size:11px;display:inline-block;line-height:5px;text-decoration:none;"

target="blank" style="margin-left:5px;" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo 'https://'. $_SERVER["SERVER_NAME"] .'/video/' . $cleanurl;?>&t=<?php echo $title;?>">
    
    <img src="https://naijaramz.com/icons/insta.png


" height="20px"  /></a>

</div>