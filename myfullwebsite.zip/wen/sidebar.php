<div class="sidebar">

	<script type="text/javascript" src="https://naijaramz.com/jquery.js"></script>
<br>

<center><a target="blank"  style="color:black;font-weight:bold;" href="https://naijaramz.com/contact"><i class="fa fa-phone-alt"></i>Contact Us</a>
</center>
<br><br>



<h2 ><i class="fa fa-search"></i><span style="text-indent: 10px;">Search For Post</span>
    </h2>

<center>
<div class="search-container" style="position: relative;border:none;">

<span class="search-sit" style="position:absolute;top:-20px;padding:2px;display:inline-block;left:10px;font-size:11px;" id="disError"></span>

<form action="https://naijaramz.com/search_server.php" method="get" onsubmit="return searchPost()">
    
 
<input type="text" id="inp" name="q" placeholder="Search here....."  style="font-size:10px;background:none;border:1px solid rgb(200,200,200);outline:none;width:55%;" />
<button type="submit"   style="cursor:pointer;border:none;outline:none;width:16%;font-size:13px;background: rgb(40,40,40);color:white;padding: 4px;"><i class="fa fa-search"></i></button>


    
</form>
</div>
</center>
    <script type="text/javascript">
      
      function _(el){

        return document.getElementById(el);
      }



         function searchPost(){


          var input = _('inp').value;
          var error = _('disError');

          if(input == ''){

error.style.color = 'red'
error.innerHTML  = 'pls enter something in this field';
           return false;
          }

         }



    </script>

  
</center>

<br>

<style>
    
    
</style>
  
       <br>
  <h2>Top music video</h2>
       
       <br>
       <?php
       
       
       $music_query = mysqli_query($conn,"SELECT * FROM movies WHERE category='Music Video'  ORDER BY id DESC LIMIT 4");
$dat = mysqli_fetch_array($music_query);
       
    $vid_id = $dat['video_id'];
   
      echo ' <iframe width="96%" height="115px"
src="https://www.youtube.com/embed/'.$vid_id.'">
</iframe> <br><br>  <div style="background:black;color:white;padding:5px;font-family:monospace;text-align:center;min-height:200px;">
';

while($da = mysqli_fetch_array($music_query)){
    


$title = $da['title'];
$cleanurl = $da['cleanurl'];
$pic = $da['picture_url'];

echo '<div><img src="'.str_replace('http','https', $pic).'" style="width:55%;height:100px;" /><a style="color:white;" href="https://naijaramz.com/Music_Video/'.$cleanurl.'"><h5>'.$title.'</h5></a></div>';


}
       ?>
       
       
   </div>


<br>

<nav>
<h2> Categories</h2>   
    
       <ul id="sas" style="margin:0;padding:0;">
             
    




       
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/forum.php" title="Ask question" >
        
          <i class="fab fa-forumbee"></i> <span style="margin-left:5px;">
            
        Forum</span></a>

        </li>

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Music" title="latest naija gist" ><i class="fas fa-headphones"></i>
        
        <span style="margin-left:5px;">
            
        Music</span></a>

        </li>
   

   
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/MusicVideo.php" title="latest naija music video" ><i class="fas fa-video"></i>
        
           
        <span style="margin-left:5px;">
            
        Music Video</span>
        </a>

        </li>
   

   


    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Entertainment"
        style="position:relative;" title="updates on latest entertaintaining gist" ><i class="far fa-grin-squint-tears"></i>
        
        
       
        <span style="margin-left:5px;">
            
        Entertainment</span>   
        
        
    
        </a>

        </li>
        
        

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Sport" title="latest sport informations" ><i class="fas fa-volleyball-ball"></i>
        
        
        <span style="margin-left:5px;">
            
        Sport</span>   </a>

        </li>

        
        
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Telecommunication" 
        style="position:relative;"  >
            
            <i class="fas fa-tty"></i>
            
           
           
        <span style="margin-left:5px;">
            
         Telecommunication</span>
    
        </a>

        </li>
        <li>
    

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Food" style="position:relative;" 
        title="updates" >
            
            <i class="fas fa-utensils"></i>
         
        <span style="margin-left:5px;">
            
         Food</span>  
        
    
        </a>

        </li>




    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/movie.php" title="download latest yoruba movie " >
            
            
            <i class="fas fa-film"></i>
            
        <span style="margin-left:5px;">
            
         Nollywood Yoruba Movies</span>  
       </a>
</li>



    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Emovie.php" title="download latest english movie " >
                  
            <i class="fas fa-film"></i>
            
        <span style="margin-left:5px;">
            
       Nollywood English Movies</span>  
       </a>
</li>



    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/comedy.php"
        style="position:relative;" title="updates on latest comedy" ><i class="far fa-grin-squint-tears"></i>
        
        
       
        <span style="margin-left:5px;">
            
        Comedy Video</span>   
        
        
    
        </a>

        </li>

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Hmovie.php" title="download latest hollywood movie " >
         
            <i class="fas fa-film"></i>
            
        <span style="margin-left:5px;">
            
       Hollywood Movies</span> </a>
</li>





<br>





   
<h2>Recent Comments</h2>   
        

<?php


echo '<div class="comm">';

$comment_query = mysqli_query($conn,"SELECT * FROM comment  ORDER BY id DESC LIMIT 5");


while($datas = mysqli_fetch_array($comment_query)){
    


$comm_id = $datas['comment_id'];
$comm = $datas['comment'];
$name= substr($datas['name'],0,60);


$date = $datas['date'];


$check_query1 = mysqli_query($conn,"SELECT * FROM posts  WHERE comment_id = '$comm_id' ORDER BY id DESC LIMIT 1");
$check_query2 = mysqli_query($conn,"SELECT * FROM music  WHERE comment_id = '$comm_id' ORDER BY id DESC LIMIT 1");
$check_query3 = mysqli_query($conn,"SELECT * FROM movies  WHERE comment_id = '$comm_id' ORDER BY id DESC LIMIT 1");

$datase = mysqli_fetch_array($check_query1);
$datase2 = mysqli_fetch_array($check_query2);
$datase3 = mysqli_fetch_array($check_query2);

$tit = $datase['title'];
$ti_url = $datase['cleanurl'];
$cat = $datase['category'];

$tit2 = $datase2['title'];
$ti_url2 = $datase2['cleanurl'];


$tit3 = $datase3['title'];
$ti_url3 = $datase3['cleanurl'];



$date = date('l d-M-Y', $date);


echo   '<li><a style="text-decoration:none;" href="https://'.$_SERVER["SERVER_NAME"].'/' .$cat . '/'. $ti_url .'#comment">
<p ><small style="color:brown;">On:'. $date .'</small><br><br><b style="font-size:16px;"> '. ucfirst($name) .':</b><p style="font-size:16px;"> ' .$comm  .'</p> ' .'
<br>

'. $tit .'</p></a></li>';







}



echo '</div>';

?>







  <br/>  
  
  

  <br/>  
  
  
  





<br>
<br>
<br>




<br>
<br>


<br>
<br>
  <h2>Articles</h2>

       
       <?php
       
       
       $music_query = mysqli_query($conn,"SELECT * FROM posts WHERE category='articles'  ORDER BY id DESC LIMIT 6");

       
       

while($da = mysqli_fetch_array($music_query)){
    


$title = $da['title'];
$cleanurl = $da['cleanurl'];
$category = $da['category'];
$pic = $da['picture_url'];

echo '<li><a style="color:black;" href="https://naijaramz.com/'.$category.'/'.$cleanurl.'">'.$title.'</a></li>';


}
       ?>
       
       


<br>


       </ul>

<style>

* width */
body::-webkit-scrollbar {
  width: 10px;
}
iframe::-webkit-scrollbar {
  width: 10px;
}

/* Track */
body::-webkit-scrollbar-track {
  background: #f1f1f1;
}

/* Handle */
body::-webkit-scrollbar-thumb {
  background:green ;
    border-radius: 10px;

}

/* Handle on hover */
body::-webkit-scrollbar-thumb:hover {
  background: darkgreen;
}


body::-webkit-scrollbar {
  width:10px;
}

/* Track */
body::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey;
  border-radius: 10px;
}



    
  .twitterbar::-webkit-scrollbar {
  width: 8px;
}
    
</style>

  <br/>  
  

</nav>



<script>
    
    var mytags = document.getElementsByClassName('mytag');
    
    
    mytags[0].style.fontSize = "30px";
    mytags[4].style.fontSize = "30px";
    mytags[6].style.fontSize = "30px";
    mytags[10].style.fontSize = "30px";
    mytags[14].style.fontSize = "29px";
    mytags[16].style.fontSize = "30px";
    mytags[16].style.fontFamily = "segoe script";
    mytags[18].style.fontSize = "30px";
    mytags[22].style.fontSize = "27px";
    mytags[25].style.fontSize = "31px";
    mytags[25].style.fontFamily = "segoe script";
    mytags[29].style.fontSize = "29px";
    mytags[34].style.fontSize = "30px";
    mytags[41].style.fontSize = "20px";
    mytags[44].style.fontSize = "20px";
    mytags[47].style.fontSize = "30px";
    mytags[50].style.fontSize = "30px";
    mytags[51].style.fontSize = "30px";
    
    
    
    
    
</script>
  
  
  <style>
      
      
      .sidebar #sas li a{
          
          
          font-size:14px;
          margin:10px;
          line-height:24px;
          padding:10px;
          background:white;
          text-decoration:none;
          font-family:Montserrat;
          color:black;
          
          
          
      }
      
      .sidebar  #sas .comm li a{
          
          background:rgb(200,200,200);
          
          color:white;
          
          
      }
      .sidebar  #sas .comm li a:hover{
          
          background:white;
          
          color:black;
          
          
      }
      
      
      .sidebar #sas li a:hover{
          
          
        
          background:rgb(200,200,200);
          
          color:white;
          
          
      }
      
      
  </style>

</div>

</div
