
    <nav style="box-shadow: none;outline: none;" ><ul class="ul-list" id="nn">


    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>" title="updates and latest post" style="position:relative;text-indent:10px;">Home

        </a>

        </li>
        
        
    <li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/News" title="latest news informations" >Latest News</a>

        
    </li>
 <li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Business" title="business" >Business</a>

        
    </li>
        
        
 <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/articles.php" >Articles</a>

        </li>

        
 <li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Sport" title="latest sport informations" > Sports</a>

        </li>



      


    <li class="dropdown" style="position:relative;color:rgb(20,120,50);">
Entertainment &#9774;
        
        
       <span class="sit" id="dropdown-content">
  
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Music" style="display: block;">Music & Lyrics</a>
       

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Nollywood" style="display: block;">Nollywood Movie</a>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Entertainment" style="display: block;">Celebrity Gist</a>
      

     </span>
        
  

        </li>



       


 <li  class="dropdown" style="position:relative;color:rgb(20,120,50);">
        Fashion & styles



       <span class="sit" id="dropdown-content">
  
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Fashion#new arrival" style="display: block;">New arrival</a>
       

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Fashion#man wear" style="display: block;">Man Wear</a>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Fashion#woman wear" style="display: block;">woman wear</a>
      

     </span>
        
        </li>


    <li  class="dropdown" style="position:relative;color:rgb(20,120,50);">Education (learning tips)





       <span class="sit" id="dropdown-content">
  
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Technology" style="display: block;">Technology</a>
       

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Telecommunication" style="display: block;">Telecommunication</a>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Finance" style="display: block;">Finance</a>
      

     </span>
        
        </li>




    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/SportPrediction">
       Lifestyle</a>
</li>
   

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/forum.php" style="position:relative;" title="Ask question" >Talk Forum
        
        <span
      style="position:absolute;top:-8px;padding:2px;display:inline-block;left:21px;color:rgb(40,40,40);font-size:8px;"><i class="fa fa-users"></i></span>
        
        
        </a>

        </li>
        



    <li >

        <a id="menu" class="menu" href="javascript:void(0);">
       &#9776;</a>
</li>
   



    </ul>


<script type="text/javascript">
	


$(document).ready(function(){


var ul = $('#nn');


$('#menu').click(function(){




		   ul.css('height', 'auto')


})


})


</script>