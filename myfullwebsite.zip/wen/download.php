<?php


$title = $_GET['title'];


$url = $_GET['url'];



$content = file_get_content($url);

// It will be called downloaded.pdf
header("Content-Disposition:attachment;filename=title.mp4");


echo $content;

?>