<!DOCtype
 html>
 
 
 
 
 
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Welcome To My Profile - NaijaRamz Co-founder</title>
<meta name="discription"
content="" />


<?php

include "head.php";

?>


</head>


<body>
      
      <?php 
      
      include 'header.php';
      
      ?>
    
<div class="wrapper" >
<center>
    <h2>Welcome To My Profile </h2>
    
    <img src="http://naijaramz.com/profile/70955959_140429460543448_6318742434037628928_o.jpg" height="210px">


      <center> 

</center>
    
 <h3>Your current Ip: <i><?php echo $_SERVER['REMOTE_ADDR'];?></i></h3>





</center>






        
        <div class="section" style="background-image:url('http://naijaramz.com/profile/about-me-page-featured-image.jpg');background-size:cover;">
            
                  
        
       
    <b><h1>About me</h1></b>
    <br>

     <p class="p" style="font-size:21px;color:white;">
Hi there! My name is Akinwale shuaib Mayowa . Welcome to my profile page.

</p>

                  
                  
                  
        </div>
        
        
    
        
        
        
        
        
        <div class="section" style="background-image:url('http://naijaramz.com/profile/foundmyp.jpg');background-size:cover;">
            
               
<h1><b>My passion</b></h1>

 
<p  class="p" style="font-size:20px;color:white">
    
    i don't need an alarm clock to wake me up, my passion wake me


</p>


                  
        </div>
        
        <div class="section" style="background-image:url('http://naijaramz.com/profile/Why-Does-My-Vision-Get-Worse-at-Night-300x200.jpg');background-size:cover;">
            
               
<h1><b>My Vision</b></h1>

 
<p  class="p" style="font-size:20px;color:white">
    My personal vision is to have a life of meaning for myself and others. It is important to me to live my life in a way that shows kindness, care, and concern for family and friends and even strangers

</p>


                  
        </div>
        
        
        <div class="section" style="background-image:url('http://naijaramz.com/profile/16x9 Large.jpg');background-size:cover;">
            
               
<h1><b>My Carreer</b></h1>

 
<p  class="p" style="font-size:20px;color:white">
    
    Php web technologies

</p>


                  
        </div>
        
        
        
        

</div>


<?php

include "footer.php";

?>


<style>

body{
    
    background:black;
    
    color:rgb(200,220,220);
}
    
    
    .input-container{
        
        box-shadow:0px 8px 8px 0px rgb(200,200,200);
    }
    
    
</style>


<style>


p img{
    
    width:80%;
}



.wrapper{
    

    padding-left:1px;
    
}
    
    
    .p{
                margin-top:3px;
     font-family:monospace;
        
        
    }
    
    
    h1{
        
        text-indent:15px;
        
        @import url(//db.onlinewebfonts.com/c/2cb3e62148b528138a35061500162dee?family=Nasalization);
        
        
       text-shadow:0px 2px 3px gray;
       font-family:nasalization;
        @font-face {font-family: "Nasalization"; src: url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.eot"); src: url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.eot?#iefix") format("embedded-opentype"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.woff2") format("woff2"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.woff") format("woff"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.ttf") format("truetype"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.svg#Nasalization") format("svg"); }
]
    }
    
    
    
    
    .section{
        
        width:210px;
        
        display:inline-block;
       margin:9px;
        padding-top:9px; padding-bottom:9px;
        height:250px;
        overflow:hidden;
        box-shadow:0px 10px 10px 0px rgb(200,200,200);
        
    }
    
    
    
    
@media screen and (max-width:980px){
    
    
    
    .section{
        
        width:95%;
        
        display:inline-block;
       margin:9px;
        padding-top:9px; padding-bottom:9px;
        min-height:200px;
        overflow:hidden;
        box-shadow:0px 10px 10px 0px rgb(200,200,200);
        
    }
    
    
}
    
</style>

</body>

</html>