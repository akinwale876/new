<!DOCtype
 html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Home - NaijaRamz | The site you can trust for music and videos</title>

<?php

require 'start.php';

include "head.php";

?>


<meta name="description" content="Naijaramz provides web users with Latest Entertainment News in Nigeria, Latest Nigerian Music, Nollywood Movies, Comedy Videos and Hollywood movies" />

<meta http-equiv="x-ua-compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no " />
<link rel="canonical" href="https://naijaramz.com"  />


<meta property="og:site_name" content="Naija Ramz" />
<meta property="og:url" content="https://Naijaramz.com" />
<meta property="og:title" content="The site you can trust for music and videos" />

<meta property="og:description" content="Naijaramz provides web users with Latest Entertainment News in Nigeria, Latest Nigerian Music, Nollywood Movies, Comedy Videos and Hollywood movies" />
<meta property="og:image" content="https://naijaramz.com/14763d33-d8f5-4a53-b4f8-10263d9de8b3_200x200.jpg"/>
<meta property="og:image:width" content="500" />
<meta property="og:image:height" content="500" />
<meta property="og:type" content="website" />

</head>


<body>


<?php

include "header.php";

?>

<div class="wrapper" >


<?php

include  root .'/app/models/init.php';


?>

<?php

include "sidebar.php";

?>

</div>


<?php

include "footer.php";

?>


<style>
    h5{
        
        margin-left:10px;
    }
    
    hr{
        
        border:none;
    }
    
    
    
</style>


<script>
    
    
    var xxx = document.getElementsByClassName('dateM');
    
    
    for(var = 0;i < xxx.length;i++){
        
  var countDownDate = xxx[i];
  
    
    // Set the date we're counting down to

// Update the count down every 1 second

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  xxx[i].innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";

 
      
        
    }
 
    
    
</script>




</body>

</html>