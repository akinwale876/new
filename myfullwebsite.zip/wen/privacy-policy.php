<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Privacy Policy - NaijaRamz</title>



<?php

include "head.php";

?>


</head>


<body>

<?php

include "header.php";

?>

<div class="wrapper">
    
<h1>Our Policy</h1>

<div class="main">




        <br> <br>
        
       
        
        
        <div class="section">
            
                  
        
       
    <b><h1>Your Privacy</h1></b>
    <br>

    
    <p class="p" style="font-size:16px;color:rgb(100,70,50);">
        


A privacy policy is a notice or a documents in which the data owner outlines the methods
and purpose of data collected, stored and processed to user's.
Whereas at Naijaramz, all the personal data collected, we inform the user's of the facts puts in stored. 

</p>
    
    <p class="p" style="font-size:16px;color:rgb(100,70,50);">
        


We take your privacy as our top priority. This policy describes what personal information we collect and
how we use it on Naijaramz [Naijaramz.com]
Routine Information Collection, All web servers track vital information about their
visitors. This information includes, but is not limited
to, IP addresses, browser details, and referring pages. 

</p>

    
    <p class="p" style="font-size:16px;color:rgb(100,70,50);">
        

None of this information can
personally identify specific visitors to this site. The information is tracked for routine administration and
maintenance purposes, and informs us what pages and information are useful and helpful to users.


</p>

                  
                  
                  
        </div>
        
        
        
        
        
        
        
        
        
        
        
        <div class="section">
            
               
<h1><b>Cookie Policy</b></h1>
    <br>
 
<p  class="p" style="font-size:16px;color:rgb(100,70,50);">

A cookie policy is a detailed guideline that tells a user how cokies are used,
the types of cookies are in place and how the user can prevent or control cookies placed on their browser

</p>

<p  class="p" style="font-size:16px;color:rgb(100,70,50);">

Where necessary, at Naijaramz we use cookies to store
information about a visitor’s preferences and history in
order to provide the best of our services to a user/or to deliver the
visitor with customized content informations.

</p>
<p  class="p" style="font-size:16px;color:rgb(100,70,50);">

Cookies are meant to enhance a user's web experiences, sometimes cookies collect information
across different sites. The data collected is then used to create behavioural profiles which are used
to determine what adverts or contents the user views.

</p>


<p  class="p" style="font-size:16px;color:rgb(100,70,50);">


A banner pop-ups is being used as a cookie. Advertising partners and other third parties also uses cookies, scripts
and/or web beacons to track visitors to our site in order to display advertisements and other important information.
Such tracking is done directly by the third parties through their own servers and privacy policies.


</p>


                  
        </div>
        
        
       
        <div class="section">
            
        
        
        
<h1>Cookies and Web Beacons</h1>

<p class="p" style="font-size:16px;color:rgb(100,70,50);">

Where necessary, this site uses cookies to store
information about a visitor’s preferences and history in
order to better serve the visitor and/or present the
visitor with customized content. Advertising partners
and other third parties may also use cookies, scripts
and/or web beacons to track visitors to our site in order
to display advertisements and other useful
information. Such tracking is done directly by the third
parties through their own servers and is subject to their
own privacy policies.

<h1>Controlling Your Privacy</h1>

<p class="p" style="font-size:16px;color:rgb(100,70,50);">

Note that you can change your browser settings to
disable cookies if you have privacy concerns. Disabling
cookies for all sites is not recommended as it may
interfere with your use of some sites. The best option is
to disable or enable cookies on a per-site basis. Consult
your browser documentation for instructions on how to
block cookies and other tracking mechanisms.
</p>

<h1>Special Note About Google Advertising</h1>
    
<p class="p" style="font-size:16px;color:rgb(100,70,50);">

Any advertisements served by Google, Inc., and
affiliated companies may be controlled using cookies.
These cookies allow Google to display ads based on
your visits to this site and other sites that use Google
advertising services. Learn how to opt out of Google’s
cookie usage. As mentioned above, any tracking done
by Google through cookies and other mechanisms is
subject to Google’s own privacy policies.
</p>
<p class="p" style="font-size:16px;color:rgb(100,70,50);">

About Google advertising: What is the Double Click
DART cookie? The Double Click DART cookie is used
by Google in the ads served on publisher websites
displaying AdSense for content ads. When users visit
an AdSense publisher’s website and either view or click
on an ad, a cookie may be dropped on that end user’s
browser. The data gathered from these cookies will be
used to help AdSense publishers better serve and
manage the ads on their site(s) and across the web.
</p>

<p class="p" style="font-size:16px;color:rgb(100,70,50);">

Users may opt out of the use of the DART cookie by visiting the Google ad and content network privacy policy.
</p>
<h1>Contact Information</h1>
<p class="p" style="font-size:16px;color:rgb(100,70,50);">

Concerns or questions about this privacy policy can be directed to admin at AMonpointV.com for further clarification.
</p>
<p class="p" style="font-size:16px;color:rgb(100,70,50);">

1) A word filter has been put in place to prevent forum
members from using $€Xually explicit words in their
posts.
</p>

<p class="p" style="font-size:16px;color:rgb(100,70,50);">

2) Our Members have been informed that they need to
keep their words clean if the Website is to survive.
</p>

<p class="p" style="font-size:16px;color:rgb(100,70,50);">

3) A privacy policy has been drafted for NaijaRamz.com.
See http://naijaramz.com/Privacy-Policy
I’m ready to do whatever may be additionally required
to make my site fully complaint with your policies.
  </p>      
                  
        </div>
         





</div>





<?php

include "sidebar.php";

?>

</div>


<?php

include "footer.php";

?>


<style>


p img{
    
    width:80%;
}



.wrapper{
    

    padding-left:1px;
    
}
    
    
    .p{
                margin-top:3px;
     font-family:monospace;
        
        
    }
    
    
    h1{
        
        text-indent:15px;
        
        @import url(//db.onlinewebfonts.com/c/2cb3e62148b528138a35061500162dee?family=Nasalization);
        
        
       text-shadow:0px 2px 3px gray;
       font-family:nasalization;
        @font-face {font-family: "Nasalization"; src: url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.eot"); src: url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.eot?#iefix") format("embedded-opentype"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.woff2") format("woff2"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.woff") format("woff"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.ttf") format("truetype"), url("//db.onlinewebfonts.com/t/2cb3e62148b528138a35061500162dee.svg#Nasalization") format("svg"); }
]
    }
    
    
    
    
    .section{
        
        
        margin-top:19px;
        margin-bottom:39px;
        padding-top:9px; padding-bottom:9px;
        min-height:300px;
        box-shadow:0px 10px 10px 0px rgb(220,230,230);
        
    }
    
    
</style>

</body>

</html>