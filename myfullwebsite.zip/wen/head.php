<?php
session_start();

?>

<script   src="https://naijaramz.com/jquery.js"></script>

<script type="text/javascript" async="" src="https://widget.intercom.io/widget/q22gd2x3"></script>

<script async="" src="//static.ads-twitter.com/uwt.js"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="indexSafe" src="/scripts/gtm/indexSafe.js"></script><script async="" src="https://static.hotjar.com/c/hotjar-1666385.js?sv=6"></script>
<link rel="stylesheet" href="https://static.cex.io/landings/css/Index.css?v=1.1.27
">

		
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="indexSafe" 
src="/scripts/gtm/indexSafe.js"></script><script async="" src="https://static.hotjar.com/c/hotjar-1666385.js?sv=6"></script>

<link rel="stylesheet" type="text/css" href="https://static.cex.io/bundles/css/custom-bundle-verification.css" media="all">



<script type="text/javascript" src="https://static.cex.io/bundles/scripts/customBundleWidget.js"></script>

<script async="" src="https://script.hotjar.com/modules.b95238168e0f39a591d4.js" charset="utf-8"></script>


<link rel="stylesheet" type="text/css" href="https://static.cex.io/bundles/css/custom-bundle-verification.css" media="all">

<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700|Roboto|Lato:400,900|Source+Sans+Pro:400,700|Montserrat:800" rel="stylesheet">


<style id="intercom-lightweight-app-style" type="text/css">
  @keyframes intercom-lightweight-app-launcher {
    from {
      opacity: 0;
      transform: scale(0.5);
    }
    to {
      opacity: 1;
      transform: scale(1);
    }
  }

  @keyframes intercom-lightweight-app-gradient {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  @keyframes intercom-lightweight-app-messenger {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .intercom-lightweight-app {
    position: fixed;
    z-index: 2147483001;
    width: 0;
    height: 0;
    font-family: intercom-font, "Helvetica Neue", "Apple Color Emoji", Helvetica, Arial, sans-serif;
  }

  .intercom-lightweight-app-gradient {
    position: fixed;
    z-index: 2147483002;
    width: 500px;
    height: 500px;
    bottom: 0;
    right: 0;
    pointer-events: none;
    background: radial-gradient(
      ellipse at bottom right,
      rgba(29, 39, 54, 0.16) 0%,
      rgba(29, 39, 54, 0) 72%);
    animation: intercom-lightweight-app-gradient 200ms ease-out;
  }

  .intercom-lightweight-app-launcher {
    position: fixed;
    z-index: 2147483003;
    bottom: 20px;
    right: 20px;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: #1BB6C1;
    cursor: pointer;
    box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.06), 0 2px 32px 0 rgba(0, 0, 0, 0.16);
    animation: intercom-lightweight-app-launcher 250ms ease;
  }

  .intercom-lightweight-app-launcher:focus {
    outline: none;
    
  }

  .intercom-lightweight-app-launcher-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: 0;
    left: 0;
    width: 60px;
    height: 60px;
    transition: transform 100ms linear, opacity 80ms linear;
  }

  .intercom-lightweight-app-launcher-icon-open {
    
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-open svg {
    width: 28px;
    height: 32px;
  }

  .intercom-lightweight-app-launcher-icon-open svg path {
    fill: rgb(255, 255, 255);
  }

  .intercom-lightweight-app-launcher-icon-self-serve {
    
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-self-serve svg {
    height: 56px;
  }

  .intercom-lightweight-app-launcher-icon-self-serve svg path {
    fill: rgb(255, 255, 255);
  }

  .intercom-lightweight-app-launcher-custom-icon-open {
    max-height: 36px;
    max-width: 36px;
    
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-minimize {
    
        opacity: 0;
        transform: rotate(-60deg) scale(0);
      
  }

  .intercom-lightweight-app-launcher-icon-minimize svg {
    width: 16px;
  }

  .intercom-lightweight-app-launcher-icon-minimize svg path {
    fill: rgb(255, 255, 255);
  }

  .intercom-lightweight-app-messenger {
    position: fixed;
    z-index: 2147483003;
    overflow: hidden;
    background-color: white;
    animation: intercom-lightweight-app-messenger 250ms ease-out;
    
        width: 376px;
        height: calc(100% - 120px);
        max-height: 704px;
        min-height: 250px;
        right: 20px;
        bottom: 100px;
        box-shadow: 0 5px 40px rgba(0,0,0,0.16);
        border-radius: 8px;
      
  }

  .intercom-lightweight-app-messenger-header {
    height: 75px;
    background: linear-gradient(
      135deg,
      rgb(27, 182, 193) 0%,
      rgb(14, 98, 103) 100%
    );
  }

  @media print {
    .intercom-lightweight-app {
      display: none;
    }
  }
</style>



<meta name="google-site-verification" content="X5XY3uz3nHWPx8LRUfpFI7ir1rc7lACRIzLzfoBjIUg" />

<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=yes">


<!--.........................google adsense......................-->


<script data-ad-client="ca-pub-5191872750204085" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<!--.........................google adsense......................-->


<link rel="stylesheet" href="https://naijaramz.com/nssssnsstyle.css" />
<link rel="stylesheet" href="https://naijaramz.com/ssstylemobile.css"/>





<link href="//db.onlinewebfonts.com/c/2cb3e62148b528138a35061500162dee?family=Nasalization" rel="stylesheet" type="text/css"/>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156981103-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-156981103-1');
</script>



<script data-ad-client="ca-pub-6279727015121725" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>


 <link rel="icon"  type="images/x-icon" href="https://naijaramz.com/14763d33-d8f5-4a53-b4f8-10263d9de8b3_200x200.jpg">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
