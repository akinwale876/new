<!DOCtype
 html>
 
 <?php
 
 if(isset($_GET['url'])){
     
     $url = $_GET['url'];
 }
 else{
     exit;
    
 }
 ?>
 
 
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title> Category <?php echo $url; ?> - Naijaramz  </title>

<?php

include "head.php";

?>


<link rel="canonical" href="https://naijaramz.com/<?php echo $url?>" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
</head>


<body>

<?php

include "header.php";

?>

<div class="wrapper">
<h2>Latest <?php echo $url?>  news</h2>

<div class="main">
<?php


require 'connection.php';



$list_post_query = mysqli_query($conn,"SELECT * FROM posts WHERE category='$url' ORDER BY id DESC LIMIT 10 ");


if(mysqli_num_rows($list_post_query) > 0){



}




while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];
$list_cleanurl = $mov['cleanurl'];
$list_image = $mov['picture_url'];
$list_discription = $mov['description'];
$list_category = $mov['category'];
$list_date = date('l m:ha d-M-Y',$mov['date']);

$likes = $mov['likes'];




echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/'.$list_category.'/'.$list_cleanurl.'">

<div class="list-post" style="position:relative;">
<img alt="'.$list_title.'" class="list-img" src="'.$list_image.'">

<div class="list-post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($list_title).'</h4>


</div>


    
</div></a>';



}







if(isset($_GET['page'])){
    
echo '<h2>Sport - ';

   echo 'Page ' . $_GET['page'];
    
}


echo '</h2>';



?>

</div>

<?php

include "sidebar.php";

?>

</div>


<?php

include "footer.php";

?>

</body>

</html>