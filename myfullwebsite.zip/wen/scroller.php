
<!--<div class="scrolling" style="position:fixed;top:-8px;left:0;width:100%;" id="inner">
    
    <span id="control" style="background:rgb(200,20,0);display:inline-block;padding:1px;"></span>
    
    
    
</div>-->

   <script>
       
          
       
          
          
       window.onscroll = function(){
              
              document.getElementById('control').style.width = (document.documentElement.scrollTop / 3.7 ) + "px";
             
              
              
              var html = document.documentElement;
              if(html.offsetHeight > 1000){
                  
                                document.getElementById('follow').style.position= "fixed";

              }else{
                                                  document.getElementById('follow').style.position= "absolute";

              }
              
              
              
                            if(html.offsetHeight > 1000){
                                

}


              
              
          }
          
       
       
   </script>
