



<?php


include 'connection.php';






$sql = "DELETE FROM posts
WHERE category ='Sport' AND id !=287";



if(mysqli_query($conn,$sql)){
    
    echo 'deleted';
}

?>