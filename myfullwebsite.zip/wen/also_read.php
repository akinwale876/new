
<?php





$aelate_post_query = mysqli_query($conn,"SELECT * FROM posts WHERE category !='$category' AND id !='$id' ORDER BY id DESC LIMIT 3 ");




if(mysqli_num_rows($aelate_post_query) > 0){

}


if(mysqli_num_rows($aelate_post_query) > 0){
echo '<h4 style="font-family:Lato;">More post</h4><hr>' ;


}




while($movo = mysqli_fetch_array($aelate_post_query)){

$rlist_title = $movo['title'];
$rlist_cleanurl = $movo['cleanurl'];
$rlist_cate = $movo['category'];
$rlist_image = $movo['picture_url'];
$rlist_date = date('l  d-M-Y',$movo['date']);





echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/'.$rlist_cate.'/'.$rlist_cleanurl.'">

<div class="list-post" style="position:relative;">

<img alt="'.$list_title.'" class="list-img" src="'.str_replace('http','https',$rlist_image).'">

<div class="list-post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($rlist_title).'</h4>

</div>


<span style="position:absolute;top:5px;left:2px;background-color:rgb(200,40,40);color:white;font-size:10px;padding:4px;">'.$rlist_cate.'</span>

    
</div></a>';



}

if(mysqli_num_rows($relate_post_query) > 0){


}


?>