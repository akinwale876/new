<!DOCtype

 html>

<html>





<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Soccer Prediction - Naija Ramz free sport predictions, live odds, forecast </title>





<?php



include "head.php";



?>





<meta name="description" content="Sports prediction" />

<link rel="canonical" href="https://naijaramz.com/sportprediction" />

<meta property="og:locale" content="en_US" />

<meta property="og:type" content="object" />

<meta property="og:title" content="Soccer Prediction &raquo; " />

<meta property="og:description" content="Sports prediction" />


</head>





<body >



<?php



include "header.php";



?>


<div class="wrapper" >


<div class="main" style="background:white;color:black;">

<?php





require 'connection.php';





$list_post_query = mysqli_query($conn,"SELECT * FROM predictions ORDER BY id DESC LIMIT 10 ");





if(mysqli_num_rows($list_post_query) > 0){






}else{


}









while($mov = mysqli_fetch_array($list_post_query)){



$list_team = $mov['team'];

$list_odd = $mov['odds'];

$list_option = $mov['options'];

$list_result = $mov['result'];


$list_date = date('l d-M-Y',$mov['date']);



$likes = $mov['likes'];







}


?>


<?php 
  
// From URL to get webpage contents. 
$url = "https://livescores.biz/live"; 
  
// Initialize a CURL session. 
$ch = curl_init();  
  
// Return Page contents. 
//grab URL and pass it to the variable. 
curl_setopt($ch, CURLOPT_URL, $url); 


curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, true); 
  
  
$result = curl_exec($ch); 
  
echo $result;  
  
?> 



</div>



<?php



include "sidebar.php";



?>



</div>





<?php



include "footer.php";



?>


<style>
    
    
    .main{
        
        box-shadow:none;
    }
    
    
</style>


</body>



</html>