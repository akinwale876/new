
<h6 style="margin-bottom:8px;box-shadow: 0px 0px 1px rgb(170,170,170);
padding:6px;width:90%;text-align:center;">Recent Post <span style="text-indent: 10px;">
    <i class="fa fa-book"></i></span></h6>

<?php



$post_query = mysqli_query($conn,"SELECT * FROM posts  ORDER BY id DESC LIMIT 2");


while($data = mysqli_fetch_array($post_query)){
    


$title = $data['title'];
$category = $data['category'];
$description= substr($data['description'],0,60);

$image = $data['picture_url'];

$cleanurl = $data['cleanurl'];

$date = $data['date'];

$date = date('m:ha   l d-M-Y', $date);


echo   '<div style="margin-bottom:8px;box-shadow: 0px 0px 10px rgb(170,170,170);
padding:6px;width:90%;text-align:center;"> <small>'.$category.'</small><a style="text-decoration:none;" href="http://www.smartgist.com.ng/'. $cleanurl .'"><img src="'. $image .'" width="95%"><h6>'.$title .'</h6><p style="font-size:10px;color:rgb(100,90,100);">'.$description.'...</p></a></div>';








}





?>


