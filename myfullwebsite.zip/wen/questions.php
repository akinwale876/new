

<br>



<?php


date_default_timezone_set('Africa/Lagos'); 






$comment_sql = "SELECT * FROM questions";

$c_sql = "SELECT * FROM reply_questions";

$comment_query = mysqli_query($conn,$comment_sql);
$c_query = mysqli_query($conn,$c_sql);

$nn= mysqli_num_rows($c_query);

if(mysqli_num_rows($comment_query) > 0){
    
    echo '<h2 name="comment"> '.mysqli_num_rows($comment_query).' Questions <span style="font-weight:normal;font-size:13px;">& '.$nn .' replies</span><p style="font-size:12px;color:rgb(56,100,90);font-weight:500;"></p></h2>';

    
}else{
    echo '<h2 style="text-align:center;" name="comment"> No Topic yet</h2>';

}



while($comment_data = mysqli_fetch_array($comment_query)){
    
    
$comment_username = $comment_data['username'];

$comment_email = $comment_data['tel'];

$comment_comment = $comment_data['question_title'];
$question_id = $comment_data['question_id'];

$comment_date =  date('D M d - Y',$comment_data['date']) . ' <b>at</b> ' . date('  m:ha',$comment_data['date']);


 
 

$reply_sql = "SELECT * FROM  `reply_questions` WHERE reply_question_id = '$question_id' ORDER BY id ASC";

$reply_query = mysqli_query($conn,$reply_sql);
 
 
$full_reply_data = '';


while($reply_data = mysqli_fetch_array($reply_query)){
    
    
$reply_username = $reply_data['username'];

$reply_email = $reply_data['email'];

$reply_comment = $reply_data['reply_question_title'];

$reply_date =  date('D M d - Y',$reply_data['date']) . ' <b>at</b> ' . date('  m:ha',$reply_data['date']);




$full_reply_data .='


<br><p style="font-size:19px;margin:10px;"><b>'.$reply_username.' </b>-->  '.$reply_comment.' <time style="font-size:9px;"> '.$reply_date.'</time></p>



';


 
 
}





$fun = "'". $question_id ."'";




        if(isset($_COOKIE['commentname'])){
                 
                 $comment_name = $_COOKIE['commentname'];
                 
                 $replyname =  '<h5>Name:<span style="color:rgb(200,40,40);" > '. $comment_name .' </span>Reply Question</h5>
                 <input type="hidden" id="n'.$question_id.'" value="'. $comment_name.'" />';
             }else{
                 
                 $replyname = '<input type="text" style="width:90px;border:none;" id="n'.$question_id.'" placeholder="Enter Name" />
                   <input type="checkbox" value="name" id="checking"  /><label for="checking" style="font-size:10px;">Save your info</label>
                   ';
             }
             
             
             
             if(isset($_COOKIE['commentemail'])){
                 
                 $comment_email = $_COOKIE['commentemail'];
                 
                 $emailreply = '<h5>Email/Phone No:<span style="color:rgb(100,100,100);" > '. $comment_email .'</span></h5>
                 <input type="hidden" id="e'.$question_id.'" value="'. $comment_email.'" ><label><span style="color:red;">Note: </span>Only you can see this</label>';
             }else{
                 
               $emailreply = '<input type="text" style="width:90px;border:none;"  id="e'.$question_id.'" placeholder="Email Or Phone No" />

                   ';
             }
             
             
             



echo ' 
<div class="data" style="height:auto;margin:0;">

              <div class="left-side">
<img style="border:none;border-radius:50%;" src="https://naijaramz.com/icons/images.png" height="10px" width="10px">
              </div>
              <div class="right-side" style="height:auto;">
              <small> <span style="color:rgb(100,100,100);">'.$comment_date.' </span>
              </small>
              
              <p style="font-size:25px;margin:10px"><b>'.$comment_username.'</b>    "'.$comment_comment.'"  </p> 
            
       <fieldset style="border:none;padding:5px;"><legend class="replies" style="position:relative;font-size:10px;">Replies<i class="fa fa-sort-desc" aria-hidden="true"></i></legend>
       
          <div style="padding:7px;background:none;">
       '.$full_reply_data.'
              
       
         </div>
       </fieldset>
          <br>
     <fieldset><legend style="font-family:arial;font-size:13px;"  class="accord">Reply</legend>
             
             <div class="panel">
             <center>
         '.$emailreply. $replyname   . '
         
         <textarea id="c'.$question_id.'" rows="3" style="width:50%;"  placeholder="Reply to the topic above"></textarea>
       <br>
       
 <input style="margin-left:10px;padding:6px;border:1px solid rgb(200,200,200);outline:none;" type="submit" 
 
 onclick="reply('.$fun.')" value="Reply! to '.$comment_username.'" />
 <span style="display:none;font-size:8px;" id="sss"><img src="https://www.naijaramz.com/icons/ggg.gif" style="height:80px;width:80px;">Processing please wait or refresh the page</span>
        </center>
             
             </div>
        </ fieldset>
       
       </div> 
       
       </div>  ';
 
}

?>




<br>


<center><h3><img src="https://naijaramz.com/icons/chat.png" height="20px">?ask</h3></center>




    
         <div class="input-container" style="width:90%;height:auto">
             
             
             
             <?php
             
             if(isset($_COOKIE['commentname'])){
                 
                 $comment_name = $_COOKIE['commentname'];
                 
                 echo '<p style="margin:5px;font-size:13px;">your information is saved Name:<span style="color:rgb(200,40,40);" >'. $comment_name .',</span>
                 </p><input type="hidden" id="nametopic" value="'. $comment_name.'" />';
             }else{
                 
                 echo '<input type="text" name="name" id="nametopic" placeholder="Name" />
                   <input type="checkbox" value="name" id="checkers"  /><label for="checkers" style="font-size:10px;">Save your info</label>
                   ';
             }
             
             ?>
                   
           
                  <?php
             
             if(isset($_COOKIE['commentemail'])){
                 
                 $comment_email = $_COOKIE['commentemail'];
                 
                 echo '<p style="margin:5px;font-size:13px;">Email/Phone No:<span style="color:rgb(100,100,100);" > '. $comment_email .'</span>
                 <input type="hidden" id="emailtopic" value="'. $comment_email.'" ><label><span style="color:red;">Note: </span>Only you can see this</label></p>';
             }else{
                 
                 echo '<input type="text" name="email"  id="emailtopic" placeholder="Email Or Phone No" />

                   ';
             }
             
             ?>
               
             
             
             
         </div>
         
               <br> 
               <center>
          <textarea id="commenttopic" rows="7" style="width:96%;"  name="comment" placeholder="Write here"></textarea>
             </center>
         <br>
         
        
        
         <div class="input-container" style="width:90%;">
                   <input style="font-size:11px;border-radius:10%;padding:8px;border:1px solid rgb(200,20,20);color:rgb(200,20,20);" type="submit" name="submit" id="submit" onclick="comm()" value="Post !" />
     <span style="display:none;" id="ssss"><img src="https://www.naijaramz.com/icons/ggg.gif" style="height:90px;width:90px;">Processing please wait</span>
</div>

         
         <br>
         <br>


<style>
    
    fieldset{
        
        border:none;
        
    }
    
    .panel{
        
        display:none;
        
    }
    
    
    .accord{
        
       
        margin-bottom:20px;
        
        border:none;
        outline:none;
        cursor:pointer;
        text-align:right;
    }
    
    
</style>


<script>
    
    
    function   reply(input){
     
     
        
        
        if($('#checking').is(":checked")){
            
                    var checking = $('#checking').val();

        }
        



        
        $('#sss').slideDown(100);
        

        
        var replyname = $('#n'+ input).val();

        var replyemail = $('#e' + input).val();
        var replycomment = $('#c' + input).val();

        
        
        $.post("https://naijaramz.com/reply_question_server.php", {
    checking: checking,
    replyid:input,
     name: replyname,
    email: replyemail,
    comment: replycomment
  }
  
  ,function(data){
        
        
        if(data == 'Ok'){
            
           $('#sss').html('<span style="color:green;">Added succesfully</span>');
            
$('#c' + input).val('');
        }else{
     
                $('#sss').html('<span style="color:green;">'+data+'</span>');
       
            
        }
        
        
        
     
        
    });
    
    
        
    }
    
    
</script>





<script>
    
    
    $('#submit').click(function(){
        
        
        $('#ssss').show();
        
        
        
        if($('#checkers').is(":checked")){
            
                    var checkers = $('#checkers').val();

        }
        
        
        var nametopic = $('#nametopic').val();
        var emailtopic = $('#emailtopic').val();
        var commenttopic = $('#commenttopic').val();

        
        
        $.post("https://naijaramz.com/question_server.php", {
    check: checkers,
     name: nametopic,
    email: emailtopic, 
    comment: commenttopic
  }
  
  ,function(data){
        
        
        if(data == 'Ok'){
               $('#ssss').html('Question post successful');
               $('#comment').html('');
               

        }else{
              $('#ssss').html(data);
            
        }
        
        
        
     
        
    });
    
    
    
    
    })
</script>




<script>
    
    
    var accord = document.getElementsByClassName('accord');
    
    
    for(i=0;i < accord.length;i++){
        
        accord[i].onclick = function(){
            
            
            
            if(this.nextElementSibling.style.display == 'block'){
                this.nextElementSibling.style.display= 'none';
                
            }
            else{
                
                                this.nextElementSibling.style.display= 'block';

            }
            
            
            if(this.parentElement.style.border == '1px solid gray'){
                
                            this.parentElement.style.border= 'none';

            }else{
                            this.parentElement.style.border= '1px solid gray';

            }
            
        }
        
    }
    
    
    
    
    
</script>



   





         
         <br>
         
         
         
         
         
         <style>
         
         
         .replies::after{
             
             content:'';
             border-style:bold;
             border-width:7px;
             border-color:transparent transparent transparent rgb(50,50,50);
             position:absolute;
             right:0;
             bottom:0;
             
         }
         
                    
             
         </style>
         
         
         
         
         
         
         <br>
         <br>