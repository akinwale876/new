<div style="padding:10px;">
<a href="https://<?php echo $_SERVER['SERVER_NAME']?>">
    
    <span style="margin-left:100px;">
        <div class="header-image">
            
</div>
</span> </a> 

<br><br>
<div class="header"  id="nav">



<header class="cex-ui-header" style="">

<div class="cex-ui-header-content" >



<div class="cex-ui-col-lg-0 cex-ui-col">

<div class="cex-ui-menu cex-ui-menu-mobile">
               <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Music" style="padding:6px;margin-left:6px;border:1px dotted rgb(240,240,240);font-size:11px;background:white;border-radius:18%;" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">Music</a>
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Entertainment" style="padding:6px;margin-left:6px;border:1px dotted rgb(240,240,240);font-size:11px;background:white;border-radius:18%;" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link"
   style="margin-left:6px;">Entertainment</a>
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/comedy.php" style="padding:6px;margin-left:6px;border:1px dotted rgb(240,240,240);font-size:11px;background:white;border-radius:18%;" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">Comedy Videos</a>
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/movie" style="padding:6px;margin-left:6px;border:1px dotted rgb(240,240,240);font-size:11px;background:white;border-radius:18%;" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link"
   style="margin-left:6px;">Yoruba Movies</a>
   
    <div class="cex-ui-hamburger">
    
    <div class="cex-ui-hamburger-title">

<div class="cex-ui-hamburger-button" onclick="ddd()">
    
    <div class="cex-ui-hamburger-button-bar1">

</div>

<div class="cex-ui-hamburger-button-bar2">
    
    
</div>

<div class="cex-ui-hamburger-button-bar3"></div>


</div>

<div id="shhow">
    
    
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/MusicVideo.php" 
   
   style="" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">Music Video</a>
   
   
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Emovie.php" 
   
   
   style="" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">English Movies</a>
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Hmovie.php" 
   
   style="" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">Hollywood Movies</a>
</div>

<style>
    
    #shhow{
        
        display:none;
    }
</style>

<script>
    
    function ddd(){
        
        if(document.getElementById("shhow").style.display = "none"){
            
            document.getElementById("shhow").style.display = "block";
        }
        else{
            document.getElementById("shhow").style.display = "none";
            
        }
    }
    
    
</script>

</div>


</div>

                
</div>

</div>

<div class="cex-ui-col-0 cex-ui-col-lg cex-ui-col"><div class="cex-ui-menu cex-ui-menu-desktop">
                                                                                           
<div class="cex-ui-menu-item" style="margin-left:40px;">
          <nav>
          <div class="cex-ui-row">
                         
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/News" 
   
   style="" 
   
   class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">News</a>
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Sport" 
   style=""
   class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">Sport</a>
   
   
   
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Music" 
   
   style="" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">Music</a>
   
   
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/MusicVideo.php" 
   
   style="" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">Music Video</a>
   
   
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Entertainment" 
   
   style="" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link"
   style="margin-left:6px;">Entertainment</a>
   
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/comedy.php" 
   
   style="" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">Comedy Videos</a>
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/movie" 
   
   style="" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link"
   style="margin-left:6px;">Yoruba Movies</a>
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Emovie.php" 
   
   
   style="" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">English Movies</a>
   <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Hmovie.php" 
   
   style="" class="cex-ui-text cex-ui-text-small cex-ui-menu-item-link" 
   style="margin-left:6px;">Hollywood Movies</a>
                         
                         </div>
                         </nav>
                         </div>
                         
                         <div class="cex-ui-auth-block cex-ui-menu-auth">
                             
        

                             
                             
                             
     
                                 
                                 
    <span style="font-size:10px;margin-left:1px;">Connect</span>        
<a target="blank" href="https://www.facebook.com/naijaramz"><img style="height:17px;width:17px;margin-left:5px;" src="https://naijaramz.com/icons/fbb.png"  /></a>

<a target="blank" href="https://www.twitter.com/naija_ramz"><img style="height:17px;width:17px;margin-left:5px;" src="https://naijaramz.com/icons/twitt.png
"  /></a>
<a target="blank"  href="https://www.instagram.com/naijaramz"><img style="height:17px;width:17px;margin-left:5px;" src="https://naijaramz.com/icons/insta.png
" /></a>
                                          



                                 </div>
                                 
                                 </div>
                                 
                                 </div>
                                 
                                 </div>
                                 
                                 
                                 </header>





    </div>
    
    
    <br>
    
<!--<center><img class="backimg"  src="https://naijaramz.com/Naijaramz. xmaspng.png" style="width:100%;"></center>

-->
    <br>


    
    
    <br> 
    
    <style>
        
        .cex-ui-header{
            background:white;color:black;
            
            
        }
        
        
        .cex-ui-text{
            
            
            
            padding:6px;margin-left:6px;border:1px dotted rgb(240,240,240);
   font-size:11px;background:white;border-radius:10%;
        }
        
        
        .backimg{
            
            height:200px;
        }
        
        
@media screen and (max-width:980px){
    
    
        .cex-ui-header{

                background:white;color:black;            
            
        }
        
    

    
}

        
    </style>
    
    
    
    
    <br>