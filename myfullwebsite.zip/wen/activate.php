<?php



require 'connection.php';





if(isset($_GET['code'])){
    
    $code= $_GET['code'];
    
    if(isset($_GET['email'])){
        
        $email = $_GET['email'];
        
        
    if(isset($_GET['id'])){
        
        
    $id = $_GET['uid'];
        
            $query = mysqli_query($conn,"SELECT * FROM activation_code  WHERE uid = $id LIMIT 1");
        
        
           if(mysqli_num_rows($query)  > 0){
               
               
                 mysqli_query($conn, "UPDATE `author` SET `active` = 1 WHERE `email` ='$email'");
               
           }
           
           else{
               
               
               echo 'not verified';
           }
        
    }
    
        
        
        
        
    }
    
    
    
}else{
    
    
    
    
    echo 'error ';
}






?>