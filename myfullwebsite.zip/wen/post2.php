
<?php

session_start();





?>
<!DOCTYPE html>

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php 


include $_SERVER['DOCUMENT_ROOT'] . '/postdata2.php';


?>

 <title>DOWNLOAD <?php echo str_replace('– Latest Nollywood','',$title) ;?> - Naija Ramz Movie</title>

<meta name="title" content="Download: <?php echo $title;?>"/>



<?php


include 'cookie.php';
?>

<meta name="description" content="download <?php echo $title?>"/>

<meta property="og:title" content="<?php echo $title;?>"/>

<meta property="og:description" content="<?php echo $description;?>" />
		
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<link rel="canonical" href="<?php echo 'https://naijaramz.com/movie/'. $cleanurl;?>" />

<meta property="og:url" content="<?php echo 'https://naijaramz.com/movie/'. $cleanurl;?>" />

<meta property="og:image" content="<?php echo $image; ?>">

<!-- Indicate preferred brand name for Google to display -->

<meta property="og:site_name" content="NaijaRamz Entertainment & learning tips" />

<meta property="og:type" content="article" />

<meta name="title" content="<?php echo $title;?>"/>




<?php


include $_SERVER['DOCUMENT_ROOT'] . '/head.php';


?>

<body>


<?php



include $_SERVER['DOCUMENT_ROOT'] . '/header.php';



?>
    <h6 style="display:inline-block;margin:3px;margin:15px;padding:15px;"><?php echo '<a style="" href="http://'. $_SERVER["SERVER_NAME"] .'">Home</a>' .' / <a href="http://'. $_SERVER["SERVER_NAME"]. '/'.$category .'">' . $category .'</a> / ' . $cleanurl .'</span>';?></h6>

    <span style="font-size:12px;font-weight: 700;padding-top:4px;padding-bottom:4px;margin-left:10px;margin-right:10px;"><?php echo '<i class="fa fa-clock"></i><span style="margin-left:8px;">' . date("l d-M-Y",$date) .'</span>'?> </span>




<span style="font-size:13px;">Share this movie</span>

<?php

include $_SERVER['DOCUMENT_ROOT'] .'/sharer.php';

?>
<span onclick="addCom()" style="float:right;font-family:Lato;font-size:10px;margin-top:15px;margin-right:10px;cursor:pointer;">
    
    <i class="fa fa-comment"></i>add comment</span>



<div class="wrapper">
    
    

<h2 class="post-h1" ><?php if($category != 'Music Video' && $category != 'Comedy Video'){ echo 'DOWNLOAD:'; }?>  <?php echo '['.$category . '] '. $title;?> </h2>


<br>
    
    
<div class="main" style="border:none;position:relative;">
    
<?php

if(isset($_SESSION['access'])){
    
   echo '<a href="http://naijaramz.com/update_movie_post.php?q='.$id.'" title="Edit post"
   style="position:absolute;top3px;right:3px;font-size:10px;">Edit</a>';  }
        
        ?>

<h6 style="margin-top:2px;color:black;display:inline-block;padding-top:2px;padding:6px;font-weight:bold;"><span style="color:black;margin-left:3px;background:white;padding:2px;display:inline-block;">
    <?php echo $category;?></span></h6>
    
<a href="#comment"><h6 style="display:inline-block;padding-top:2px;padding:3px;"><i class="fa fa-comment"></i>

<span style="color:red;margin-left:3px;background:white;padding:4px;display:inline-block;">
     <?php 
$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$comment_id'");


echo $num_post_query = mysqli_num_rows($comment_post_query);

?></span></h6></a>
    
    
<h2 style="display:inline-block;padding-top:2px;padding:3px;">
    
    <i class="fa fa-eye"></i>

<span>
   <?php echo $views;?></span></h2>



    <?php  
    
echo '<h6 style="font-size:12px;color:brown;margin-left:2px;color:black;display:inline-block;padding-top:2px;padding:6px;">Posted by  <span style="color:brown;">'.$author . '</span></h6>';
    
    ?>
    


<center>
    
<div style>
	
<article style="height:auto;padding:6px;">
    
    
<iframe width="100%" height="260px"
src="https://www.youtube.com/embed/<?php echo $video_id ?>?autoplay=1">
</iframe>
    
    <!--  -->
    
    
    
    <?php
    
    
    /*
<img style="border-radius:0px 4px 4px 0px;" src="https://i.ytimg.com/vi/<?php echo $video_id; ?>/hqdefault.jpg" 
alt="This movie is available for download dont mind the image not showing" width="100%" height="auto"  />
  
    */
    
    ?>
    
</article>



</div>

</center>

<p >
    
    
    


</p>


<div class="p-content" style="color:gray;margin-top:50px;">

<p>
<?php 
echo '
Download ' . str_replace('– Latest Nollywood','',$title);


?>





<i><small><?php 
echo  'Featured by '.$tag. ' <a href="#related"> See more list</a>';
?></small></i>


</p>
<p>

        <p style="color:rgb(100,100,100);"><em>
<?php 
echo $content;
?></em></p>
</p>
<br>


<p style="font-size:13px;">Share this movie to any of the social media platform</p>

<?php

include $_SERVER['DOCUMENT_ROOT'] .'/sharer.php';

?>
<br>


    
</div>



<br>


<br>


<center>
	
	
	<?php
	
	if(strlen($video_id) > 11){

	  echo '
	<a style="font-size:15px;padding:8px;color:rgb(100,100,100);" 
	href="'. $video_id .'"> Download Here</a>';  
	    

	}else{
	  echo '
	<a style="font-size:15px;padding:8px;color:rgb(100,100,100);" 
	href="http://naijaramz.com/getvideoinfo.php?video_id='. $video_id .'&title='. $title.'"> Download Here</a>';  
	    
	}
	
	
	
	?>




</center>

<br>


<?php



$post_queryt = mysqli_query($conn,"SELECT * FROM movies WHERE tag='$tag'  AND id !='$id' ORDER BY id DESC LIMIT 3 ");


if(mysqli_num_rows($post_queryt) > 0){
    
    
echo '<a name="related"></a><h2  style="padding: 8px;color:black;">More of '.$tag.' <span style="text-indent: 10px;">
<i class="fa fa-book"></i></span></h2>' ;


}


while($datat = mysqli_fetch_array($post_queryt)){
    


$titlet = $datat['title'];
$descriptiont= substr($datat['description'],0,60);

$cleanurlt = $datat['cleanurl'];
$pic= $datat['picture_url'];

$date = $datat['date'];

$date = date(' d-M-Y', $date);


echo '<a style="text-decoration:none;color:black;" href="http://'. $_SERVER["SERVER_NAME"].'/movie/'.$cleanurlt.'">

<div class="post" style="position:relative;background:white;">

<img alt="'.$list_title.'" class="img" src="'. str_replace('http','https',$pic). '">


<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($titlet).'</h4>
<br>
<small>'. $date .'</small>
</div>


    
</div></a>';







}




if(mysqli_num_rows($post_queryt) > 0){
  


}
?>

<?php


include  $_SERVER['DOCUMENT_ROOT'] .'/comment.php';





?>
</div>



<!--     ending of main-->

<?php




include $_SERVER['DOCUMENT_ROOT'] . '/sidebar.php';



?>



</div>


<?php




include $_SERVER['DOCUMENT_ROOT'] . '/footer.php';



?>


<script>
    
    function addCom(){
        
        var x = document.getElementById('comment');
        
        
        
        x.focus();
        
        
    }
    
    
</script>


<style>
    
 .main   p{
        
        font-size:19px;
        line-height:29px;
    }
    
    
    body{
        
        background:black;
        color:white;
    }
    
    .wrapper{
        
              background:white;
              color:black;

    }


       
</style>


</body>

</html>