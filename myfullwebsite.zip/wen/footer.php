<div class="footer" style="position:relative;">

<br>




<footer class="cex-ui-footer" style="background:white;">


<div class="cex-ui-footer-content"><div class="cex-ui-footer-content-menu">

<div class="cex-ui-footer-content-menu-column">
            


  <div class="header-image" >  

</div>



    <nav>

                
                </div><div class="cex-ui-footer-content-menu-column">
                      <iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FNaijaramz7&width=450&layout=standard&action=like&size=small&share=false&height=35&appId" width="450" height="35" style="border:none;overflow:hidden;display:inline-block;margin:10px;" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

                
    <p style="color:rgb(100,100,100);font-weight:400;">
    
    
   
<small style="font-size:9px;float: left;margin: 0;">

<script language="JavaScript">

document.write('&copy;' );
document.write(' <b><i>NaijaRamz</i> ');
document.write(new Date().getFullYear());
document.write(' </b> Alright Reserved');

</script>

</small>
 



</p>

                
                
                </div><div class="cex-ui-footer-content-menu-column">
                    
                    <h2 class="cex-ui-title cex-ui-title-m cex-ui-title-left">About</h2>
                    
                    
                    <ul class="ul-list">

        
    

    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/about" >About us</a>

        </li>
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/contact" >Contact Us</a>
        

        </li>
   
    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/privacy-policy" >Privacy Policy</a>

        </li>   
    <li>

        <a href="https://store.naijaramz.com" >Store</a>

        </li>     


    </ul>
                  
                  </div><div class="cex-ui-footer-content-menu-column">
                        
                        <h2 class="cex-ui-title cex-ui-title-m cex-ui-title-left">Follow</h2><div class="cex-ui-social">
                            <div class="cex-ui-messengers"><button href="https://twitter.com/cex_io" 
                            class="cex-ui-icon-button cex-ui-icon-button-big cex-ui-icon-button-secondary" target="_blank">
                                
                                <svg width="33" height="26" fill="none" xmlns="http://www.w3.org/2000/svg" 
                                class="cex-ui-icon cex-ui-icon-social" viewBox="0 0 33 26">
                                    
                                    <path d="M33 3.078c-1.214.522-2.52.875-3.889 1.032 1.398-.812 2.471-2.097 2.978-3.63a13.814 13.814 0 01-4.3 1.592A6.865 6.865 0 0022.846 0c-3.738 0-6.77 2.94-6.77 6.564 0 .514.06 1.015.176 1.496C10.625 7.786 5.636 5.173 2.297 1.2a6.384 6.384 0 00-.917 3.301c0 2.277 1.196 4.287 3.012 5.463a6.884 6.884 0 01-3.067-.822v.084c0 3.18 2.335 5.833 5.431 6.435a6.99 6.99 0 01-3.057.114c.861 2.607 3.361 4.505 6.325 4.558a13.858 13.858 0 01-8.41 2.81c-.545 0-1.085-.031-1.614-.092A19.59 19.59 0 0010.377 26c12.454 0 19.264-10.002 19.264-18.676 0-.284-.007-.568-.02-.849A13.505 13.505 0 0033 3.078z" fill="#0C87F2"></path></svg></button>
                                    
                                    <button href="https://t.me/CEX_IO" class="cex-ui-icon-button cex-ui-icon-button-big cex-ui-icon-button-secondary" target="_blank">
                                        
                                        <svg width="34" height="30" fill="none" xmlns="http://www.w3.org/2000/svg" class="cex-ui-icon cex-ui-icon-social" viewBox="0 0 34 30">
                                            
                                            <path d="M.6 14.385l7.835 2.963 3.032 9.883a.918.918 0 001.465.447l4.367-3.608a1.29 1.29 0 011.588-.045l7.877 5.795a.92.92 0 001.446-.565l5.77-28.127c.148-.726-.555-1.33-1.236-1.064L.59 12.634c-.793.31-.786 1.449.01 1.75zM10.98 15.77l15.31-9.557c.276-.171.559.206.323.428L13.976 18.546c-.445.419-.731.98-.812 1.588l-.43 3.232c-.058.432-.656.475-.774.057l-1.655-5.895c-.19-.672.087-1.39.674-1.757z" fill="#0C87F2"></path></svg></button>
                                            
                                            <button href="https://www.facebook.com/pages/CEXIO/420149274752615?fref=ts" 
                                            class="cex-ui-icon-button cex-ui-icon-button-big cex-ui-icon-button-secondary" target="_blank">
                                                <svg width="16" height="29" fill="none" xmlns="http://www.w3.org/2000/svg" 
                                                class="cex-ui-icon cex-ui-icon-social" viewBox="0 0 16 29">
                                                    <path d="M15.398.006L11.56 0C7.248 0 4.462 2.801 4.462 7.137v3.29H.603A.598.598 0 000 11.02v4.768c0 .327.27.591.603.591h3.859v12.03c0 .327.27.592.603.592H10.1a.597.597 0 00.603-.591v-12.03h4.512a.597.597 0 00.603-.592l.002-4.768a.586.586 0 00-.177-.418.61.61 0 00-.427-.174h-4.513V7.639c0-1.34.326-2.021 2.109-2.021l2.585-.001A.597.597 0 0016 5.024V.597c0-.326-.27-.59-.602-.591z" fill="#0C87F2"></path></svg></button><button href="https://www.linkedin.com/company/cex-io" class="cex-ui-icon-button cex-ui-icon-button-big cex-ui-icon-button-secondary" target="_blank"><svg width="27" height="27" fill="none" xmlns="http://www.w3.org/2000/svg" class="cex-ui-icon cex-ui-icon-social" viewBox="0 0 27 27"><path fill-rule="evenodd" clip-rule="evenodd" d="M1.292 1.725c.595-.56 1.37-.84 2.327-.84.958 0 1.725.28 2.302.84.576.56.87 1.266.882 2.12.011.841-.28 1.545-.874 2.11s-1.375.848-2.344.848H3.55c-.946 0-1.707-.283-2.284-.848C.69 5.39.401 4.686.401 3.845c0-.854.297-1.56.891-2.12zm23.885 8.982c-1.2-1.309-2.786-1.964-4.758-1.964-.727 0-1.387.09-1.981.269-.594.178-1.096.43-1.505.752-.41.323-.736.623-.978.9-.23.263-.455.569-.675.915V9.141H9.588l.017.83c.012.554.018 2.261.018 5.122 0 2.86-.012 6.592-.035 11.194h5.692V16.72c0-.588.064-1.055.19-1.401a3.675 3.675 0 011.1-1.48c.49-.398 1.098-.597 1.825-.597.992 0 1.721.343 2.189 1.03.467.686.7 1.635.7 2.846v9.17h5.693V16.46c0-2.527-.6-4.444-1.8-5.753zM6.438 9.143H.728v17.145h5.71V9.143z" fill="#0C87F2"></path></svg></button></div><button href="https://cexio.statuspage.io/" class="cex-ui-button cex-ui-button-small cex-ui-button-secondary-outlined" target="_blank">Naijaramz.com Status</button><div class="cex-ui-paymentSystems">
         <span class="cex-ui-icon cex-ui-icon-big"></a>
                                                                
                                                                </div></div></div></div>
                                                                
                                                                <div class="cex-ui-footer-content-copyrights"></div></div>

</footer>









    
    <style>
        
        ul.ul-list li a{
            
            text-decoration:none;
            


        }
        
       .footer ul.ul-list li a{
            font-size:12px;

        }
        
        
    </style>
    
    
    </nav>
    
    


<style>
    
    p{
        font-size:11px;
        color:#07240f;
    }
</style>

<?php


include 'scroller.php';
   ?>


<div style="">

    
</div>
</div>
</div>


<?php

/*
<div style="position:fixed;bottom:10px;left:10px;display:inline-block;z-index:1;background:rgb(240,240,240);padding:5px;display:none;width:97%;" class="container">
    
    <div style="position:relative;">

        
        <span style="background:rgb(200,200,200); border-radius:8px;position:absolute;right:4px;top:0;color:rgb(100,0,0);padding:5px;font-size:9px;font-weight:bold;cursor:pointer;" id="remove">Accept</span></div>
    
    <div style="overflow:auto;padding:8px;">
        
<center>

<p style="font-size:12px;  ">By continuing to browse or by clicking “Accept Cookies,” you agree to the storing of first- and third-party cookies on your device to enhance site navigation, analyze site usage, and assist in our marketing efforts. Read
 more at <a href="https://naijaramz.com/privacy-policy">policy</p>

</center> 


    </div>
    
</div>
*/

?>










<a style="padding:6px;background:rgb(50,150,50);color:white;box-shadow:0px 4px  4px 0px rgb(90,99,90);display:none;position:fixed;bottom:10px;right:6px;font-weight:bold;
text-decoration:none;font-size:19px;" href="javascript:void(0);" id="upp" onclick="gg()">
    <span style="font-size:10px;color:white;margin-right:4px;" id="dd">Top</span>&uArr;</a>


<script>



       $('#upp').click(function(){
           
           
                   $('html,body').animate({scrollTop:0},600);

           
       })

  




</script>
<script>



    setInterval(function(){

          $('.main').fadeIn(1000);

 
        
    },1000);
   

var nnn;


nnn = 0;


    setInterval(function(){

if(nnn == 0){
            
           
          $('.container').fadeIn(2200);

          $('.imm').slideUp(500);
          $('.stories').fadeIn(500);
}
 
        
    },1000);
   
    

    
    $('#remove').click(function(){
        

                    $('.container').fadeOut(1010);

    
    nnn = 1;    
    });
    
    
    
    $('#rem').click(function(){
        
            $('html').animate({opacity: '1'});
                    $('.container').animate({left:"0",top:"0"}, 'fast');

                    $('.container').slideUp(10);

    
    nnn = 1;    
    });
    
    

</script>











<script type="text/javascript">


var body = window;
 
 body.addEventListener('scroll', callMe);


   function callMe(){

       
if(document.documentElement.scrollTop > 400){
    
              $('#upp').fadeIn(1500);

}
  
if(document.documentElement.scrollTop < 400){
    
              $('#upp').fadeOut(1500);

}



   }


</script>



<script type="text/javascript">
  

         var imgs = document.getElementsByClassName('header-slide-img');


         for (var i = 0; i < imgs.length; i++) {
           var getwidth = imgs[i].width;
           
          // getwidth = getwidth - 90;
            //document.getElementById('mainslide').style.width = getwidth + 'px';
          // imgs[i].style.width = getwidth + 'px';


         }


         if (imgs.length == 0) {


                 document.getElementById('slideControl').style.display = 'none';
                 document.getElementById('slideControl1').style.display = 'none';
         }


</script>

<style>
    
    
    body,html{
        
     margin:0; 
     
    }
    
</style>
