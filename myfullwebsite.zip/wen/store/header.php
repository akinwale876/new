<div style="padding:10px;">
<a href="https://<?php echo $_SERVER['SERVER_NAME']?>">
    
    <span style="margin-left:100px;">
        <div class="header-image">
            
</div>
</span> </a> 

<br><br>

                    
                             <?php
                              
                              session_start();
                              
                              include 'admin_init.php';

                             
 
 if(!isset($_SESSION['access'])){
     
     echo '
                              <a href="/login"> <h1 
                             >Sign In</h1>
                             </a>
                                 ';
     
 }else{
     
          echo '  
                                 
                                 <a href="https://store.naijaramz.com/welcome.php" style="color:white;"><h1>Account</h1></a>
                                 <a href="https://store.naijaramz.com/logout.php" style="color:red;float:right;"><h1>Logout</h1></a>
';

 }
 
 
                             
                             
                             ?>





    </div>
    
    
    <br>
    
<!--<center><img class="backimg"  src="https://naijaramz.com/Naijaramz. xmaspng.png" style="width:100%;"></center>

-->
    <br>
    
       


    
    
    <br> 
    
    <style>
        
        .cex-ui-header{
            background:white;color:black;
            
            
        }
        
        
        .cex-ui-text{
            
            
            
            padding:6px;margin-left:6px;border:1px dotted rgb(240,240,240);
   font-size:11px;background:white;border-radius:10%;
        }
        
        
        .backimg{
            
            height:200px;
        }
        
        
@media screen and (max-width:980px){
    
    
        .cex-ui-header{

                background:white;color:black;            
            
        }
        
    

    
}

        
    </style>
    
    
    
    
    <br>