<!DOCtype
 html>
 
 
 <?php
 
 require 'admin_init.php';
 
 
 
 
 
 if(!isset($_SESSION['access'])){
     
     echo '<script>
     
     
     window.location ="https://store.naijaramz.com/login"
     
     </script>';
     
 }
 
 
 
 ?>
 
 
 
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Welcome <?php echo $firstname; ?> - Author NaijaRamz</title>
<meta name="discription"
content="" />


<?php

include "head.php";

?>


</head>


<body style="background-image: url('1000231-digital-art-night-minimalism-internet-deep-web-dark-background-sphere-fireworks-midnight-event-darkness-recreation-black-and-white-outdoor-recreation.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;">
      
      <?php 
      
      include 'header.php';
      
      ?>
    
<div class="wrapper" style="background:none;color:white;">
    <?php if($active == 0){
        
        echo '<h6>your account is not activated yet<a href="http://naijaramz.com/sendcode.php"> activate your account </a></h6>';
    }?>
<center>
    <h2 style="font-size:41px;">Welcome: <?php echo $firstname; ?></h2>
    
    <br><i class="far fa-user"></i>
 <h2>Your Account Status: <i><?php echo $active;?></i></h2>

<br>
 

<?php     if($active == 1) {echo '




<a href="https://store.naijaramz.com/add-post">
    
    <div style="background:white;color:black;width:330px;padding:36px;height:150px;display:inline-block;box-shadow:0px 2px 2px 0px rgb(200,200,200);">
         <center><i class="fab fa-cc-apple-pay" style="font-size:30px"></i>
       <h2>Publish post</h2>
         </center>
    </div>
    
    </a>
    
    
<a href="https://store.naijaramz.com/post-music.php">
   
    <div style="background:white;color:black;width:330px;padding:36px;height:150px;display:inline-block;box-shadow:0px 2px 2px 0px rgb(200,200,200);">
       <center> 
    <i class="fa fa-music" style="font-size:30px"></i>
       <h2>Promote Your Music</h2>
        </center>
    </div>
    
    </a>
<a href="https://store.naijaramz.com/post-movie.php">
   
    <div style="background:white;color:black;width:330px;padding:36px;height:150px;display:inline-block;box-shadow:0px 2px 2px 0px rgb(200,200,200);">
       <center> 
    <i class="fa fa-video" style="font-size:30px"></i>
       <h2>Promote Your Video</h2>
        </center>
    </div>
    
    </a>

';
}
else{
    
    
          echo '<h4 style="color:red;">your account is not activated yet<a href="https://naijaramz.com/sendcode.php"> activate your account to unable you to post</a></h4>';

    
}


?>


</center>

<br>
<br>

<br>
<br>



    
    <h2>Your ticket</h2>
    
<br>

<br>
<br>
<br>

<h2>Your Recent post</h2>

<br>

<?php 


$nam = $firstname.$lastname;


$list_post_query = mysqli_query($conn,"SELECT * FROM `posts`  WHERE author='$nam' ORDER BY id DESC LIMIT 2");

echo '<div class="main" style="background:none;">';
if(mysqli_num_rows($list_post_query) > 0){
    


}
else{
    
    
}




while($mov = mysqli_fetch_array($list_post_query)){

$list_title = $mov['title'];
$list_cleanurl = $mov['cleanurl'];
$list_image = $mov['picture_url'];
$list_description = $mov['description'];
$list_content = $mov['description'];

$list_category = $mov['category'];
$list_comments = $mov['comments'];
$list_comments_id = $mov['comment_id'];
$list_views = $mov['views'];

$list_date = date(' l  d / M / Y',$mov['date']);

$current_date = date_create();

$current_date = date_timestamp_get($current_date);


$count_date = $mov['date'];



$count_date =  ($current_date - $count_date);

$comment_post_query = mysqli_query($conn,"SELECT * FROM `comment` WHERE `comment_id` = '$list_comments_id'");


$num_post_query = mysqli_num_rows($comment_post_query);







  
  $days = floor($count_date / (60 * 60 * 24));
  $hours = floor(($count_date % (60 * 24)) / (1000 * 60 * 60));
 $minutes = floor(($count_date % ( 60)) / (1000 * 60));
 $seconds = floor(($count_date % (1000 * 60)) / 1000);
  
  

    
    $time = $minutes  . ' mins ';
    
$likes = $mov['likes'];
//

echo '<a style="text-decoration:none;color:black;" href="https://naijaramz.com/'.$list_category.'/'.$list_cleanurl.'">

<div class="post" style="position:relative;background:white;">
<div class="post-title">
<h4 style="margin-bottom:8px;">'. ucfirst($list_title).'</h4>

<span class="hov" style="padding:3px;font-size:9px;>'.$list_category.'</span>


<b style="color:rgb(10,10,100);position:absolute;left:9px;bottom:10px;"><small><i class="fa fa-clock">'. $list_date .'</i>
</small><span style="margin-left:5px;color:red;font-size:10px;"><i class="fa fa-eye"></i>'.$list_views.' views</span></b><br><span class="content" id="one" style="color:rgb(140,140,140);font-family: Source Sans Pro,sans-serif 
;">
<span class="hov" style="padding:3px;border:none;font-weight:bold;">

<i class="fa fa-comment"></i>'.$num_post_query.'</span><span>

'. str_replace('h2','',str_replace('<h1>','',substr($list_content,0,120))) .'</span>
<span style="color:brown;font-weight:bold;margin-left:4px;font-size:9px;"></span>

</div>


    
</div></a>';

}


echo '</div>';





?>




    
    



</div>






<?php

include "footer.php";

?>


<style>
    
    

body, a, h1{
    
        font-family:Montserrat;

}

h1{
    
        text-shadow:0px 2px 2px 0px rgb(90,90,90);

}



.main{
    
  
    font-size:23px;
    font-family:Montserrat;
}
 
    
    
</style>



</body>

</html>