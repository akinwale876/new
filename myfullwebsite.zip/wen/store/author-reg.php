<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


	<title>Register With us - NaijaRamz</title>

    
<?php

include 'head.php';

?>


</head>
<body>

       <?php
                include 'header.php';    ?>



           <div class="wrapper" style="background:black;">

<div class="main" style="background:black;">
    <center>
    <div class="im">
                    
                       <center><h2>Register With Us</h2></center>         
                       <form name="form" action="/" method="get" onsubmit="return false">

<div class="input-container">
  
<input type="text"  id="firstname" placeholder="First Name">


<span class="input-error-report"></span>

</div>

<div class="input-container">
  


<input type="text" id="lastname" placeholder="Last Name">
<span class="input-error-report"></span>

</div>







<div class="input-container">
  
<input type="text"  id="email" placeholder="Email">


<span class="input-error-report"></span>

</div>




<div class="input-container">
  
<input type="password"  id="password" placeholder="Create a Password">


<span class="input-error-report"></span>

</div>




<div class="input-container">
  
<input type="password"  id="confirm" placeholder="Confirm Password">


<span class="input-error-report"></span>

</div>




<br>
<input type="submit"  name="submit" onclick="register()" id="butto" value="Submit!" >

</form>

                            <p>already have account <a href="http://naijaramz.com/login">Login</a></p>

</div>



</center>
</div>

<div class="sidebar">
    
    <div class="hide" style="background:white;">
    
<p id="status"></p>
               
<p id="loaded"></p>
               
<progress id="progressbar" value="" max="100"></progress>

    </div>
    
</div>

           
           
           </div>


<style>
    
    ol{
        
        list-style:none;
        margin:7px;
    }
    
    
    .im{
        
        
        width:250px;
        background:white;
        padding:10px;
    }
    
 
    
    .hide{
        
        
        display:none;
    }
    
</style>





<style>
    
    

    
    
    
    
</style>





<?php


include 'footer.php';

?>



<script src="reg.js"></script>





<script>
    
    
    

setTimeout(function(){
    
    
    
    
    $('#butto').click(function(){
        
        
    $('.hide').slideDown(200)
    
    
    })
    
    
    
    
    
    
},2000)


</script>
</body>
</html>