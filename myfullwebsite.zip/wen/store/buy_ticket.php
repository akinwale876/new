<?php

session_start();




if(!isset($_SESSION['access'])){
    
    header('location: http://'.$_SERVER["SERVER_NAME"].'/login');
    
    
    
    
    
}else{
    
    require_once 'connection.php';
    
    $sess = $_SESSION['access'];
    
    $sql = "SELECT * FROM author WHERE password = '$sess' AND active = 1 LIMIT 1";
    
    if(mysqli_num_rows(mysqli_query($conn,$sql)) != 1){
        
            header('location: https://'.$_SERVER["SERVER_NAME"].'/welcome.php');

    }
}



?>

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


	<title>Buy ticket - Naija Ramz Store</title>

    
<?php

include 'head.php';

?>


</head>

    
<?php

include 'header.php';

?>


<body>





                       <center><h1>Buy Naija Ramz ticket <small style="font-size:11px;"></small>




<select name="Category" id="category">

<option>Ticket</option>

</select>

</h1></center>

           <div class="wrapper" style="background:black;">

                            <div class="main" style="background:black;">
                                
                            <form name="form" action="/add post" method="get" onsubmit="return false">

<div class="input-container">
  
<input type="text"  id="title" placeholder="Enter token">


<span class="input-error-report"></span>

</div>
<div class="input-container">
  
<input type="text"  id="tag" placeholder="Enter amount">


<span class="input-error-report"></span>

</div>

<div class="input-container">
  


<input type="text" id="description" placeholder="Enter point">
<span class="input-error-report"></span>

</div>



<br>

<br>

<br>
<input type="submit"  name="submit" onclick="uploadFile()" id="ddd" value="Buy!">

</form>

  
                                
                                
                            </div>  
                            
                            <div class="sidebar">
                                
<br>

                                
                            </div>
           
           
           </div>









<?php


include 'footer.php';

?>



<div class="boot" id="boot" style="width:30%;height:200px;position:fixed;bottom:-30px;left:-30px;display:none;background:white;box-shadow:0px 8px 8px 0px rgb(200,200,200);">
    <h6 style="background:black;margin:0;padding:6px;"><progress id="progressbar" value="" max="100"></progress><span style="color:red;float:right;cursor:pointer;"
    onclick="$('.boot').animate({left:'-31px',top:'-28px'},'fast');$('.boot').slideUp('slow');
                              ">&times;</span></h6>

    <div style="padding:5px;">
        
<small id="status"></small>
               
<small id="loaded"></small>
               

           
        
    </div>
    
</div>




<script src="addpost.js"></script>


<style>
    
</style>

   
           <script>
           
           
           
               
                     $('#ddd').click(function(){
                         
                         
                              $('.boot').slideDown('fast');
                              $('.boot').animate({left:"31%",top:"28%"},"fast");
                              
                              
                             
                     });
                  
           </script>

</body>
</html>