<!DOCtype
 html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Welcome to Store</title>

<?php


include "head.php";

?>


<meta name="description" content="Naijaramz store provides you post ticket" />

<meta http-equiv="x-ua-compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no " />
<link rel="canonical" href="https://naijaramz.com"  />



</head>


<body>


<?php

include "header.php";

?>


   <h1 style="font-size:45px;margin:20px;">Welcome to Naijaramz Store</h1>

<div class="wrapper" style="background:black;color:white;">



   <a href="buy_ticket.php">Buy ticket</a>
   
   <br>
   <br>
   <br>
   
   <h2>List of ticket price</h2>

<div class="main">
   <table>
       
       
       <tr>
           
           <th>Amount</th>
           <th>point</th>
      
           <th>Number of post</th>
           
       </tr>
       
       <tr>
           
           <td>1,000</td>
           <td>1.0</td>
           <td>1 post</td>
           
       </tr>
       <tr>
           
           <td>2,000</td>
           <td>2.0</td>
                      <td>2 post</td>

           
       </tr>
       <tr>
           
           <td>3,000</td>
           <td>3.0</td>
                      <td>3 post</td>

       </tr>
       
       
       
   </table>

<br>
<br>
<br>

<h2>Payment</h2>

<br>


<a href="ticket.php">
    
    <div style="background:white;color:black;width:330px;padding:16px;display:inline-block;box-shadow:0px 2px 2px 0px rgb(200,200,200);">
         <center><i class="fab fa-cc-apple-pay" style="font-size:30px"></i>
       <h2> Buy Ticket with card</h2>
         </center>
    </div>
    
    </a>
    
    
<a href="agent.php">
   
    <div style="background:white;color:black;width:330px;padding:16px;display:inline-block;box-shadow:0px 2px 2px 0px rgb(200,200,200);">
       <center> 
    <i class="far fa-user" style="font-size:30px"></i>
       <h2> Buy Ticket from agent</h2>
        </center>
    </div>
    
    </a>

</div>


<?php

include "footer.php";

?>


<style>
    h5{
        
        margin-left:10px;
    }
    
    hr{
        
        border:none;
    }
    
    
    
</style>




<style>


body, a, h1{
    
        font-family:Montserrat;

}

h1{
    
        text-shadow:0px 2px 2px 0px rgb(90,90,90);

}



.main{
    
    background:black;
    color:white;
    
    font-size:23px;
    font-family:Montserrat;
}
    
    
    table{
                padding:8px;
                width:100%;
                

        
        
    }
    
    tr{
        
        background:rgb(10,10,10);
    }
    
    tr:nth-child(even){
        
        background:rgb(20,20,20);
    }
    
    
    th{
        
        padding:8px;
        
    }
    
    td{
        
                padding:8px;

    }
    
    
</style>



</body>

</html>