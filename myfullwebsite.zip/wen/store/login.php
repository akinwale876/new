<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>login - Naija Ramz store</title>


<meta property="og:locale" content="en_US">
<?php

include "head.php";

?>


</head>

<?php 


include 'header.php';


?>




<body>
    
    
<div class="wrapper" style="min-height:auto;height:auto;background:black;">

    
<center>
    <div style="background:white;width:260px;padding:8px;box-shadow:0px 2px 2px 0px rgb(200,200,200);height:310px;border-radius:0px 6px 0px 6px;">
        
<br>
      <h2>Login to your store account</h2>

    <br><br>    
    
        <form method="post" action="admin.php" name="form" id="sub">
            
                 <div>
                        <input type="email" name="email" id="email" placeholder="Enter Email" required>
                 </div>
            
                 <div>
                        <input type="password" placeholder="Enter Password" id="password" name="password">
                 </div>
            
                 <div>
                        <input type="submit" value="Login!"   name="submit">
                 </div>
            
            
        </form>
    <br><br>
      <div>not registered:<a href="https://store.naijaramz.com/create" style="margin-left:3px;color:gray;">Register now</a></div>
      
    </div>

</center>

<script>
    
    
    
    
    
$('#sub').submit(function(){

var email = $('#email').val();
var password = $('#password').val();


  if(email == '' || password == ''){
      
      alert('fill in your details')
  }
          
});

    
    
    
    
</script>

</div>


<?php

include "footer.php";

?>


<style>
    
    
    input[type=email],input[type=password]{
        
        
        font-size:13px;
        font-family:Lato;
        
    }
    
</style>


</body>




</html>