<?php

require 'connection.php';

if(isset($_GET['q'])){
    
    
    $q = $_GET['q'];
    
    
 $sql = "SELECT * FROM posts WHERE id= $q";
 
 
 
 $query = mysqli_query($conn,$sql);
 
 
 
 $data = mysqli_fetch_array($query);
 
 
 
 
 $title = $data['title'];


 
 $id = $data['id'];


 
 
 
 $description = $data['description'];

 
 
 $content = $data['content'];
 
 
 


    
}





?>

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


	<title>Update Post - Naijaramz </title>

    
<?php

include 'head.php';

?>



</head>
<body>

       <?php
                include 'header.php';    ?>


                       <center><h1>Update: <small><?php echo $title;?></small></h1></center>

           <div class="wrapper">
                            
                            <form name="form" action="/add post" method="get" onsubmit="return false">

<div class="input-container">
  
<input type="text"  id="title" placeholder="Enter Title" value="<?php echo $title;?>">
<input type="hidden"  id="id"  value="<?php echo $id;?>">


<span class="input-error-report"></span>

</div>



<div class="input-container">
  


<input type="text" id="description" placeholder="Description" value="<?php echo $description; ?>">
<span class="input-error-report"></span>

</div>



<br>





<center>  
<input type="file"  id="file">
</center>



<br>


<textarea rows="30" id="content" style="width:90%;padding:2px;box-shadow:0px 6px 6px 0px rgb(200,200,200);background:rgb(230,230,,230);" name="content" placeholder="Content...."><?php echo $content;?></textarea>

<br>
<input type="submit"  name="submit" onclick="updates()" id="ddd" value="Update Post!">

</form>

           
           
           
           </div>









<?php


include 'footer.php';

?>



<div class="boot" id="boot" style="width:30%;height:200px;position:fixed;bottom:-30px;left:-30px;display:none;background:white;box-shadow:0px 8px 8px 0px rgb(200,200,200);">
    <h6 style="background:black;margin:0;padding:6px;"><progress id="progressbar" value="" max="100"></progress><span style="color:red;float:right;cursor:pointer;"
    onclick="$('.boot').animate({left:'-31px',top:'-28px'},'fast');$('.boot').slideUp('slow');
                              ">&times;</span></h6>

    <div style="padding:5px;">
        
<small id="status"></small>
               
<small id="loaded"></small>
               

           
        
    </div>
    
</div>




<script>
    
    
    
    

var title,description,id,content;



// preparing variables 



function _(el){



return document.getElementById(el);





}









// ..beginning of form validation...

function updates(){



title = _('title');

description =_('description');

file = _('file').files[0];


 id = _('id');

 content = _('content');





var formdata = new FormData();



formdata.append('title', title.value);

formdata.append('description', description.value);

formdata.append('id', id.value);

formdata.append('content', content.value);

formdata.append('file', file);





if (window.XMLHttpRequest) {

    // code for modern browsers

   var ajax = new XMLHttpRequest();

 } else {

    // code for old IE browsers

   var ajax = new ActiveXObject("Microsoft.XMLHTTP");

}





ajax.upload.addEventListener('progress', progressHandle, false);

ajax.addEventListener('load', completeHandle, false);

ajax.addEventListener('error', errorHandle, false);

ajax.addEventListener('abort', abortHandle, false);

ajax.open("POST", "update_post_server.php");

ajax.send(formdata);









}





function progressHandle(event){



    _('loaded').innerHTML = "uploaded " + event.loaded + "bytes of " + event.total;



var percent = (event.loaded / event.total) * 100;



_('progressbar').value = Math.round(percent);

_('status').innerHTML = Math.round(percent) + "% upload... please wait";





}



function completeHandle(event){



_('status').innerHTML = event.target.responseText;



_('progressbar').value = 0;



}



function errorHandle(event){



_('status').innerHTML = "upload failed";







}



function abortHandle(event){



_('status').innerHTML = "upload aborted";







}



    
    
    
    
</script>


<style>
    
      .input-container{
          
             box-shadow:0px 2px 2px 0px rgb(240,240,240);
      }
    
</style>

   
           <script>
           
           
           
               
                     $('#ddd').click(function(){
                         
                         
                              $('.boot').slideDown('fast');
                              $('.boot').animate({left:"31%",top:"28%"},"fast");
                              
                              
                             
                     });
                  
           </script>

</body>

</html>