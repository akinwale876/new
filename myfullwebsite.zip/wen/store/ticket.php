<!DOCtype
 html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Welcome to Store</title>

<?php


include "head.php";

?>


<meta name="description" content="Naijaramz store provides you post ticket" />

<meta http-equiv="x-ua-compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no " />
<link rel="canonical" href="https://naijaramz.com"  />



</head>


<body>


<?php

include "header.php";

?>

<center><h2>ticket</h2></center>
<div class="wrapper" style="background:black;color:white;">



   <a href="buy_ticket.php">Buy ticket</a>
   
   <br>
   <br>
   <br>
   
   <h2>List of ticket price</h2>

<div class="main">
   <table>
       
       
       <tr>
           
           <th>Amount</th>
           <th>point</th>
      
           <th>Number of post</th>
           
       </tr>
       
       <tr>
           
           <td>1,000</td>
           <td>1.0</td>
           <td>1 post</td>
           
       </tr>
       <tr>
           
           <td>2,000</td>
           <td>2.0</td>
                      <td>2 post</td>

           
       </tr>
       <tr>
           
           <td>3,000</td>
           <td>3.0</td>
                      <td>3 post</td>

       </tr>
       
       
       
   </table>


</div>


<style>


body, a{
    
        font-family:Montserrat;

}



.main{
    
    background:black;
    color:white;
    
    font-size:25px;
    font-family:Montserrat;
}
    
    
    table{
                padding:8px;
                width:100%;
                

        
        
    }
    
    tr{
        
        background:rgb(10,10,10);
    }
    
    tr:nth-child(even){
        
        background:rgb(20,20,20);
    }
    
    
    th{
        
        padding:8px;
        
    }
    
    td{
        
                padding:8px;

    }
    
    
</style>







</div>


<?php

include "footer.php";

?>


<style>
    h5{
        
        margin-left:10px;
    }
    
    hr{
        
        border:none;
    }
    
    
    
</style>





</body>

</html>