

<div class="header"  id="nav">

<div style="display: none;">
  
  <?php

session_start();



?>
</div>


<div class="left-header" style="position:relative;">
    
    
    

<a href="https://<?php echo $_SERVER['SERVER_NAME']?>"><div class="header-image" 
>  

<h1 class="headme" style="font-size: 38px;">ZiFXTrade<span style="font-size: 20px;color:red;">.com</span></h1>


</div>

</a>  
<span class="hideme" style="margin-left:230px;font-size: 10px;">ZiFX is an easy trading website you can earn fast with brokers</span>
 


</div>




<label style="font-size:12px;position:absolute;top:5px;right:5px;">

   <i class="fa fa-clock"></i>

<span id="ttt"></span>

   <script>



setInterval(function(){



 date = new Date();

 var year = date.getFullYear();
 var months = date.getMonth();
 var day = date.getDay();

 var seconds = date.getSeconds();
 var minutes = date.getMinutes();
 var hours = date.getHours();


var realTime = hours + 'h : '+ minutes + 'm : '+ seconds + 's ';


document.getElementById('ttt').innerHTML = realTime;


},1000);



</script>

 </label>



<span  style="margin-right:20px;float:right;">
<span style="color:black;font-family:cursive;margin-top:-7px;font-size:11px;:28px;">
	
Connect</span>
<a target="blank" href="https://www.facebook.com/naijaramz" style="border-radius:50%;display:inline-block;background:rgb(10,10,160);padding:9px;font-size: 10px;color: white;line-height: 5px;font-weight:bold;">f</a>
<a target="blank" href="https://www.twitter.com/naija_ramz" style="border-radius:50%;display:inline-block;background:rgb(30,30,180);padding:9px;font-size: 10px;font-weight:bold;color: white;line-height: 5px;">t</a>

</span>

<br>

<br>




    <nav style="box-shadow: none;outline: none;" ><ul class="ul-list" id="nn">


    <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/" title="" style="position:relative;text-indent:10px;font-weight:100;">Home

        </a>

        </li>
         
<li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/coin.php?coin=Zicoin" style="display: block;font-weight:100;">Zicoin</a>

</li>       
<li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/coin.php?coin=Bitcoin" style="display: block;font-weight:100;">Bitcoin</a>

</li>
        
    <li>
              <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/coin.php?coin=BNB" style="display: block;font-weight:100;">Binance BNB</a>

        
    </li>
    
      
    <li>

      
       
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/coin.php?coin=Ethereum" style="display: block;font-weight:100;">Ethereum</a>
      


        </li> 
    
       <li>
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/coin.php?coin=Smart Chain" style="display: block;font-weight:100;">Smart Chain</a>

</li>
         
         <li>
         
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/coin.php?coin=XRP" style="display: block;font-weight:100;">XRP</a>  

        </li>

   
      <span style="margin-left:150px ;"> <li>
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/about.php" style="background:rgb(100,100,100);color:white;display: block;font-weight:500;font-size: 10px;">Read about us</a>

</li>

<?php


if(isset($_SESSION['access'])){

    echo '      <li>
      <a href="https://'. $_SERVER["HTTP_HOST"]. '/myaccount" style="display: block;font-weight:500;font-size: 10px;">My wallet</a>

</li>';
}else{

  echo '
      <li>
      <a href="https://' . $_SERVER['HTTP_HOST'] .'/login.php" style="display: block;font-weight:500;font-size: 10px;">Login</a>

</li>
       <li>
      <a href="https://'. $_SERVER['HTTP_HOST'] . '/author-reg.php" style="display: block;font-weight:500;font-size: 10px;">Open An Account</a>

</li>';
}

?>


      </span>

        
   <!-- <li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/News" title="latest news informations" style="position:relative;text-indent:10px;font-weight:100;">News</a>

        
    </li>
 

    <li style="position:relative;color:rgb(20,120,50);font-weight:100;">

        
  
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/howto.php" style="display: block;font-weight:100;">
        How to</a>
       
  

        </li>

    
 <li>
        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/category/Sport" title="businesw" style="position:relative;text-indent:10px;font-weight:100;">Sports</a>

        
    </li>   -->
 



   

        </li>
        
      

  
 <!--   <li>
  <li>

<a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/forum.php" style="position:relative;text-indent:10px;font-weight:100;"
title="Ask question" >Gists Zone
        
        
        
        </a>

 </li>-->

 <!--   <li>

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/articles.php" style="position:relative;text-indent:10px;font-weight:100;">
       Articles</a>
</li>



<li>
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Emovie.php" style="display: block;font-weight:100;">English  Movies</a>

</li>


-->



 <!--   <li>

    <li class="dropdown" style="position:relative;color:rgb(20,120,50);font-weight:100;">
 Movies &#9774;
        
        
       <span class="sit" id="dropdown-content">
  
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Emovie.php" style="display: block;font-weight:100;">English  Movies</a>
      <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/Hmovie.php" style="display: block;font-weight:100;">Hollywood  Movies</a>
       

        <a href="https://<?php echo $_SERVER['HTTP_HOST'] ?>/movie.php" style="display: block;font-weight:100;">Yoruba Movies</a>



     </span>
        
  

        </li>
        -->
      


    


    <li>

        <a id="menu" class="menu" href="javascript:void(0);">
       &#9776;</a>
</li>
   



    </ul>


<script type="text/javascript">
	

var xN = 0;

$(document).ready(function(){


var ul = $('#nn');






$('#menu').click(function(){

           if(xN == 0){
xN = 1;
		   ul.css('height', 'auto')
		}else{
			xN = 0;
			ul.css('height', '35px')
		}


})


})

</script>



</nav>










    </div>