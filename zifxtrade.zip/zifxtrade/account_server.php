<?php

require 'connection.php';


if ($_GET['q']) {
	
 $q  = $_GET['q'];



$query = mysqli_query($conn,"SELECT * FROM `customers` WHERE `account_number`= '$q' LIMIT 1");


if(mysqli_num_rows($query) == 1){


  $data = mysqli_fetch_array($query);


    $account_name = $data['first_name'];

echo '<span style="color:black;">' . $account_name. '</span>';

}else{


    echo '<span style="color:red;font-size:9px;">Acct not fund</span>';

}


}

?>