<?php



require 'connection.php';


$errors = [];



if (isset($_GET['email'])) {
	

	$email = $_GET['email'];
}


if (isset($_GET['token'])) {
	

	$token = $_GET['token'];
}


if (isset($_GET['code'])) {
	

	$code = $_GET['code'];
}

if (isset($_GET['password'])) {
	

	$password = $_GET['password'];
$password = md5($password);
}




if(empty($errors)){

$query = mysqli_query($conn, "SELECT * FROM `customers` WHERE  `email` = '$email' LIMIT 1");




if (mysqli_num_rows($query) == 1) {
	

if(mysqli_query($conn, "UPDATE `customers` SET `password` = '$password' WHERE  `email` = '$email' LIMIT 1")){


	echo '<p style="color:green;">Password changed</p>';
}else{
	echo '<p style="color:red;">Password changed fail</p>';


}



}


}else{


   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }



}






?>