<!DOCTYPE html>
<html>
<head>
	<title>Our Support</title>

<?php

include 'head.php';







?>

</head>
<body>



    
<div id="supportcontainer" style="position: fixed;left:5%;top:10px;background:white;width:340px;height:500px;overflow:hidden;box-shadow: 0px 3px 3px 0px gray;border-radius:0px 12px">
	


	<div style="background:rgb(230, 61, 103);color: white;position: relative;padding: 15px;"><h5 style="display: inline-block;margin: 5px;">Our Support</h5>
		
	</div>




<div>
	

<div style="padding: 14px;">

<div style="margin:0 10px;font-size: 13px;font-family: monospace;">reach us here our live specialist will attend to you</div>

</div>



<br>


<div style="padding: 12px;">
	<img src="https://slasafe.godsso.xyz/user.png"  style="width:35px;height:35px;border-radius:50%;float: left;font-size: 30px;">


</div>





</div>


    <div id="mainmessage" style="width: 320px;height:160px;padding: 5px;position: relative;overflow: auto;">
    	


    </div>



<div style="width:98%;position: absolute;padding: 8px;bottom: 0;background: rgb(240,240,240);">

<form id="fform" action="/" method="" onsubmit="return false;">
	
<input type="text" id="mailmessage" style="border: none;outline: none;background: rgb(240,240,240);" placeholder="Reply a Message">

<button id="ssmail" style="display:inline-block;margin-left:27px;font-size:13px;cursor:pointer;border: none;outline: none;color:rgb(103, 61, 230);font-weight: 800;"><i style="display: inline-block;" class="fas fa-paper-plane"></i></button>

<input type="hidden" value="
<?php

echo $_GET['user'];

?>"  id="get">

</form>

<script type="text/javascript">
	

       $("#ssmail").click(function(){

           

           var input = $("#mailmessage").val();
           var user = $("#get").val();


           $.post("supportcontactus.php",{message:input,user:user}, function(data){
                         

            $("#mainmessage").html(data);
  });  


        
         $("#fform").trigger('reset');
  
              

       });

</script>




<script type="text/javascript">
	
  	var vv = $('#get');


	 $.get("guestdata.php?user=" +vv, function(data){
    
         	$('#talk').html(data);


  });
     


</script>


</div>










</div>









</body>
</html>