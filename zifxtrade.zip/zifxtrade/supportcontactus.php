<?php


require 'connection.php';

include 'admin_init.php';


  $array_home = [];


if(isset($_POST['message'])){




$message = $_POST['message'];

$message  = '<p style="text-align:left;">'. $message. '</p>';

$cookie = $_POST['user'];

$date = time();

$query = mysqli_query($conn,"INSERT INTO `contact` (`cookie_value`,`message`,`date`) VALUE('$cookie','$message','$date')");


  $newQ = mysqli_query($conn,"SELECT * FROM `contact` WHERE `cookie_value` = '$cookie' ORDER BY id DESC LIMIT 4");




  while ($arr = mysqli_fetch_array($newQ)) {
  
  $arr_message = $arr['message'];


  array_push($array_home,'<div style="display:block;font-size:13px;font-family:monospace;background:none;">'.$arr_message.'</div>');



  }


$n_array = array_reverse($array_home);


foreach($n_array as $value) {

     echo $value;

	}



}



?>