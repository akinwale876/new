<?php

require 'connection.php';







$errors = array();


if($conn){


    echo '<span style="color:green;font-size:9px;">connected</span>';
}










if(isset($_POST['email'])){

    if(!empty($_POST['email'])){


if(strlen($_POST['email']) > 3){


$email = $_POST['email'];


}else{

    array_push($errors, '<span style="color:red;">email length must be greater than 100 characters</span>');


}















    }else{
    array_push($errors, '<span style="color:red;">Please Enter Email</span>');


    }







}
else{

    array_push($errors, 'email is required');
}










if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);





$token =  '903i'. uniqid() ;


$ip = $_SERVER['REMOTE_ADDR'];



$code = uniqid();




$query =mysqli_query($conn,"INSERT INTO `verification` ( `email`, `ip`, `token`, `code`, `date`)
 VALUES ('$email','$ip','$token','$code','$date')");




if($query){

$to = $email;
$subject = "Reset Password";

$message ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>Reset Password ...</title>



</head>
<body>

<h2>Dear '.$email.' </h2>

<p>Please reset password by clicking the following link </p>
<div style="padding:30px;">


<a style="margin:30px;padding:10px;border:0.3px solid rgb(40,100,40);" href="https://zifxtrade.online/verify.php?token='.$token.'&code='.$code.'&email='.$email.'">Reset Password</a>

<div>
</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From:Reset Password zifx Support@zifxtrade.online' . "\r\n";
$headers .= 'Cc:Reset Password zifx Support@zifxtrade.online' . "\r\n";

if(mail($to,$subject,$message,$headers)){
echo 'mail sent';

}










}else{
    
echo '<p style="color:red;">Registration failed please try again later</p>';


}





}else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}




?>