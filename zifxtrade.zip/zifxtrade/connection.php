<?php

$conn = new mysqli('localhost','u436011667_root','U2Ja09p+:k4','u436011667_website');

?>