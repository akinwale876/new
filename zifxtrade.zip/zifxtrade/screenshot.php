<?php

$errors = [];

if(isset($_FILES['file'])){

$file_name = $_FILES['file']['name'];
$file_size = $_FILES['file']['size'];
$file_type = $_FILES['file']['type'];
$file_tmp = $_FILES['file']['tmp_name'];


$extensions = array('jpg','png','jpeg');

$extract  = explode('.',$file_name);

$get_ext = end($extract);

if(!in_array($get_ext, $extensions)){


array_push($errors, '<span style="color:red;">extension not allowed</span>');
}
    


if($file_size > 2000000){


array_push($errors, '<span style="color:red;">file size must be 200000 bytes or less</span>');


}




if(move_uploaded_file($file_tmp, 'images/' . $file_name)){
    
$pic_url = 'images/' . $file_name;

}



}else{

    array_push($errors, '<span style="color:red;">please select file</span>');

}




$userid = $_POST['userid'];





$to = 'support@zifxtrade.online';

$subject = 'New screenshot';

$messages ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>New screenshot</title>



</head>
<body>

<h2>Client Payment Screenshot</h2>


<center><img src="https://zifxtrade.online/'. $pic_url .'" style="width:400px;height:500px;margin:40px;"></center>


<br><b> Zicoin addr is: '. $userid .'</b>



</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: Screenshot support@zifxtrade.online' . "\r\n";
$headers .= 'Cc: Screenshot support@zifxtrade.online' . "\r\n";

if(mail($to,$subject,$messages,$headers)){


echo '<h1 style="font-size:70px;">Sent </h1>';


}






?>