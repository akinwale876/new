<?php


require 'connection.php';

include 'admin_init.php';


  $array_home = [];


if(isset($_POST['message'])){




$message = $_POST['message'];

$message  = '<p style="text-align:right;">'. $message. '</p>';


if(isset($_COOKIE['user'])){


$cookie = $_COOKIE['user'];

$date = time();


mysqli_query($conn,"INSERT INTO `contact` (`cookie_value`,`message`,`date`) VALUE('$cookie','$message','$date')");


  $ne = mysqli_query($conn,"SELECT * FROM `contact` WHERE `cookie_value` = '$cookie' ORDER BY id DESC");


  while ($arrr = mysqli_fetch_array($ne)) {
  
  $arr_message = $arrr['message'];


  array_push($array_home,'<div style="display:block;font-family:monospace;background:none;">'.$arr_message.'</div>');


  }


$n_array = array_reverse($array_home);


foreach($n_array as $value) {

     echo $value;

	}







}else{

  
  $cookie  = 'User_' . uniqid();


   setcookie('user', $cookie, time() + (86400 * 30), "/");

    

$date = time();

 mysqli_query($conn,"INSERT INTO `contact` (`cookie_value`,`message`,`date`) VALUE('$cookie','$message','$date')");


  $newQ = mysqli_query($conn,"SELECT * FROM `contact` WHERE `cookie_value` = '$cookie' ORDER BY id DESC LIMIT 4");


  while ($arr = mysqli_fetch_array($newQ)) {
  
  $arr_message = $arr['message'];


  array_push($array_home,'<div style="display:block;font-family:monospace;background:none;">'.$arr_message.'</div>');


  }


$n_array = array_reverse($array_home);


foreach($n_array as $value) {

     echo $value;

  }


if (isset($email)) {
  
  $email = $email;
}

$to = 'support@zifxtrade.online';

$subject = 'online guest';

$messages ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>New Guest </title>



</head>
<body>

<h2>Dear Official </h2>


<p>'.$email.': '.$message.'</p>

<a href="https://zifxtrade.online/adminlive.php?user='.$cookie.'">follow this to respond</a>

</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: User Guest support@zifxtrade.online' . "\r\n";
$headers .= 'Cc: User Guest support@zifxtrade.online' . "\r\n";

if(mail($to,$subject,$messages,$headers)){


}







}







}



?>