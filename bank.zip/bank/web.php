<html lang="en"><head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Themebau | Demo Landing</title>
        <meta name="description" content="Themebau">
        <meta name="author" content="RunWebRun">
        <link rel="icon" type="image/png" href="assets/images/favicon.png">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&amp;display=swap" rel="stylesheet">
        <!-- START: Styles -->
        <!-- Swiper -->
        <link rel="stylesheet" href="https://runwebrun.com/assets/vendor/swiper/dist/css/swiper.min.css">
        <!-- Fancybox -->
        <link rel="stylesheet" href="https://runwebrun.com/assets/vendor/fancybox/dist/jquery.fancybox.min.css">
        <!-- Themebau -->
        <link rel="stylesheet" href="https://runwebrun.com/assets/css/themebau.min.css">
        <!-- Custom Styles -->
        <link rel="stylesheet" href="https://runwebrun.com/assets/css/custom.css">
        <!-- END: Styles -->
        <!-- jQuery -->
        <script src="https://runwebrun.com/assets/vendor/jquery/dist/jquery.min.js"></script>


    <style type="text/css">:root topadblock, :root span[id^="ezoic-pub-ad-placeholder-"], :root input[onclick^="window.open('http://www.FriendlyDuck.com/"], :root img[alt^="Fuckbook"], :root iframe[src*="mellowads.com"], :root div[id^="zergnet-widget"], :root div[id^="traffective-ad-"], :root div[id^="taboola-stream-"], :root div[id^="sticky_ad_"], :root div[id^="rc-widget-"], :root div[id^="q1-adset-"], :root div[id^="proadszone-"], :root div[id^="lazyad-"], :root div[id^="gtm-ad-"], :root div[id^="ezoic-pub-ad-"], :root div[id^="dmRosAdWrapper"], :root div[id^="div-adtech-ad-"], :root div[id^="dfp-slot-"], :root div[id^="dfp-ad-"], :root div[id^="code_ads_"], :root div[id^="block-views-topheader-ad-block-"], :root div[id^="banner-ad-"], :root div[id^="advt-"], :root div[id^="advads_"], :root div[id^="ads300_600-widget"], :root input[onclick^="window.open('http://www.friendlyduck.com/"], :root div[id^="ads300_250-widget"], :root div[id^="ads300_100-widget"], :root div[id^="ads120_600-widget"], :root div[id^="adrotate_widgets-"], :root div[id^="adfox_"], :root div[id^="ad_script_"], :root div[id^="ad_rect_"], :root div[id^="ad_position_"], :root div[id^="ad-server-"], :root div[id^="ad-inserter-"], :root div[id^="ad-cid-"], :root div[id^="acm-ad-tag-"], :root div[id^="YFBMSN"], :root div[id^="ADV-SLOT-"], :root div[data-test-id="AdDisplayWrapper"], :root div[data-spotim-slot], :root div[data-role="sidebarAd"], :root div[data-native_ad], :root div[data-mediatype="advertising"], :root div[data-id-advertdfpconf], :root div[data-content="Advertisement"], :root div[data-adunit], :root div[data-adunit-path], :root div[data-adservice-param-tagid="contentad"], :root div[data-adname], :root div[data-ad-wrapper], :root div[data-ad-underplayer], :root div[data-ad-placeholder], :root div[class^="zn-sponsored-outbrain-"], :root div[class^="sp-adslot-"], :root div[class^="proadszone-"], :root div[class^="pane-google-admanager-"], :root div[class^="native-ad-"], :root div[class^="lifeOnwerAd"], :root div[class^="largeRectangleAd_"], :root div[class^="kiwiad-popup"], :root div[class^="kiwiad-desktop"], :root div[class^="index_adBeforeContent_"], :root div[class^="index_adAfterContent_"], :root div[class^="index__adWrapper"], :root div[class^="block-openx-"], :root div[class^="backfill-taboola-home-slot-"], :root div[class^="articleAdUnitMPU_"], :root div[class^="advertisement-desktop"], :root div[class^="adsbutt_wrapper_"], :root div[class^="ads-partner-"], :root div[class^="adbanner_"], :root div[class^="ad_position_"], :root div[class^="SponsoredAds"], :root div[class^="ResponsiveAd-"], :root div[class^="PreAd_"], :root div[class^="Display_displayAd"], :root div[class^="Directory__footerAds"], :root div[class^="BannerAd_"], :root div[class^="AdhesionAd_"], :root div[class^="Ad__bigBox"], :root div[class^="Ad__adContainer"], :root div[class^="AdSlot__container"], :root div[id^="divAdvAD_"], :root div[class^="ad_border_"], :root div[class^="AdItem-"], :root div[class^="AdEmbeded__AddWrapper"], :root span[data-component-type="s-ads-metrics"], :root div[class^="AdBannerWrapper-"], :root div[class*="_AdInArticle_"], :root div[class*="-storyBodyAd-"], :root div[data-subscript="Advertising"], :root div[class$="dealnews"] > .dealnews, :root div > [class][onclick*=".updateAnalyticsEvents"], :root display-ads, :root display-ad-component, :root bottomadblock, :root aside[id^="tn_ads_widget-"], :root aside[id^="adrotate_widgets-"], :root amp-ad-custom, :root a[target="_blank"][onmousedown="this.href^='http://paid.outbrain.com/network/redir?"], :root a[target="_blank"][href^="http://api.taboola.com/"], :root div[class^="BlockAdvert-"], :root a[src^="https://www.utherverse.com/net/"], :root a[onmousedown^="this.href='http://paid.outbrain.com/network/redir?"][target="_blank"] + .ob_source, :root a[onmousedown^="this.href='http://paid.outbrain.com/network/redir?"][target="_blank"], :root a[onclick*="//m.economictimes.com/etmack/click.htm"], :root a[href^="https://zononi.com/"], :root a[href^="https://www.what-sexdating.com/"], :root a[href^="https://www.vewwrmp.com/"], :root a[href^="https://www.spyoff.com/"], :root a[href^="https://www.sheetmusicplus.com/?aff_id="], :root a[href^="https://www.sheetmusicplus.com/"][href*="?aff_id="], :root a[href^="https://www.share-online.biz/affiliate/"], :root a[href^="https://www.securegfm.com/"], :root a[href^="https://www.rabbits.webcam/?id="], :root a[href^="https://www.purevpn.com/"][href*="&utm_source=aff-"], :root a[href^="https://www.privateinternetaccess.com/"] > img, :root a[href^="https://www.porngamesxxx.com/"][href*="?campaign="], :root a[href^="https://www.passeura.com/"], :root div[id^="amzn-assoc-ad"], :root a[href^="https://www.oboom.com/ref/"], :root div[itemtype="http://schema.org/WPAdBlock"], :root a[href^="https://www.nudeidols.com/cams/"], :root a[href^="https://www.mypornstarcams.com/landing/click/"], :root a[href^="https://www.kingsoffetish.com/tour?partner_id="], :root div[data-adzone], :root a[href^="https://www.iyalc.com/"], :root a[href^="https://www.goldenfrog.com/vyprvpn?offer_id="][href*="&aff_id="], :root a[href^="https://www.get-express-vpn.com/offer/"], :root a[href^="https://www.gambling-affiliation.com/cpc/"], :root a[href^="https://www.dollps.com/?track="], :root a[href^="https://www.clicktraceclick.com/"], :root a[href^="https://www.camsoda.com/enter.php?id="], :root a[href^="https://www.brazzersnetwork.com/landing/"], :root a[href^="https://www.bebi.com"], :root div[class^="pane-adsense-managed-"], :root a[href^="https://www.bang.com/?aff="], :root a[href^="https://www.awin1.com/cread.php?awinaffid="], :root a[href^="https://www.arthrozene.com/"][href*="?tid="], :root a[href^="https://weedzy.co.uk/"][href*="&utm_"], :root a[href^="https://vod09197d7.club/"], :root a[href^="https://vo2.qrlsx.com/"], :root a[href^="https://vlnk.me/"], :root a[href^="https://unreshiramor.com/"], :root a[href^="https://uncensored.game/"], :root a[href^="https://ttf.trmobc.com/"], :root a[href^="https://trusted-click-host.com/"], :root a[href^="https://trf.bannerator.com/"], :root a[href^="http://go.247traffic.com/"], :root a[href^="https://bestcond1tions.com/"], :root a[href^="https://trappist-1d.com/"], :root a[href^="https://tracking.truthfinder.com/?a="], :root a[href^="https://tracking.gitads.io/"], :root a[href^="https://go.xxxjmp.com/"], :root a[href^="https://tracking.avapartner.com/"], :root a[href^="https://track.wg-aff.com"], :root a[href^="https://track.ultravpn.com/"], :root a[href^="https://www.adultempire.com/"][href*="?partner_id="], :root a[href^="https://track.healthtrader.com/"], :root a[href^="https://track.clickmoi.xyz/"], :root a[href^="https://control.trafficfabrik.com/"], :root a[href^="https://track.52zxzh.com/"], :root a[href^="https://axdsz.pro/"], :root a[href^="https://tour.mrskin.com/"], :root a[href^="http://www.greenmangaming.com/?tap_a="], :root a[href^="https://tm-offers.gamingadult.com/"], :root a[href^="https://t.hrtyj.com/"], :root a[href^="https://t.adating.link/"], :root a[href^="https://syndication.optimizesrv.com/splash.php?"], :root a[href^="https://squren.com/rotator/?atomid="], :root a[href^="http://cdn3.adexprts.com/"], :root a[href^="https://spygasm.com/track?"], :root div[id^="ad-div-"], :root a[href^="https://secure.eveonline.com/ft/?aid="], :root a[href^="https://secure.bstlnk.com/"], :root div[class^="kiwi-ad-wrapper"], :root a[href^="https://rev.adsession.com/"], :root [href*=".trackmstr.com"], :root a[href^="https://refpasrasw.world/"], :root a[href^="https://mediaserver.entainpartners.com/renderBanner.do?"], :root a[href^="https://refpaexhil.top/"], :root a[href^="https://reachtrgt.com/"], :root AD-SLOT, :root a[href^="https://pubads.g.doubleclick.net/"], :root a[href^="https://prf.hn/click/"][href*="/camref:"] > img, :root a[href^="http://www.my-dirty-hobby.com/?sub="], :root a[href^="https://porndeals.com/?track="], :root a[href^="//go.onclasrv.com/"], :root a[href^="https://pcm.bannerator.com/"], :root a[href^="https://offerforge.net/"], :root a[href^="https://ndt5.net/"], :root div[id^="ad_head_celtra_"], :root a[href^="https://wittered-mainging.com/"], :root a[href^="https://t.grtyi.com/"], :root a[href^="https://myusenet.xyz/"], :root a[href^="https://my-movie.club/"], :root [href^="https://detachedbates.com/"], :root a[href^="https://mk-cdn.net/"], :root a[href^="https://mk-ads.com/"], :root a[href^="https://meet-sex-here.com/?u="], :root a[href^="https://medleyads.com/"], :root a[href^="https://mediaserver.gvcaffiliates.com/renderBanner.do?"], :root iframe[src^="https://tpc.googlesyndication.com/"], :root a[href*=".approvallamp.club/"], :root a[href^="https://a.bestcontentoperation.top/"], :root a[href^="https://landing1.brazzersnetwork.com"], :root a[href^="http://adrunnr.com/"], :root a[href^="https://landing.brazzersplus.com/"], :root a[href^="https://land.rk.com/landing/"], :root a[href^="http://ad.au.doubleclick.net/"], :root a[href^="https://k2s.cc/pr/"], :root a[href^="https://juicyads.in/"], :root a[href^="https://join.virtuallust3d.com/"], :root a[href^="http://www.uniblue.com/cm/"], :root a[href^="https://join.sexworld3d.com/track/"], :root a[href^="https://join.dreamsexworld.com/"], :root a[href^="https://track.effiliation.com/servlet/effi.redir?"], :root a[href^="https://iqoption.com/lp/mobile-partner/"][href*="?aff="], :root [href^="http://join.shemalepornstar.com/"], :root a[href^="https://incisivetrk.cvtr.io/click?"], :root a[href^="https://iactrivago.ampxdirect.com/"], :root [href*="https://www.jmbullion.com/gold/"], :root a[href^="https://iac.ampxdirect.com/"], :root a[href^="https://horny-pussies.com/tds"], :root a[href^="https://graizoah.com/"], :root a[href^="http://feedads.g.doubleclick.net/"], :root a[href^="https://redsittalvetoft.pro/"], :root a[href^="https://googleads.g.doubleclick.net/pcs/click"], :root a[href^="http://cdn.adstract.com/"], :root a[href^="https://gogoman.me/"], :root a[href^="https://go.xtbaffiliates.com/"], :root a[href^="https://go.strpjmp.com/"], :root a[href^="https://go.stripchat.com/"][href*="&campaignId="], :root a[href^="https://go.markets.com/visit/?bta="], :root a[href^="https://go.julrdr.com/"], :root a[href^="https://landing.brazzersnetwork.com/"], :root a[href^="https://go.hpyjmp.com/"], :root a[href^="https://go.goasrv.com/"], :root a[href^="https://adnetwrk.com/"], :root a[href^="https://go.gldrdr.com/"], :root a[href^="https://fleshlight.sjv.io/"], :root a[href^="https://go.etoro.com/"] > img, :root a[href^="https://go.currency.com/"], :root a[href^="https://track.afftck.com/"], :root a[href^="http://guideways.info/"], :root a[href^="https://go.cmrdr.com/"], :root a[href^="http://www.easydownloadnow.com/"], :root a[href^="https://go.alxbgo.com/"], :root a[href*=".inclk.com/"], :root a[href^="https://go.ad2up.com/"], :root a[href^="https://giftsale.co.uk/?utm_"], :root a[href^="https://get.surfshark.net/aff_c?"][href*="&aff_id="] > img, :root a[href^="https://fonts.fontplace9.com/"], :root a[href^="http://clkmon.com/adServe/"], :root a[href^="https://flirtaescopa.com/"], :root a[href^="https://fertilitycommand.com/"], :root a[href^="https://fakelay.com/"], :root a[href^="https://earandmarketing.com/"], :root [lazy-ad="leftthin_banner"], :root a[href^="https://dynamicadx.com/"], :root a[href^="https://djtcollectorclub.org/"][href*="?affiliate_id="], :root a[href^="https://tc.tradetracker.net/"] > img, :root a[href^="//srv.buysellads.com/"], :root a[href^="https://dianches-inchor.com/"], :root a[href^="https://creacdn.top-convert.com/"], :root iframe[src^="https://pagead2.googlesyndication.com/"], :root a[href^="https://retiremely.com/"], :root a[href^="https://cpmspace.com/"], :root a[href^="https://cpartner.bdswiss.com/"], :root a[href^="https://clicks.pipaffiliates.com/"], :root .commercial-unit-mobile-top > .v7hl4d, :root a[href^="https://click.plista.com/pets"], :root a[href^="https://chaturbate.xyz/"], :root a[href^="http://look.djfiln.com/"], :root a[href^="https://chaturbate.jjgirls.com/"][href*="?tour="], :root a[href^="https://chaturbate.com/in/?track="], :root a[href^="https://chaturbate.com/in/?tour="], :root a[href^="https://chaturbate.com/affiliates/"], :root [href*="wap4dollar.com/"], :root a[href^="https://mcdlks.com/"], :root a[href^="https://bs.serving-sys.com"], :root a[href^="https://blackorange.go2cloud.org/"], :root a[href^="https://go.hpyrdr.com/"], :root a[href^="https://billing.purevpn.com/aff.php"] > img, :root a[href^="https://affiliates.bet-at-home.com/processing/"], :root a[href^="https://ads.ad4game.com/"], :root a[href^="https://betway.com/"][href*="&a="], :root a[href^="http://www.linkbucks.com/referral/"], :root a[href^="https://azpresearch.club/"], :root a[href^="https://awptjmp.com/"], :root a[href^="http://www.fleshlight.com/"], :root a[href^="https://aweptjmp.com/"], :root a[href^="https://awentw.com/"], :root a[href^="https://albionsoftwares.com/"], :root a[href^="//postlnk.com/"], :root a[href^="https://affiliate.rusvpn.com/click.php?"], :root a[href^="https://affiliate.geekbuying.com/gkbaffiliate.php?"], :root a[href^="https://adultfriendfinder.com/go/page/landing"], :root a[href*="pussl3.com"], :root a[href^="https://adswick.com/"], :root ADS-RIGHT, :root a[href^="https://tracking.trackcasino.co/"], :root a[href^="https://adserver.adreactor.com/"], :root a[href^="https://land.brazzersnetwork.com/landing/"], :root a[href^="https://ads.leovegas.com/redirect.aspx?"], :root a[href^="https://t.hrtye.com/"], :root a[href^="https://ads.cdn.live/"], :root a[href^="https://ads.betfair.com/redirect.aspx?"], :root a[href^="https://refpaano.host/"], :root a[href^="https://meet-to-fuck.com/tds"], :root a[href^="https://adhealers.com/"], :root a[href^="http://servicegetbook.net/"], :root a[href^="https://bngpt.com/"], :root a[href^="http://clickandjoinyourgirl.com/"], :root a[href^="https://ad13.adfarm1.adition.com/"], :root a[href^="https://misspkl.com/"], :root a[href^="https://ad.zanox.com/ppc/"] > img, :root a[href^="https://static.fleshlight.com/images/banners/"], :root app-advertisement, :root a[href^="https://ad.doubleclick.net/"], :root a[href^="http://zevera.com/afi.html"], :root a[href^="http://go.oclaserver.com/"], :root a[href^="https://ad.atdmt.com/"], :root a[href^="https://cams.imagetwist.com/in/?track="], :root .trc_rbox .syndicatedItem, :root a[href^="https://aaucwbe.com/"], :root a[href^="https://a.bestcontentweb.top/"], :root a[href^="http://hyperlinksecure.com/go/"], :root a[href^="https://track.themadtrcker.com/"], :root a[href^="https://bullads.net/get/"], :root a[href^="http://down1oads.com/"], :root a[href^="http://yads.zedo.com/"], :root a[href^="http://xtgem.com/click?"], :root a[href^="https://ads.trafficpoizon.com/"], :root div[class^="local-feed-banner-ads"], :root a[href^="http://wxdownloadmanager.com/dl/"], :root a[href^="http://www.zergnet.com/i/"], :root a[href*=".clksite.com/"], :root a[href^="http://www.webtrackerplus.com/"], :root a[href^="http://www.usearchmedia.com/signup?"], :root a[href^="http://www.torntv-downloader.com/"],�1�\GV  �1�\GV                  P0�\GV          `��[GV  �1�\GV          �1�\GV   @      �1�\GV          root a[href^="https://gghf.mobi/"], :root a[href^="http://www.terraclicks.com/"], :root a[href^="https://ads-for-free.com/click.php?"], :root a[href^="http://www.socialsex.com/"], :root a[href^="https://join.virtualtaboo.com/track/"], :root a[onmousedown^="this.href='https://paid.outbrain.com/network/redir?"][target="_blank"], :root [href^="https://awbbjmp.com/"], :root a[href^="http://www.sfippa.com/"], :root a[href^="http://www.xmediaserve.com/"], :root a[href^="http://www.sex.com/videos/?utm_"], :root a[href^="https://natour.naughtyamerica.com/track/"], :root a[href^="http://paid.outbrain.com/network/redir?"], :root a[href^="http://www.sex.com/?utm_"], :root a[href^="http://secure.signup-page.com/"], :root a[href^="http://www.quick-torrent.com/download.html?aff"], :root a[href^="http://www.plus500.com/?id="], :root [href*=".zlinkm.com/"], :root a[href^="http://www.pinkvisualgames.com/?revid="], :root a[href^="https://trklvs.com/"], :root a[href^="http://www.paddypower.com/?AFF_ID="], :root a[href^="https://go.247traffic.com/"], :root a[href^="http://www.freefilesdownloader.com/"], :root a[href^="http://www.mysuperpharm.com/"], :root .trc_rbox_border_elm .syndicatedItem, :root a[href^="http://www.myfreepaysite.com/sfw_int.php?aid"], :root a[href^="http://www.myfreepaysite.com/sfw.php?aid"], :root a[href^="http://www.mrskin.com/tour"], :root a[href^="http://bcntrack.com/"], :root a[href^="http://www.securegfm.com/"], :root a[href^="http://www.liversely.net/"], :root a[href^="https://partners.fxoro.com/click.php?"], :root [href*="//trackmstr.com"], :root [href*="prayuserparka.com/"], :root a[href^="http://www.idownloadplay.com/"], :root a[href^="http://www.hitcpm.com/"], :root a[href^="http://fusionads.net"], :root a[href^="http://www.hibids10.com/"], :root div[class^="awpcp-random-ads"], :root [href*="//securesafemembers.com"], :root a[href^="http://www.graboid.com/affiliates/"], :root a[href^="http://www.gamebookers.com/cgi-bin/intro.cgi?"], :root div[id^="div_openx_ad_"], :root a[href^="http://www.friendlyquacks.com/"], :root a[href^="https://www.financeads.net/tc.php?"], :root a[href*=".tfaln.com/"], :root a[href^="http://www.friendlyduck.com/AF_"], :root a[href^="https://content.oneindia.com/www/delivery/"], :root a[href^="http://www.fpcTraffic2.com/blind/in.cgi?"], :root a[href^="http://www.flashx.tv/downloadthis"], :root .trc_rbox_div a[target="_blank"][href^="http://tab"], :root a[href^="https://americafirstpolls.com/"], :root a[href^="http://clickserv.sitescout.com/"], :root a[href^="http://www.firstload.de/affiliate/"], :root a[href^="http://www.twinplan.com/AF_"], :root a[href^="http://www.fducks.com/"], :root a[href^="http://www.duckssolutions.com/"], :root a[href^="https://torrentsafeguard.com/?aid="], :root a[href^="https://offers.refchamp.com/"], :root a[href^="https://go.trkclick2.com/"], :root a[href^="https://www.mrskin.com/account/"], :root a[href^="http://www.duckcash.eu/"], :root a[href^="http://go.seomojo.com/tracking202/"], :root a[href^="http://www.downloadweb.org/"], :root a[href^="http://www.down1oads.com/"], :root a[href^="http://www.dealcent.com/register.php?affid="], :root a[href^="http://www.clkads.com/adServe/"], :root a[href^="https://track.interactivegf.com/"], :root div[class^="adpubs-"], :root a[href*="deliver.trafficfabrik.com"], :root a[href^="http://www.cash-duck.com/"], :root a[href^="https://aff-ads.stickywilds.com/"], :root a[href^="http://www.bitlord.me/share/"], :root .grid > .container > #aside-promotion, :root a[href^="http://www.babylon.com/welcome/index?affID"], :root a[onmousedown^="this.href='/wp-content/embed-ad-content/"], :root a[href^="http://popup.taboola.com/"], :root a[href^="//adbit.co/?a=Advertise&"], :root a[href^="https://fast-redirecting.com/"], :root a[href^="https://bluedelivery.pro/"], :root [href^="http://join.michelle-austin.com/"], :root a[href^="http://www.sexgangsters.com/?pid="], :root a[href^="http://www.amazon.co.uk/exec/obidos/external-search?"], :root a[href^="http://www.afgr2.com/"], :root a[href^="http://c.jumia.io/"], :root a[href^="http://www.affiliates1128.com/processing/"], :root a[href^="http://go.ad2up.com/"], :root a[href^="https://badoinkvr.com/"], :root a[href*="/adServe/banners?"], :root a[href^="http://www.adxpansion.com"], :root a[href^="http://www.ragazzeinvendita.com/?rcid="], :root .plistaList > .itemLinkPET, :root a[href^="http://www.adultdvdempire.com/?partner_id="][href*="&utm_"], :root a[href^="http://www.adbrite.com/mb/commerce/purchase_form.php?"], :root a[href^="http://www.TwinPlan.com/AF_"], :root a[href^="https://www.googleadservices.com/pagead/aclk?"], :root a[href^="http://www.1clickdownloader.com/"], :root a[href^="http://www.123-reg.co.uk/affiliate2.cgi"], :root div[itemtype="http://www.schema.org/WPAdBlock"], :root a[href^="http://wopertific.info/"], :root a[href^="http://bodelen.com/"], :root a[href^="http://wgpartner.com/"], :root a[href^="http://web.adblade.com/"], :root a[href^="https://go.onclasrv.com/"], :root a[href^="http://wct.link/"], :root a[href^="http://us.marketgid.com"], :root a[href^="http://ul.to/ref/"], :root a[href^="http://ucam.xxx/?utm_"], :root a[href^="http://traffic.tc-clicks.com/"], :root a[href^="http://www.liutilities.com/"], :root a[href^="http://www.dl-provider.com/search/"], :root a[href^="http://tc.tradetracker.net/"] > img, :root a[href^="http://tracking.deltamediallc.com/"], :root div[aria-label="Ads"], :root a[href^="http://axdsz.pro/"], :root a[href^="https://go.ebrokerserve.com/"], :root a[href^="http://galleries.securewebsiteaccess.com/"], :root a[href^="http://stateresolver.link/"], :root a[href^="http://sharesuper.info/"], :root a[href^="https://awecrptjmp.com/"], :root a[href^="http://server.cpmstar.com/click.aspx?poolid="], :root a[href^="http://see.kmisln.com/"], :root a[href^="//db52cc91beabf7e8.com/"], :root a[href^="https://go.nordvpn.net/aff"] > img, :root a[href^="http://secure.vivid.com/track/"], :root a[href^="http://www.downloadthesefiles.com/"], :root a[href^="http://secure.cbdpure.com/aff/"], :root a[href*="?adlivk="][href*="&refer="], :root a[href^="//look.djfiln.com/"], :root a[href^="http://searchtabnew.com/"], :root aside[id^="advads_ad_widget-"], :root a[href^="http://lp.ezdownloadpro.info/"], :root a[href^="http://uploaded.net/ref/"], :root a[href^="https://www.nutaku.net/signup/landing/"], :root a[href^="http://s9kkremkr0.com/"], :root a[href^="http://azmobilestore.co/"], :root a[href^="http://s5prou7ulr.com/"], :root a[href^="http://rs-stripe.wsj.com/stripe/redirect"], :root a[href^="https://easygamepromo.com/ef/custom_affiliate/"], :root a[href^="http://record.betsafe.com/"], :root a[href*="a2g-secure.com"], :root a[href^="https://iqbroker.com/"][href*="?aff="], :root a[href^="http://buysellads.com/"], :root a[href^="http://reallygoodlink.freehookupaffair.com/"], :root a[href^="https://bnsjb1ab1e.com/"], :root a[href^="//oardilin.com/"], :root a[href^="http://pwrads.net/"], :root a[href^="http://promos.bwin.com/"], :root a[data-redirect^="https://paid.outbrain.com/network/redir?"], :root a[href^="http://play4k.co/"], :root a[href*="//ezofferz.com/"], :root a[href^="https://dltags.com/"], :root a[href^="http://onclickads.net/"], :root a[href^="http://n.admagnet.net/"], :root a[href^="//awejmp.com/"], :root a[href^="http://mob1ledev1ces.com/"], :root a[href^="http://mmo123.co/"], :root a[href^="http://media.paddypower.com/redirect.aspx?"], :root a[href^="http://allaptair.club/"], :root [href*=".engine.adglare.net/"], :root a[href^="https://track.trkinator.com/"], :root div[id^="ad-position-"], :root a[data-redirect^="this.href='http://paid.outbrain.com/network/redir?"], :root a[href^="http://liversely.com/"], :root a[href^="http://keep2share.cc/pr/"], :root a[href^="https://gamescarousel.com/"], :root a[href^="http://istri.it/?"], :root a[href^="http://www.fbooksluts.com/"], :root a[href^="http://www.cdjapan.co.jp/aff/click.cgi/"], :root a[href*="//ridingintractable.com/"], :root a[href^="http://c.actiondesk.com/"], :root a[href^="http://intent.bingads.com/"], :root a[href^="https://intrev.co/"], :root a[href^="http://https://www.get-express-vpn.com/offer/"], :root a[href^="//voyeurhit.com/cs/"], :root [href*=".go2page.net"], :root a[href^="http://hd-plugins.com/download/"], :root a[href^="http://greensmoke.com/"], :root a[href^="https://look.utndln.com/"], :root a[href^="//5e1fcb75b6d662d.com/"], :root a[href^="http://googleads.g.doubleclick.net/pcs/click"], :root .nrelate .nr_partner, :root a[href^="http://go.xtbaffiliates.com/"], :root a[href*=".purple6401.com/"], :root a[href^="https://oackoubs.com/"], :root a[href^="http://install.securewebsiteaccess.com/"], :root a[href^="http://www.revenuehits.com/"], :root a[href^="http://go.mobisla.com/"], :root a[href^="https://ads.planetwin365affiliate.com/redirect.aspx?"], :root a[href^="http://g1.v.fwmrm.net/ad/"], :root a[href^="http://imads.integral-marketing.com/"], :root a[href^="http://freesoftwarelive.com/"], :root a[href^="http://adtrackone.eu/"], :root span[title="Ads by Google"], :root a[href^="http://finaljuyu.com/"], :root a[href^="https://www.im88trk.com/"], :root a[href^="http://ffxitrack.com/"], :root a[href^="http://t.wowtrk.com/"], :root a[href^="//syndication.dynsrvtbg.com/splash.php?"], :root a[href^="http://extra.bet365.com/"][href*="?affiliate="], :root a[href^="http://ethfw0370q.com/"], :root a[href^="https://tracking.comfortclick.eu/"], :root [id^="bunyad_ads_"], :root a[href^="http://elitefuckbook.com/"], :root a[href^="http://eclkmpsa.com/"], :root a[href^="http://earandmarketing.com/"], :root a[href*=".mfroute.com/"], :root #content > #center > .dose > .dosesingle, :root a[href^="http://campaign.bharatmatrimony.com/track/"], :root a[href*="3wr110.xyz/"], :root a[href^="http://d2.zedo.com/"], :root a[href^="http://codec.codecm.com/"], :root a[href^="https://paid.outbrain.com/network/redir?"], :root a[href^="http://www.downloadplayer1.com/"], :root a[href^="http://clicks.binarypromos.com/"], :root a[href^="https://dediseedbox.com/clients/aff.php?"], :root [href^="/ucmini.php"], :root a[href^="http://www.wantstraffic.com/"], :root a[href^="http://track.afcpatrk.com/"], :root a[href^="http://databass.info/"], :root div[data-test-id="AdBannerWrapper"], :root div[class^="AdCard_"], :root a[href^="http://www.urmediazone.com/signup"], :root a[href^="http://click.plista.com/pets"], :root a[href^="http://chaturbate.com/affiliates/"], :root [href^="https://secure.bmtmicro.com/servlets/"], :root a[href^="http://amzn.to/"] > img[src^="data"], :root a[href^="http://bs.serving-sys.com/"], :root a[href^="http://cpaway.afftrack.com/"], :root a[href^="http://cdn.adsrvmedia.net/"], :root [lazy-ad="top_banner"], :root a[href^="http://360ads.go2cloud.org/"], :root a[href^="http://dftrck.com/"], :root a[href^="http://casino-x.com/?partner"], :root a[href^="https://meet-sexhere.com/"], :root a[href^="http://record.sportsbetaffiliates.com.au/"], :root a[href^="http://campeeks.com/"][href*="&utm_"], :root a[href^="http://download-performance.com/"], :root a[href^="http://www.on2url.com/app/adtrack.asp"], :root #\5f _nq__hh[style="display:block!important"], :root [href^="https://affect3dnetwork.com/track/"], :root div[class^="index_displayAd_"], :root a[href^="http://adultgames.xxx/"], :root a[href^="https://s.zlink2.com/"], :root a[href^="http://semi-cod.com/clicks/"], :root a[href*="//bongacams4.com/track?"], :root a[href^="http://campaign.bharatmatrimony.com/cbstrack/"], :root a[href^="http://www.seekbang.com/cs/"], :root a[href^="http://syndication.exoclick.com/"], :root a[href^="http://k2s.cc/pr/"], :root [src*="https://cdn.cloudimagesb.com/"], :root a[href^="http://bluehost.com/track/"], :root div[id^="vuukle-ad-"], :root a[href^="http://betahit.click/"], :root a[href^="https://torguard.net/aff.php"] > img, :root a[href^="http://bestorican.com/"], :root a[href^="http://bcp.crwdcntrl.net/"], :root a[href^="http://bc.vc/?r="], :root a[href^="https://windscribe.com/promo/"], :root a[href^="http://farm.plista.com/pets"], :root a[href^="https://leg.xyz/?track="], :root a[href^="http://affiliate.glbtracker.com/"], :root a[href^="https://transfer.xe.com/signup/track/redirect?"], :root a[href^="http://anonymous-net.com/"], :root aside[itemtype="https://schema.org/WPAdBlock"], :root a[href^="https://watchmygirlfriend.tv/"], :root a[href^="https://ovb.im/"], :root a[href^="http://hotcandyland.com/partner/"], :root a[href^="http://affiliates.thrixxx.com/"], :root #atvcap + #tvcap > .mnr-c > .commercial-unit-mobile-top, :root a[href*="/adrotate-out.php?"], :root a[href^="http://affiliates.lifeselector.com/"], :root a[href^="http://affiliate.coral.co.uk/processing/"], :root a[href^="http://aff.ironsocket.com/"], :root div[id^="drudge-column-ads-"], :root a[href*="//bongacams10.com/track?"], :root a[href^="http://tour.mrskin.com/"], :root [src^="/Redirect.a2b?"], :root a[href^="http://linksnappy.com/?ref="], :root ad-desktop-sidebar, :root [id*="MGWrap"], :root a[href^="http://9amq5z4y1y.com/"], :root a[href^="http://adtrack123.pl/"], :root a[href^="http://adsrv.keycaptcha.com"], :root a[href^="http://deloplen.com/afu.php?zoneid="], :root div[class^="StickyHeroAdWrapper-"], :root a[href^="http://cwcams.com/landing/click/"], :root a[href^="http://ads.betfair.com/redirect.aspx?"], :root a[href^="https://www.mrskin.com/tour"], :root a[href^="http://adserver.adtech.de/"], :root a[href^="http://adserver.adreactor.com/"], :root a[href^="http://ads.sprintrade.com/"], :root a[data-redirect^="http://click.plista.com/pets"], :root .section-subheader > .section-hotel-prices-header, :root a[href^="http://landingpagegenius.com/"], :root [href^="https://click2cvs.com/"], :root a[href^="http://ads.expekt.com/affiliates/"], :root a[href^="http://reallygoodlink.extremefreegames.com/"], :root a[href^="http://adlev.neodatagroup.com/"], :root [href*="//mclick.net"], :root a[href^="http://adclick.g.doubleclick.net/"], :root a[href^="http://www.sex.com/pics/?utm_"], :root a[href^="http://vo2.qrlsx.com/"], :root [href^="https://stvkr.com/"], :root a[href^="http://engine.newsmaxfeednetwork.com/"], :root a[href^="http://ad.yieldmanager.com/"], :root [href^="http://homemoviestube.com/"], :root a[href^="http://ad.doubleclick.net/"], :root a[href^="http://websitedhoome.com/"], :root a[href^="https://clickadilla.com/"], :root .ob_container .item-container-obpd, :root a[href*=".directtl.xyz/"], :root a[href^="http://www.adskeeper.co.uk/"], :root a[href^="http://ad-emea.doubleclick.net/"], :root a[href^="http://srvpub.com/"], :root [data-dynamic-ads], :root a[href^="http://a.adquantix.com/"], :root a[href^="http://NowDownloadAll.com"], :root a[href^="http://1phads.com/"], :root a[href^="https://ismlks.com/"], :root a[href^="//zenhppyad.com/"], :root a[href^="https://www.sugarinstant.com/?partner_id="], :root a[href^="//z6naousb.com/"], :root a[href^="//www.pd-news.com/"], :root div[id^="ads250_250-widget"], :root [href^="https://go.astutelinks.com/"], :root [href*=".doubleclick-net.com"], :root a[href^="//www.mgid.com/"], :root a[href^="http://lp.ncdownloader.com/"], :root a[href^="//pubads.g.doubleclick.net/"], :root a[href^="http://www.ducksnetwork.com/"], :root a[href^="http://3wr110.net/"], :root #topstuff > #tads, :root a[href*=".bang.com/"][href*="&aff="], :root .pubexchange_module .pe-external, :root a[data-widget-outbrain-redirect^="http://paid.outbrain.com/network/redir?"], :root a[href^="http://join3.bannedsextapes.com/track/"], :root [href^="http://join.shemalesfromhell.com/"], :root a[href^="https://www.travelzoo.com/oascampaignclick/"], :root a[href^="https://see.kmisln.com/"], :root [src^="//adtorio.com/"], :root a[href^="http://refer.webhostingbuzz.com/"], :root a[href^="//nlkdom.com/"], :root a[href^="//medleyads.com/spot/"], :root [href^="https://mylead.global/stl/"] > img, :root a[href^="https://ilovemyfreedoms.com/"][href*="?affiliate_id="], :root [href*=".afftracks.online/"], :root div[class^="Component-dfp-"], :root a[href^="//healthaffiliate.center/"], :root [onclick*="content.ad/"], :root a[href^="https://clixtrac.com/"], :root a[href^="//88d7b6aa44fb8eb.com/"], :root a[href^="http://go.fpmarkets.com/"], :root a[href^="//00ae8b5a9c1d597.com/"], :root [href^="http://join.ts-dominopresley.com/"], :root a[href^=".vddfe.club/"], :root [href^="/ucdownloader.php"], :root a[href^="https://awejmp.com/"], :root [href*="//go2page.net"], :root a[href^=" http://www.sex.com/"][href*="&utm_"], :root a[href^="https://fileboom.me/pr/"], :root a[href^="http://marketgid.com"], :root [href^="https://mysbitl.com"], :root a[href*="onclkds."], :root a[href^="https://adclick.g.doubleclick.net/"], :root a[href*=".intab.fun/"], :root a[href*="get-express-vpn.xyz"], :root a[href^="https://prf.hn/click/"][href*="/creativeref:"] > img, :root a[href^="http://www.adultempire.com/unlimited/promo?"][href*="&partner_id="], :root a[href*="=adscript"], :root a[href*="=Adtracker"], :root a[href^="https://members.linkifier.com/public/affiliateLanding?refCode="], :root a[href^="https://jmp.awempire.com/"], :root [href^="https://wct.link/"], :root a[href^="https://track.totalav.com/"], :root a[href^="http://ad-apac.doubleclick.net/"], :root a[href*="/servlet/click/zone?"], :root a[href^="http://track.trkvluum.com/"], :root a[href^="https://www.chngtrack.com/"], :root a[href*="=exoclick"], :root a[href^="http://www.firstclass-download.com/"], :root a[href*="//bongacams7.com/track?"], :root FBS-AD, :root a[href*="//bongacams5.com/track?"], :root a[href^="http://k2s.cc/code/"], :root div[id^="tms-ad-dfp-"], :root a[href^="https://trust.zone/go/r.php?RID="], :root a[href^="http://c43a3cd8f99413891.com/"], :root a[href*="//bongacams2.com/track?"], :root a[href^="//4f6b2af479d337cf.com/"], :root [href*="//doubleclick-net.com"], :root div[id^="advads-"], :root a[href^="http://www.myfreecams.com/?co_id="][href*="&track="], :root a[href^="https://track.afcpatrk.com/"], :root a[href*=".ad-center.com/"], :root a[href*=".udncoeln.com/"], :root a[href^="https://a.bestcontentfood.top/"], :root #ads > .dose > .dosesingle, :root .commercial-unit-mobile-top .jackpot-main-content-container > .UpgKEd + .nZZLFc > div > .vci, :root a[href*="delivery.trafficfabrik.com"], :root .trc_rbox_div .syndicatedItem, :root a[href^="http://www.streamate.com/exports/"], :root [href^="https://traffserve.com/"], :root [href*="maskip.co/"], :root div[class$="_b-ad-main"], :root a[href*=".trck5.com/"], :root a[href*=".qertewrt.com/"], :root .ob-widget > .ob-first.ob-widget-section, :root a[href*=".smartadserver.com"], :root a[href^="http://z1.zedo.com/"], :root a[href*=".irtyc.com/"], :root div[id^="div_ad_stack_"], :root a[href*=".ichlnk.com/"], :root a[href^="https://uncensored3d.com/"], :root a[href^="http://adf.ly/?id="], :root a[href^="https://usenetxs.website/"], :root a[href^="http://pokershibes.com/index.php?ref="], :root a[href^="http://api.content.ad/"], :root a[href*=".clkcln.com/"], :root [data-ad-manager-id], :root div[class^="adUnit_"], :root a[href^="https://deliver.tf2www.com/"], :root a[href^="http://spygasm.com/track?"], :root .ob_dual_right > .ob_ads_header ~ .odb_div, :root [src*="//www.dianomi.com/smartads.epl"], :root a[href*=".adk2x.com/"], :root a[href^="http://www.friendlyadvertisements.com/"], :root a[href^="http://www.firstload.com/affiliate/"], :root a[href^="http://duckcash.eu/"], :root a[href^="http://www.mobileandinternetadvertising.com/"], :root [href^="https://join.playboyplus.com/track/"], :root a[data-url^="http://paid.outbrain.com/network/redir?"] + .author, :root [href^="https://www.reimageplus.com/"], :root div[id^="cns_ads_"], :root a[data-obtrack^="http://paid.outbrain.com/network/redir?"], :root a[href^="https://prf.hn/click/"][href*="/adref:"] > img, :root a[href^="http://enter.anabolic.com/track/"], :root a[data-nvp*="'trafficUrl':'https://paid.outbrain.com/network/redir?"], :root a[href^="http://a63t9o1azf.com/"], :root a[href*=".axdsz.pro/"], :root a[href^="http://www.badoink.com/go.php?"], :root a[class="RBAd"], :root a[href^="http://banners.victor.com/processing/"], :root [href^="http://raboninco.com/"], :root a[href^="http://www.getyourguide.com/?partner_id="], :root [onclick^="window.open('https://www.brazzersnetwork.com/landing/"], :root [href^="http://join.rodneymoore.com/"], :root [id*="MarketGid"], :root a[href^="http://espn.zlbu.net/"], :root a[href^="http://admrotate.iplayer.org/"], :root a[href^="https://scurewall.co/"], :root div[class*="_browserAdOuterContainer_"], :root [name^="google_ads_iframe"], :root a[href^="http://fsoft4down.com/"], :root a[href*="ad2upapp.com/"], :root a[href*=".fwd28.com/"], :root [lazy-ad="leftbottom_banner"], :root dile-cookies-consent, :root [id^="div-gpt-ad"], :root a[href^="https://playuhd.host/"], :root [href^="https://go.affiliatexe.com/"], :root a[href^="http://mgid.com/"], :root a[href*=".adsrv.eacdn.com/"] > img, :root [href^="https://ptwmjmp.com/"], :root [href*="//etracking.pro"], :root a[href^="http://www.fonts.com/BannerScript/"], :root a[href^="http://c.ketads.com/"], :root a[href^="http://6kup12tgxx.com/"], :root [href^="https://freecourseweb.com/"] > .sitefriend, :root [href^="https://www.hostg.xyz/aff_c"] > img, :root [href*="//trackout.business"], :root [href^="https://veepn.g2afse.com/"], :root a[href^="https://syndication.exoclick.com/splash.php?"], :root a[data-oburl^="http://paid.outbrain.com/network/redir?"], :root a[href^="http://refpa.top/"], :root a[href*="//bongacams.com/track?"], :root a[href^="https://servedbyadbutler.com/"], :root a[href^="https://www.bet365.com/"][href*="affiliate="], :root a[href^="https://mob1ledev1ces.com/"], :root a[data-redirect^="http://paid.outbrain.com/network/redir?"], :root a[href^="https://promo-bc.com/"], :root a[href^="https://explore.findanswersnow.net/"], :root [id^="adframe_wrap_"], :root div[jsdata*="CarouselPLA-"][data-id^="CarouselPLA-"], :root a[href^="https://go.trackitalltheway.com/"], :root [data-template-type="nativead"], :root [href^="https://track.fiverr.com/visit/"] > img, :root a[href^="https://traffic.bannerator.com/"], :root [href^="https://shiftnetwork.infusionsoft.com/go/"] > img, :root a[href^="http://www.roboform.com/php/land.php"], :root div[id^="yandex_ad"], :root a[href^="https://www.pornhat.com/"][rel="nofollow"], :root a[href^="https://www.hotgirls4fuck.com/"], :root a[href*=".frtyl.com/"], :root a[href^="http://y1jxiqds7v.com/"], :root [href^="https://online-protection-now.com/"], :root a[href^="http://online.ladbrokes.com/promoRedirect?"], :root a[href^="//mob1ledev1ces.com/"], :root [href^="https://go.4rabettraff.com/"], :root a[href^="https://delivery.porn.com/"], :root a[href^="https://www.firstload.com/affiliate/"], :root .trc_related_container div[data-item-syndicated="true"], :root a[href^="https://freeadult.games/"], :root a[href^="http://liversely.net/"], :root a[href^="http://www.coiwqe.site/"], :root iframe[id^="google_ads_frame"], :root a[href^="http://www.bet365.com/"][href*="affiliate="], :root a[href^="http://www.bluehost.com/track/"] > img, :root a[data-url^="http://paid.outbrain.com/network/redir?"], :root a[href^="https://www.popads.net/users/"], :root a[href^="http://www.advcashpro.com/aff/"], :root a[href^="http://adultfriendfinder.com/p/register.cgi?pid="], :root a[href^="http://secure.hostgator.com/~affiliat/"], :root [onclick^="window.open('http://adultfriendfinder.com/search/"], :root [onclick^="window.open('window.open('//delivery.trafficfabrik.com/"], :root [href^="/admdownload.php"], :root iframe[src^="http://ad.yieldmanager.com/"], :root a[href^="http://pubads.g.doubleclick.net/"], :root a[href^="https://porntubemate.com/"], :root a[href^="http://www.gfrevenge.com/landing/"], :root a[href^="http://45eijvhgj2.com/"], :root a[href^="http://hpn.houzz.com/"], :root div[id^="ad_bigbox_"], :root #content > #right > .dose > .dosesingle, :root a[href^="http://9nl.es/"], :root a[href^="https://deliver.ptgncdn.com/"], :root a[href^="http://latestdownloads.net/download.php?"], :root [href^="https://www.targetingpartner.com/"], :root a[href^="http://see-work.info/"], :root a[href*=".orange2258.com/"], :root #taw > .med + div > #tvcap > .mnr-c:not(.qs-ic) > .commercial-unit-mobile-top, :root .plista_widget_belowArticleRelaunch_item[data-type="pet"], :root a[data-oburl^="https://paid.outbrain.com/network/redir?"], :root a[href^="http://affiliates.score-affiliates.com/"], :root a[href^="https://wantopticalfreelance.com/"], :root [href^="/ucdownload.php"], :root [id^="ad-wrap-"], :root div[id^="ad-gpt-"], :root a[href^="http://pan.adraccoon.com?"], :root div[data-contentexchange-widget], :root [href^="http://www.star-clicks.com/"], :root [href^="http://join.hardcoreshemalevideo.com/"], :root a[href^="http://ads2.williamhill.com/redirect.aspx?"], :root a[href*=".xromp.com/landing/click/"], :root a[href^="https://click.hoolig.app/"], :root a[href^="http://www.download-provider.org/"], :root a[href^="https://10dfkuvbdkfv.club/"], :root AD-TRIPLE-BOX, :root [class^="Ad-adContainer"], :root a[href^="http://adserving.unibet.com/"], :root [id*="ScriptRoot"], :root a[href^="http://fileboom.me/pr/"], :root a[href*=".trust.zone"], :root a[href^="https://adsrv4k.com/"], :root a[href^="http://trk.mdrtrck.com/"], :root [href^="https://shrugartisticelder.com"], :root [href^="https://refpahrwzjlv.top/"], :root a[href^="http://czotra-32.com/"], :root a[href^="http://click.payserve.com/"], :root a[href^="http://serve.williamhill.com/promoRedirect?"], :root [class*="__adspot-title-container"], :root a[href*="n47adshostnet.com/"], :root a[href*=".cfm?fp="][href*="&prvtof="], :root [href*=".mclick.net"], :root [href*=".grtya.com/"], :root a[href^="http://refpaano.host/"], :root a[href*="/cmd.php?ad="], :root [href^="https://bulletprofitsmartlink.com/"], :root [href^="https://join3.bannedsextapes.com"], :root a[href^="http://tezfiles.com/pr/"], :root div[class^="Ad__container"], :root a[href^="http://adprovider.adlure.net/"], :root a[id^="ads_banner_"], :root a[href^="http://findersocket.com/"], :root a[href^="https://porngames.adult/?SID="], :root div[id^="adspot-"], :root #\5f _admvnlb_modal_container, :root a[href^="http://www.streamtunerhd.com/signup?"], :root div[class^="hp-ad-rect-"], :root a[href^="http://dwn.pushtraffic.net/"], :root a[href$="/vghd.shtml"], :root div[id^="crt-"][style], :root a[href^="http://igromir.info/"], :root div[id^="div-ads-"], :root a[onmousedown^="this.href='https://paid.outbrain.com/network/redir?"][target="_blank"] + .ob_source, :root a[href^="http://at.atwola.com/"], :root a[href^="https://syndication.dynsrvtbg.com/splash.php?"], :root [href^="http://join.trannies-fuck.com/"], :root a[href^="http://get.slickvpn.com/"], :root [data-ad-module], :root a[href^="https://www.g4mz.com/"], :root a[href^="http://webgirlz.online/landing/"], :root [href*="cadsecs.com/"], :root a[href^="https://msecure117.com/"], :root [href^="http://stvkr.com/"], :root a[href^="https://keep2share.cc/pr/"], :root a[href*=".opskln.com/"], :root a[href^="http://xads.zedo.com/"], :root [class^="div-gpt-ad"], :root [class*="auto-bottom-advertising-"], :root a[href^="https://t.mobtya.com/"], :root a[href^="https://www.adxtro.com/"], :root [class*="__adv-block"], :root a[href^="https://farm.plista.com/pets"], :root a[href*=".red90121.com/"], :root a[href^="http://www.afgr3.com/"], :root [ad-id^="googlead"], :root [href^="https://rapidgator.net/article/premium/ref/"], :root [href^="https://join.girlsoutwest.com/"], :root a[href^="http://taboola-"][href*="/redirect.php?app.type="], :root a[href^="http://www.menaon.com/installs/"], :root a[href^="https://financeads.net/tc.php?"], :root .commercial-unit-mobile-top .jackpot-main-content-container > .UpgKEd + .nZZLFc > .vci, :root a[href^="https://www.oneclickroot.com/?tap_a="] > img, :root a[href^="//porngames.adult/?SID="], :root DFP-AD, :root a[href^="https://mmwebhandler.aff-online.com/"], :root [href^="https://r.kraken.com/"], :root a[href^="http://www.pinkvisualpad.com/?revid="], :root a[href^="https://www.friendlyduck.com/AF_"], :root [href^="http://advertisesimple.info/"], :root [lazy-ad="lefttop_banner"], :root a[href^="https://a.adtng.com/"], :root a[href^="http://static.fleshlight.com/images/banners/"], :root a[href^="https://www.adskeeper.co.uk/"], :root [href^="https://www.highrevenuecpm.com"], :root a[href^="https://secure.cbdpure.com/aff/"], :root AMP-AD, :root a[href^="http://aflrm.com/"], :root div[id^="google_dfp_"], :root [href*="get-download.club/"], :root [href^="https://www.xvbelink.com/"], :root a[href^="http://affiliates.pinnaclesports.com/processing/"], :root #header + #content > #left > #rlblock_left, :root a[href^="http://partners.etoro.com/"], :root [id^="google_ads_iframe"], :root .vid-present > .van_vid_carousel__padding, :root a[href^="http://goldmoney.com/?gmrefcode="], :root a[href^="http://papi.mynativeplatform.com:80/pub2/"], :root LEADERBOARD-AD, :root .plistaList > .plista_widget_underArticle_item[data-type="pet"], :root [class*="-slot_ad-placements-"], :root [href^="http://join.shemale.xxx/"], :root a[href^="https://www.oboom.com/ad/"], :root [href*=".adcampo.com/"], :root [href^="https://pulsetrack.biz/"], :root a[href^="https://trackjs.com/?utm_source"], :root AFS-AD, :root a[href^="https://secure.starsaffiliateclub.com/C.ashx?"], :root .trc_rbox_div .syndicatedItemUB, :root [href*=".xiloy.site/"], :root [src^="http://api.lanistaads.com/ServeAd?"], :root a[href^="http://webtrackerplus.com/"], :root [href*=".jetx.info/"], :root [href*=".trackout.business"], :root a[href*=".allsports4you.club"] { display: none !important; }
:root a[href^="https://track.bruceads.com/"], :root a[href^="https://m.do.co/c/"] > img, :root [href*=".ltroute.com/"], :root div[class*="margin-Advert"], :root a[href^="//jsmptjmp.com/"], :root a[href*=".adform.net/"], :root a[href^="http://www.onwebcam.com/random?t_link="], :root a[href*="//promo-bc.com/track?"], :root a[href^="https://sexsimulator.game/tab/?SID="], :root .rc-cta[data-target], :root a[href^="https://as.sexad.net/"], :root a[href^="//40ceexln7929.com/"], :root a[href$="/5-"][target="_blank"][rel="nofollow"], :root a[href*=".revimedia.com/"], :root [href*=".securesafemembers.com"], :root a[href^="https://secure.adnxs.com/clktrb?"], :root a[href^="http://adserver.adtechus.com/"], :root a[href^="https://topoffers.com/"][href*="/?pid="], :root a[href^="http://vinfdv6b4j.com/"], :root [href^="https://dooloust.net/"], :root a[href*=".surfmdia.com/"], :root .commercial-unit-mobile-top > div[data-pla="1"], :root [data-freestar-ad], :root [href*=".revrtb.com/"], :root a[href^="https://goraps.com/"], :root [href*=".etracking.pro"] { display: none !important; }</style></head>
    <body class="navbar-show">
        <header class="navbar navbar-top navbar-expand-lg navbar-dark navbar-fixed">
            <div class="container">
                <a class="navbar-brand order-1" href="index.html">
                    <img width="107" src="https://runwebrun.com/assets/images/logo-white.svg" alt="">
                </a>
                <a class="navbar-toggle order-4" href="#navbar-mobile-style-2" data-fancybox="" data-base-class="fancybox-navbar" data-keyboard="false" data-auto-focus="false" data-touch="false" data-close-existing="true" data-small-btn="false" data-toolbar="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </a>
                <ul class="nav navbar-nav order-2">
                    <li class="nav-item navbar-dropdown navbar-dropdown-mega">
                        <a href="index-1.html" class="nav-link">
                            <span class="nav-link-name">home</span>
                            <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </a>
                        <div class="dropdown-menu">
                            <div class="container">
                                <ul role="menu" class="navbar-nav row gh-1 gv-3">
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="home.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/main-home.jpg" alt=""></span><span class="nav-link-name">main home</span>
                                        </a>
                                    </li>
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="simple-portfolio.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/simple-portfolio.jpg" alt=""></span><span class="nav-link-name">simple portofolio</span>
                                        </a>
                                    </li>
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="creative-agency.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/creative-agency.jpg" alt=""></span><span class="nav-link-name">creative agency</span>
                                        </a>
                                    </li>
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="freelancer-portfolio.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/freelancer-portfolio.jpg" alt=""></span><span class="nav-link-name">freelancer portfolio</span>
                                        </a>
                                    </li>
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="interactive-links-dark.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/interactive-dark.jpg" alt=""></span><span class="nav-link-name">interactive dark</span>
                                        </a>
                                    </li>
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="interactive-links-light.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/interactive-light.jpg" alt=""></span><span class="nav-link-name">interactive light</span>
                                        </a>
                                    </li>
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="left-menu.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/left-menu.jpg" alt=""></span><span class="nav-link-name">left menu</span>
                                        </a>
                                    </li>
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="digital-agency.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/digital-agency.jpg" alt=""></span><span class="nav-link-name">digital agency</span>
                                        </a>
                                    </li>
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="carousel-dark.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/carousel-dark.jpg" alt=""></span><span class="nav-link-name">carousel dark</span>
                                        </a>
                                    </li>
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="carousel-light.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/carousel-light.jpg" alt=""></span><span class="nav-link-name">carousel light</span>
                                        </a>
                                    </li>
                                    <li class="nav-item col-md-6 col-lg-3 col-xl-2">
                                        <a href="fullscreen-showcase.html" class="nav-link"><span class="nav-link-image"><img src="assets/images/demos/fullscreen-showcase.jpg" alt=""></span><span class="nav-link-name">fullscreen showcase</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item navbar-dropdown">
                        <a href="portfolio-col-1-style-1.html" class="nav-link">
                            <span class="nav-link-name">projects</span>
                            <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </a>
                        <div class="dropdown-menu">
                            <ul class="nav navbar-nav">
                                <li class="nav-item navbar-dropdown">
                                    <a href="portfolio-col-1-style-1.html" class="nav-link">
                                        <span class="nav-link-name">1 column</span>
                                        <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item">
                                                <a href="portfolio-col-1-style-1.html" class="nav-link">
                                                    <span class="nav-link-name">Style 1</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-1-style-2.html" class="nav-link">
                                                    <span class="nav-link-name">Style 2</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item navbar-dropdown">
                                    <a href="portfolio-col-2-style-1.html" class="nav-link">
                                        <span class="nav-link-name">2 column</span>
                                        <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item">
                                                <a href="portfolio-col-2-style-1.html" class="nav-link">
                                                    <span class="nav-link-name">Style 1</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-2-style-2.html" class="nav-link">
                                                    <span class="nav-link-name">Style 2</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-2-style-3.html" class="nav-link">
                                                    <span class="nav-link-name">Style 3</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-2-style-4.html" class="nav-link">
                                                    <span class="nav-link-name">Style 4</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-2-style-5.html" class="nav-link">
                                                    <span class="nav-link-name">Style 5</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-2-style-6.html" class="nav-link">
                                                    <span class="nav-link-name">Style 6</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item navbar-dropdown">
                                    <a href="portfolio-col-3-style-1.html" class="nav-link">
                                        <span class="nav-link-name">3 column</span>
                                        <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item">
                                                <a href="portfolio-col-3-style-1.html" class="nav-link">
                                                    <span class="nav-link-name">Style 1</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-3-style-2.html" class="nav-link">
                                                    <span class="nav-link-name">Style 2</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-3-style-3.html" class="nav-link">
                                                    <span class="nav-link-name">Style 3</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-3-style-4.html" class="nav-link">
                                                    <span class="nav-link-name">Style 4</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-3-style-5.html" class="nav-link">
                                                    <span class="nav-link-name">Style 5</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item navbar-dropdown">
                                    <a href="portfolio-col-4-style-1.html" class="nav-link">
                                        <span class="nav-link-name">4 column</span>
                                        <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item">
                                                <a href="portfolio-col-4-style-1.html" class="nav-link">
                                                    <span class="nav-link-name">Style 1</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-4-style-2.html" class="nav-link">
                                                    <span class="nav-link-name">Style 2</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-4-style-3.html" class="nav-link">
                                                    <span class="nav-link-name">Style 3</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-col-4-style-4.html" class="nav-link">
                                                    <span class="nav-link-name">Style 4</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item navbar-dropdown">
                                    <a href="portfolio-single-style-1.html" class="nav-link">
                                        <span class="nav-link-name">Single Works</span>
                                        <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item">
                                                <a href="portfolio-single-style-1.html" class="nav-link">
                                                    <span class="nav-link-name">Style 1</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-single-style-2.html" class="nav-link">
                                                    <span class="nav-link-name">Style 2</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-single-style-3.html" class="nav-link">
                                                    <span class="nav-link-name">Style 3</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-single-style-4.html" class="nav-link">
                                                    <span class="nav-link-name">Style 4</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-single-style-5.html" class="nav-link">
                                                    <span class="nav-link-name">Style 5</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="portfolio-single-style-6.html" class="nav-link">
                                                    <span class="nav-link-name">Style 6</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item navbar-dropdown">
                        <a href="about-us.html" class="nav-link">
                            <span class="nav-link-name">pages</span>
                            <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </a>
                        <div class="dropdown-menu">
                            <ul class="nav navbar-nav">
                                <li class="nav-item navbar-dropdown">
                                    <a href="about-us.html" class="nav-link">
                                        <span class="nav-link-name">About Us</span>
                                        <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-drop-left">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item">
                                                <a href="about-us.html" class="nav-link">
                                                    <span class="nav-link-name">About Us</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="about-us-2.html" class="nav-link">
                                                    <span class="nav-link-name">About Us 2</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="about-me.html" class="nav-link">
                                                    <span class="nav-link-name">About Me</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item navbar-dropdown">
                                    <a href="services.html" class="nav-link">
                                        <span class="nav-link-name">Services</span>
                                        <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-drop-left">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item">
                                                <a href="services.html" class="nav-link">
                                                    <span class="nav-link-name">Services</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="single-service.html" class="nav-link">
                                                    <span class="nav-link-name">Single Service</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item navbar-dropdown">
                                    <a href="blog-col-3.html" class="nav-link">
                                        <span class="nav-link-name">Blog</span>
                                        <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-drop-left">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item">
                                                <a href="blog-col-3.html" class="nav-link">
                                                    <span class="nav-link-name">3 column</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="blog-col-1.html" class="nav-link">
                                                    <span class="nav-link-name">1 column</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="single-post.html" class="nav-link">
                                                    <span class="nav-link-name">Single Post</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a href="coming-soon.html" class="nav-link">
                                        <span class="nav-link-name">Coming Soon</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="404.html" class="nav-link">
                                        <span class="nav-link-name">404</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item navbar-dropdown">
                        <a href="contact-1.html" class="nav-link">
                            <span class="nav-link-name">contact</span>
                            <svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 9L5 5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </a>
                        <div class="dropdown-menu">
                            <ul class="nav navbar-nav">
                                <li class="nav-item">
                                    <a href="contact-1.html" class="nav-link">
                                        <span class="nav-link-name">Contact 1</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="contact-2.html" class="nav-link">
                                        <span class="nav-link-name">Contact 2</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                </ul>
                <a class="d-none d-sm-inline-block btn btn-white btn-with-ball ml-auto ml-lg-60 mr-40 mr-lg-0 order-2 order-lg-3" href="https://themes.getbootstrap.com/product/themebau/">purchase<span class="btn-ball" style="transform: translateY(0px);"></span></a>
                <a class="btn btn-white btn-link btn-clean d-sm-none order-2 ml-auto mr-40" href="https://themes.getbootstrap.com/product/themebau/">purchase</a>
            </div>
        </header>
        <!-- style 2 -->
        <div class="navbar navbar-mobile navbar-mobile-style-2 navbar-dark" id="navbar-mobile-style-2">
            <div class="shape justify-content-end">
                <svg data-rellax-speed="0" width="544" height="362" viewBox="0 0 544 362" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: translate3d(0px, 0px, 0px);">
                    <circle cx="320.5" cy="41.5" r="320.5" fill=" #202020"></circle>
                </svg>
            </div>
            <div class="navbar-head">
                <div class="container">
                    <a class="navbar-brand" href="index.html">
                        <img width="107" src="assets/images/logo-white.svg" alt="">
                    </a>
                    <a class="navbar-toggle" href="#" data-fancybox-close="">
                        <span></span>
                        <span></span>
                        <span></span>
                    </a>
                </div>
            </div>
            <div class="container">
                <div class="row gh-1 justify-content-center">
                    <div class="col-12 col-md-7 col-lg-5 col-xl-4">
                        <div class="navbar-body">
                            <ul class="nav navbar-nav navbar-nav-collapse">
                                <li class="nav-item navbar-collapse">
                                    <a href="#navbarCollapseHome" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapseHome">
                                        <span class="nav-link-name">home</span>
                                        <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="navbar-collapse-menu collapse" id="navbarCollapseHome">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item">
                                                <a href="home.html" class="nav-link">
                                                    <span class="nav-link-name">main home</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="simple-portfolio.html" class="nav-link">
                                                    <span class="nav-link-name">simple portofolio</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="creative-agency.html" class="nav-link">
                                                    <span class="nav-link-name">creative agency</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="freelancer-portfolio.html" class="nav-link">
                                                    <span class="nav-link-name">freelancer portfolio</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="interactive-links-dark.html" class="nav-link">
                                                    <span class="nav-link-name">interactive dark</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="interactive-links-light.html" class="nav-link">
                                                    <span class="nav-link-name">interactive light</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="left-menu.html" class="nav-link">
                                                    <span class="nav-link-name">left menu</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="digital-agency.html" class="nav-link">
                                                    <span class="nav-link-name">digital agency</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="carousel-dark.html" class="nav-link">
                                                    <span class="nav-link-name">carousel dark</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="carousel-light.html" class="nav-link">
                                                    <span class="nav-link-name">carousel light</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="fullscreen-showcase.html" class="nav-link">
                                                    <span class="nav-link-name">fullscreen showcase</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item navbar-collapse">
                                    <a href="#navbarCollapseProjects" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapseProjects">
                                        <span class="nav-link-name">projects</span>
                                        <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="navbar-collapse-menu collapse" id="navbarCollapseProjects">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item navbar-collapse">
                                                <a href="#navbarCollapse1Column" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapse1Column">
                                                    <span class="nav-link-name">1 column</span>
                                                    <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </a>
                                                <div class="navbar-collapse-menu collapse" id="navbarCollapse1Column">
                                                    <ul class="nav navbar-nav">
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-1-style-1.html" class="nav-link">
                                                                <span class="nav-link-name">Style 1</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-1-style-2.html" class="nav-link">
                                                                <span class="nav-link-name">Style 2</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <li class="nav-item navbar-collapse">
                                                <a href="#navbarCollapse2Column" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapse2Column">
                                                    <span class="nav-link-name">2 column</span>
                                                    <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </a>
                                                <div class="navbar-collapse-menu collapse" id="navbarCollapse2Column">
                                                    <ul class="nav navbar-nav">
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-2-style-1.html" class="nav-link">
                                                                <span class="nav-link-name">Style 1</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-2-style-2.html" class="nav-link">
                                                                <span class="nav-link-name">Style 2</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-2-style-3.html" class="nav-link">
                                                                <span class="nav-link-name">Style 3</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-2-style-4.html" class="nav-link">
                                                                <span class="nav-link-name">Style 4</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-2-style-5.html" class="nav-link">
                                                                <span class="nav-link-name">Style 5</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-2-style-6.html" class="nav-link">
                                                                <span class="nav-link-name">Style 6</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <li class="nav-item navbar-collapse">
                                                <a href="#navbarCollapse3Column" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapse3Column">
                                                    <span class="nav-link-name">3 column</span>
                                                    <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </a>
                                                <div class="navbar-collapse-menu collapse" id="navbarCollapse3Column">
                                                    <ul class="nav navbar-nav">
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-3-style-1.html" class="nav-link">
                                                                <span class="nav-link-name">Style 1</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-3-style-2.html" class="nav-link">
                                                                <span class="nav-link-name">Style 2</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-3-style-3.html" class="nav-link">
                                                                <span class="nav-link-name">Style 3</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-3-style-4.html" class="nav-link">
                                                                <span class="nav-link-name">Style 4</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-3-style-5.html" class="nav-link">
                                                                <span class="nav-link-name">Style 5</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <li class="nav-item navbar-collapse">
                                                <a href="#navbarCollapse4Column" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapse4Column">
                                                    <span class="nav-link-name">4 column</span>
                                                    <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </a>
                                                <div class="navbar-collapse-menu collapse" id="navbarCollapse4Column">
                                                    <ul class="nav navbar-nav">
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-4-style-1.html" class="nav-link">
                                                                <span class="nav-link-name">Style 1</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-4-style-2.html" class="nav-link">
                                                                <span class="nav-link-name">Style 2</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-4-style-3.html" class="nav-link">
                                                                <span class="nav-link-name">Style 3</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-col-4-style-4.html" class="nav-link">
                                                                <span class="nav-link-name">Style 4</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <li class="nav-item navbar-collapse">
                                                <a href="#navbarCollapseSingleWorks" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapseSingleWorks">
                                                    <span class="nav-link-name">Single Works</span>
                                                    <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </a>
                                                <div class="navbar-collapse-menu collapse" id="navbarCollapseSingleWorks">
                                                    <ul class="nav navbar-nav">
                                                        <li class="nav-item">
                                                            <a href="portfolio-single-style-1.html" class="nav-link">
                                                                <span class="nav-link-name">Style 1</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-single-style-2.html" class="nav-link">
                                                                <span class="nav-link-name">Style 2</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-single-style-3.html" class="nav-link">
                                                                <span class="nav-link-name">Style 3</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-single-style-4.html" class="nav-link">
                                                                <span class="nav-link-name">Style 4</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-single-style-5.html" class="nav-link">
                                                                <span class="nav-link-name">Style 5</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="portfolio-single-style-6.html" class="nav-link">
                                                                <span class="nav-link-name">Style 6</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item navbar-collapse">
                                    <a href="#navbarCollapsePages" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapsePages">
                                        <span class="nav-link-name">pages</span>
                                        <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="navbar-collapse-menu collapse" id="navbarCollapsePages">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item navbar-collapse">
                                                <a href="#navbarCollapseAboutUs" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapseAboutUs">
                                                    <span class="nav-link-name">About Us</span>
                                                    <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </a>
                                                <div class="navbar-collapse-menu collapse" id="navbarCollapseAboutUs">
                                                    <ul class="nav navbar-nav">
                                                        <li class="nav-item">
                                                            <a href="about-us.html" class="nav-link">
                                                                <span class="nav-link-name">About Us</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="about-us-2.html" class="nav-link">
                                                                <span class="nav-link-name">About Us 2</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="about-me.html" class="nav-link">
                                                                <span class="nav-link-name">About Me</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <li class="nav-item navbar-collapse">
                                                <a href="#navbarCollapseServices" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapseServices">
                                                    <span class="nav-link-name">Services</span>
                                                    <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </a>
                                                <div class="navbar-collapse-menu collapse" id="navbarCollapseServices">
                                                    <ul class="nav navbar-nav">
                                                        <li class="nav-item">
                                                            <a href="services.html" class="nav-link">
                                                                <span class="nav-link-name">Services</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="single-service.html" class="nav-link">
                                                                <span class="nav-link-name">Single Service</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <li class="nav-item navbar-collapse">
                                                <a href="#navbarCollapseBlog" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapseBlog">
                                                    <span class="nav-link-name">Blog</span>
                                                    <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </a>
                                                <div class="navbar-collapse-menu collapse" id="navbarCollapseBlog">
                                                    <ul class="nav navbar-nav">
                                                        <li class="nav-item">
                                                            <a href="blog-col-3.html" class="nav-link">
                                                                <span class="nav-link-name">3 column</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="blog-col-1.html" class="nav-link">
                                                                <span class="nav-link-name">1 column</span>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="single-post.html" class="nav-link">
                                                                <span class="nav-link-name">Single Post</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <li class="nav-item">
                                                <a href="coming-soon.html" class="nav-link">
                                                    <span class="nav-link-name">Coming Soon</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="404.html" class="nav-link">
                                                    <span class="nav-link-name">404</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item navbar-collapse">
                                    <a href="#navbarCollapseContact" class="nav-link collapsed" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="navbarCollapseContact">
                                        <span class="nav-link-name">contact</span>
                                        <svg class="collapse-icon" width="7" height="12" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 11L6 6L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="navbar-collapse-menu collapse" id="navbarCollapseContact">
                                        <ul class="nav navbar-nav">
                                            <li class="nav-item">
                                                <a href="contact-1.html" class="nav-link">
                                                    <span class="nav-link-name">Contact 1</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="contact-2.html" class="nav-link">
                                                    <span class="nav-link-name">Contact 2</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-1 d-none d-md-block"></div>
                    <div class="col-12 col-md-4 col-lg-4 col-xl-3">
                        <div class="navbar-footer">
                            <div class="mb-60 text-white">
                                <p class="lead mb-17 font-weight-medium">Contact info:</p>
                                <ul class="list-group borderless font-size-17">
                                    <li class="list-group-item">Email: <a href="mailto:hello@themebau.com?subject=Test%20Address%20Email" class="text-white">hello@themebau.com</a></li>
                                    <li class="list-group-item">Phone: <a href="callto:+1 202-358-0309" class="text-white">+1 202-358-0309</a></li>
                                </ul>
                            </div>
                            <div class="mb-60 text-white">
                                <p class="lead mb-17 font-weight-medium">Address:</p>
                                <ul class="list-group borderless font-size-17">
                                    <li class="list-group-item">2260 Lady Bug Drive,</li>
                                    <li class="list-group-item">New York, NY 10011</li>
                                </ul>
                            </div>
                            <ul class="nav nav-gap-sm navbar-nav nav-social align-items-center mt-n10 text-white">
                                <li class="nav-item">
                                    <a href="https://facebook.com/runwebrun" class="nav-link">
                                        <svg width="8" viewBox="0 0 10 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M8.17421 3.65234H9.99996V0.154687C9.68557 0.107422 8.60224 0 7.34088 0C4.70831 0 2.90529 1.82188 2.90529 5.16914V8.25H0V12.1602H2.90529V22H6.46588V12.1602H9.25375L9.69693 8.25H6.46588V5.55586C6.46588 4.42578 6.7424 3.65234 8.17421 3.65234Z" fill="currentColor"></path>
                                        </svg>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="https://twitter.com/runwebrun" class="nav-link">
                                        <svg width="20" viewBox="0 0 25 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M22.0706 5.51356C22.086 5.73504 22.086 5.95656 22.086 6.17804C22.086 12.9334 17.0783 20.7172 7.92575 20.7172C5.10601 20.7172 2.48661 19.8787 0.283203 18.4232C0.683835 18.4707 1.069 18.4865 1.48505 18.4865C3.81167 18.4865 5.95347 17.6797 7.6638 16.3033C5.47581 16.2558 3.64221 14.7845 3.01046 12.7594C3.31865 12.8069 3.6268 12.8385 3.9504 12.8385C4.39723 12.8385 4.84411 12.7752 5.2601 12.6645C2.97968 12.1898 1.2693 10.1332 1.2693 7.64935V7.58609C1.93183 7.96579 2.70231 8.20309 3.5189 8.2347C2.17837 7.31709 1.30013 5.75086 1.30013 3.97894C1.30013 3.02972 1.54661 2.15959 1.97807 1.40019C4.42801 4.50103 8.11063 6.52604 12.24 6.74756C12.163 6.36787 12.1168 5.97239 12.1168 5.57687C12.1168 2.76076 14.3356 0.466797 17.0937 0.466797C18.5266 0.466797 19.8209 1.0838 20.73 2.0805C21.8548 1.85902 22.9334 1.43184 23.8887 0.846495C23.5189 2.03307 22.7331 3.02977 21.7008 3.66255C22.7023 3.55186 23.673 3.26702 24.5667 2.87155C23.8888 3.88403 23.0413 4.78577 22.0706 5.51356Z" fill="currentColor"></path>
                                        </svg>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="https://instagram.com/runwebrun" class="nav-link">
                                        <svg width="18" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11.2827 5.3166C8.24087 5.3166 5.78732 7.8148 5.78732 10.912C5.78732 14.0092 8.24087 16.5074 11.2827 16.5074C14.3245 16.5074 16.7781 14.0092 16.7781 10.912C16.7781 7.8148 14.3245 5.3166 11.2827 5.3166ZM11.2827 14.5497C9.31698 14.5497 7.70998 12.9183 7.70998 10.912C7.70998 8.90563 9.3122 7.27425 11.2827 7.27425C13.2532 7.27425 14.8554 8.90563 14.8554 10.912C14.8554 12.9183 13.2484 14.5497 11.2827 14.5497ZM18.2846 5.08772C18.2846 5.81331 17.7107 6.39282 17.0029 6.39282C16.2902 6.39282 15.7211 5.80844 15.7211 5.08772C15.7211 4.36699 16.295 3.78261 17.0029 3.78261C17.7107 3.78261 18.2846 4.36699 18.2846 5.08772ZM21.9243 6.4123C21.843 4.66404 21.4508 3.11545 20.1929 1.83956C18.9399 0.563678 17.419 0.164355 15.7019 0.0766992C13.9323 -0.0255664 8.62827 -0.0255664 6.85865 0.0766992C5.14643 0.159486 3.62552 0.558809 2.36766 1.83469C1.10979 3.11058 0.722392 4.65917 0.636302 6.40743C0.535865 8.20925 0.535865 13.6098 0.636302 15.4117C0.717609 17.1599 1.10979 18.7085 2.36766 19.9844C3.62552 21.2603 5.14165 21.6596 6.85865 21.7473C8.62827 21.8495 13.9323 21.8495 15.7019 21.7473C17.419 21.6645 18.9399 21.2652 20.1929 19.9844C21.446 18.7085 21.8382 17.1599 21.9243 15.4117C22.0247 13.6098 22.0247 8.21412 21.9243 6.4123ZM19.6381 17.345C19.2651 18.2995 18.5429 19.0348 17.6007 19.4195C16.1898 19.9893 12.8419 19.8578 11.2827 19.8578C9.72352 19.8578 6.37081 19.9844 4.96469 19.4195C4.02727 19.0397 3.30507 18.3043 2.92724 17.345C2.36766 15.9084 2.49679 12.4995 2.49679 10.912C2.49679 9.32443 2.37244 5.91071 2.92724 4.47899C3.30029 3.52451 4.02248 2.78917 4.96469 2.40446C6.37559 1.83469 9.72352 1.96618 11.2827 1.96618C12.8419 1.96618 16.1946 1.83956 17.6007 2.40446C18.5381 2.7843 19.2603 3.51964 19.6381 4.47899C20.1977 5.91558 20.0686 9.32443 20.0686 10.912C20.0686 12.4995 20.1977 15.9133 19.6381 17.345Z" fill="currentColor"></path>
                                        </svg>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-wrap">
            <div class="py-160 bg-dark text-center">
                <div class="container shape-parent">
                    <div class="shape ml-60">
                        <svg class="mt-n160" data-rellax-speed="1" width="500" height="318" viewBox="0 0 500 318" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: translate3d(0px, -50px, 0px);">
                            <circle cx="250" cy="68" r="250" fill="#202020"></circle>
                        </svg>
                    </div>
                    <div class="row justify-content-center text-white mb-100">
                        <div class="col-12 col-lg-8 col-xl-6">
                            <h1 class="display-4 mb-20 text-white show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="10" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">Themebau.</h1>
                            <p class="mb-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="10" data-show-delay="100" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">Themebau is a stylish universal template for all your projects &amp; creative output. Minimalistic and easy to use, it has everything you need to launch your website.</p>
                        </div>
                    </div>
                    <div class="row gh-1 gv-4">
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="50" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="home.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/main-home-740-600.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Main Home</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="150" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="simple-portfolio.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/simple-portfolio-740-600.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Simple Portfolio</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="250" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="creative-agency.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/creative-agency-740-600.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Creative Agency</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="50" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="freelancer-portfolio.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/freelancer-portfolio-740-600.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Freelancer Portfolio</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="150" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="interactive-links-dark.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/interactive-dark-740-600.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Interactive Dark</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="250" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="digital-agency.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/digital-agency-740-600.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Digital Agency</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="50" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="fullscreen-showcase.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/fullscreen-slider-740-362.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Fullscreen Slider</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="150" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="carousel-light.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/carousel-light-740-362.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Carousel Light</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="250" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="carousel-dark.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/carousel-dark-740-362.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Carousel Dark</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="50" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="interactive-links-light.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/interactive-light-740-600.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Interactive Light</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="150" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="left-menu.html" class="card card-demo text-white">
                                <span class="card-img">
                                    <img src="assets/images/demos/left-menu-740-600.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Left Menu</span>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="py-160">
                <div class="container">
                    <div class="row gh-1 gv-2 align-items-center mb-100">
                        <div class="col-12 col-lg-5 d-flex flex-column align-items-lg-end">
                            <img class="w-100 h-100 mb-30 mb-lg-0 box-shadow show-on-scroll show-on-scroll-ready" src="assets/images/demos/demo-1-940-602.jpg" alt="" data-show-duration="600" data-show-distance="40" data-show-origin="left" data-show-delay="400" style="transform: translateY(0px); transition-duration: 600ms; opacity: 1;">
                            <img class="mw-100 mt-lg-n70 mr-lg-n100 box-shadow show-on-scroll show-on-scroll-ready" width="370" src="assets/images/demos/demo-2-740-560.jpg" alt="" data-show-duration="600" data-show-distance="40" data-show-origin="left" data-show-delay="550" style="transform: translateY(0px); transition-duration: 600ms; opacity: 1;">
                        </div>
                        <div class="col-lg-2 d-none d-lg-block"></div>
                        <div class="col-12 col-lg-4">
                            <h2 class="h3 ml-lg-n100 mb-40 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-origin="right" data-show-delay="50" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">Present your work in a unique way 💪</h2>
                            <p class="mt-lg-n2 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-origin="right" data-show-delay="150" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">Themebau has 1/2/3/4 columns layouts to showcase your work and collections. Choose between the 19 types of layouts to create your portfolio.</p>
                            <a href="portfolio-col-2-style-1.html" class="btn btn-dark btn-with-ball show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-origin="right" data-show-delay="200" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">view pages<span class="btn-ball"></span></a>
                        </div>
                    </div>
                    <div class="row gh-1 gv-1 justify-content-center">
                        <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="250" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="portfolio-col-1-style-1.html" class="card card-demo">
                                <span class="card-img d-flex align-items-center justify-content-center flex-column">
                                    <span class="p-18">
                                        <svg width="134" height="109" viewBox="0 0 134 109" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M134 0H0V50H134V0ZM134 59H0V109H134V59Z" fill="#E2E2E2"></path></svg>
                                    </span>
                                </span>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="150" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="portfolio-col-2-style-1.html" class="card card-demo">
                                <span class="card-img d-flex align-items-center justify-content-center flex-column">
                                    <span class="p-18">
                                        <svg width="134" height="109" viewBox="0 0 134 109" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M62 0H0V50H62V0ZM62 59H0V109H62V59ZM72 59H134V109H72V59ZM134 0H72V50H134V0Z" fill="#E2E2E2"></path></svg>
                                    </span>
                                </span>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="50" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="portfolio-col-2-style-2.html" class="card card-demo">
                                <span class="card-img d-flex align-items-center justify-content-center flex-column">
                                    <span class="p-18">
                                        <svg width="134" height="109" viewBox="0 0 134 109" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M62 0H0V64H62V0ZM134 45H72V109H134V45ZM72 0H134V36H72V0ZM62 73H0V109H62V73Z" fill="#E2E2E2"></path></svg>
                                    </span>
                                </span>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="50" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="portfolio-col-3-style-1.html" class="card card-demo">
                                <span class="card-img d-flex align-items-center justify-content-center flex-column">
                                    <span class="p-18">
                                        <svg width="134" height="109" viewBox="0 0 134 109" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M38 0H0V50H38V0ZM86 0H47V50H86V0ZM95 0H134V50H95V0ZM38 59H0V109H38V59ZM47 59H86V109H47V59ZM134 59H95V109H134V59Z" fill="#E2E2E2"></path></svg>
                                    </span>
                                </span>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="150" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="portfolio-col-3-style-2.html" class="card card-demo">
                                <span class="card-img d-flex align-items-center justify-content-center flex-column">
                                    <span class="p-18">
                                        <svg width="134" height="109" viewBox="0 0 134 109" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M38 0H0V62H38V0ZM86 0H47V38H86V0ZM95 0H134V62H95V0ZM38 71H0V109H38V71ZM47 47H86V109H47V47ZM134 71H95V109H134V71Z" fill="#E2E2E2"></path></svg>
                                    </span>
                                </span>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="250" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <a href="portfolio-col-4-style-1.html" class="card card-demo">
                                <span class="card-img d-flex align-items-center justify-content-center flex-column">
                                    <span class="p-18">
                                        <svg width="134" height="109" viewBox="0 0 134 109" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M29 0H0V32H29V0ZM29 38H0V71H29V38ZM0 77H29V109H0V77ZM64 0H35V32H64V0ZM35 38H64V71H35V38ZM64 77H35V109H64V77ZM70 0H99V32H70V0ZM99 38H70V71H99V38ZM70 77H99V109H70V77ZM134 0H105V32H134V0ZM105 38H134V71H105V38ZM134 77H105V109H134V77Z" fill="#E2E2E2"></path></svg>
                                    </span>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="text-center mt-40 pt-10 show-on-scroll show-on-scroll-ready" data-show-distance="20" data-show-duration="500" data-show-delay="200" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                        <a href="#" class="font-size-18 font-weight-medium">and more... 🔥</a>
                    </div>
                </div>
            </div>
            <div class="py-160 bg-dark shape-parent overflow-hidden">
                <div class="shape justify-content-end mt-n130">
                    <svg class="mt-n160 mr-n60" width="640" height="640" viewBox="0 0 640 640" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: translate3d(0px, 100px, 0px);">
                        <circle cx="320" cy="320" r="320" fill="#202020"></circle>
                    </svg>
                </div>
                <div class="container">
                    <h2 class="text-center text-white mt-n10 mb-100 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="10" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">Projects Showcase</h2>
                </div>
                <div class="swiper swiper-dark overflow-hidden mt-n10 show-on-scroll show-on-scroll-ready" data-swiper-slides="auto" data-swiper-gap="70" data-swiper-grabcursor="true" data-swiper-breakpoints="620:1" data-show-duration="800" data-show-delay="150" style="transition-duration: 800ms; opacity: 1; transform: translateY(0px);">
                    <div class="container">
                        <div class="swiper-container overflow-initial swiper-container-initialized swiper-container-horizontal" style="cursor: grab;">
                            <div class="swiper-wrapper align-items-center" style="transform: translate3d(0px, 0px, 0px);">
                                <div class="swiper-slide w-sm-auto swiper-slide-active" style="margin-right: 70px;">
                                    <a href="portfolio-single-style-1.html">
                                        <img class="mw-100 w-xs-100" width="500" src="assets/images/demos/portfolio-single-1-1000-958.jpg" alt="">
                                    </a>
                                </div>
                                <div class="swiper-slide w-sm-auto swiper-slide-next" style="margin-right: 70px;">
                                    <a href="portfolio-single-style-2.html">
                                        <img class="mw-100 w-xs-100" width="330" src="assets/images/demos/portfolio-single-2-660-660.jpg" alt="">
                                    </a>
                                </div>
                                <div class="swiper-slide w-sm-auto" style="margin-right: 70px;">
                                    <a href="portfolio-single-style-3.html">
                                        <img class="mw-100 w-xs-100" width="500" src="assets/images/demos/portfolio-single-3-1000-958.jpg" alt="">
                                    </a>
                                </div>
                                <div class="swiper-slide w-sm-auto" style="margin-right: 70px;">
                                    <a href="portfolio-single-style-4.html">
                                        <img class="mw-100 w-xs-100" width="330" src="assets/images/demos/portfolio-single-4-660-660.jpg" alt="">
                                    </a>
                                </div>
                                <div class="swiper-slide w-sm-auto" style="margin-right: 70px;">
                                    <a href="portfolio-single-style-5.html">
                                        <img class="mw-100 w-xs-100" width="500" src="assets/images/demos/portfolio-single-5-1000-958.jpg" alt="">
                                    </a>
                                </div>
                                <div class="swiper-slide w-sm-auto" style="margin-right: 70px;">
                                    <a href="portfolio-single-style-6.html">
                                        <img class="mw-100 w-xs-100" width="330" src="assets/images/demos/portfolio-single-6-660-660.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                        <div class="swiper-scrollbar"><div class="swiper-scrollbar-drag" style="transform: translate3d(0px, 0px, 0px); width: 93.8028px;"></div></div><span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                        <div class="swiper-scrollbar"></div>
                    </div>
                </div>
            </div>
            <div class="py-160">
                <div class="container">
                    <div class="row gh-1 mb-90">
                        <div class="col-lg-1"></div>
                        <div class="col-lg-5 col-xl-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="50" data-show-origin="left" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <h2 class="h3 mt-n9">Practical Inner pages for everything you may need.</h2>
                        </div>
                        <div class="col-lg-2 d-none d-xl-block"></div>
                        <div class="col-lg-5 col-xl-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="200" data-show-origin="right" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <p class="mt-n6 mb-0">Themebau is packed with a set of practical inner pages for various uses. Choose your favorites &amp; customize them to your needs.</p>
                        </div>
                    </div>
                    <div class="row gh-1 gv-3 text-center">
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="100" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="about-us.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/about-us-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">About Us</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="150" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="about-us-2.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/about-us-2-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">About Us V.2</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="200" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="about-me.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/about-me-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">About Me</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="250" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="services.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/services-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Services</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="300" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="single-service.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/single-service-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Single Service</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="350" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="contact-1.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/contact-us-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Contact Us</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="400" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="contact-2.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/contact-us-2-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Contact Us V.2</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="450" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="404.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/404-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">404 Page</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="500" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="blog-col-3.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/blog-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Blog</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="550" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="blog-col-1.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/blog-2-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Blog V.2</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="600" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="single-post.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/single-post-540-460.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Single Post</span>
                                </span>
                            </a>
                        </div>
                        <div class="col-6 col-sm-6 col-md-4 col-lg-3 show-on-scroll show-on-scroll-ready" data-show-duration="400" data-show-distance="20" data-show-delay="650" style="transform: translateY(0px); transition-duration: 400ms; opacity: 1;">
                            <a href="coming-soon.html" class="card card-demo">
                                <span class="card-img box-shadow">
                                    <img src="assets/images/demos/coming-soon-540-264.jpg" alt="">
                                </span>
                                <span class="card-body">
                                    <span class="card-title h5">Coming Soon</span>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="py-160 bg-dark text-center">
                <div class="container">
                    <h2 class="mt-n10 text-white mb-70 show-on-scroll" data-show-duration="500" data-show-distance="10" style="transform: translateY(10px); transition-duration: 500ms;">Menu Styles</h2>
                    <div class="swiper swiper-dark show-on-scroll show-on-scroll-ready" data-swiper-slides="3" data-swiper-gap="30" data-swiper-grabcursor="true" data-swiper-breakpoints="460:1, 828:2" data-show-duration="800" data-show-delay="100" style="transition-duration: 800ms; opacity: 1; transform: translateY(0px);">
                        <div class="swiper-container swiper-container-initialized swiper-container-horizontal" style="cursor: grab;">
                            <div class="swiper-wrapper pt-20" style="transform: translate3d(0px, 0px, 0px);">
                                <div class="swiper-slide swiper-slide-active" style="width: 220px; margin-right: 30px;">
                                    <a href="home.html" class="card card-demo text-white">
                                        <span class="card-img">
                                            <img src="assets/images/demos/classic-menu-740-362.jpg" alt="">
                                        </span>
                                        <span class="card-body">
                                            <span class="card-title h5">Classic Menu</span>
                                        </span>
                                    </a>
                                </div>
                                <div class="swiper-slide swiper-slide-next" style="width: 220px; margin-right: 30px;">
                                    <a href="left-menu.html" class="card card-demo text-white">
                                        <span class="card-img">
                                            <img src="assets/images/demos/white-left-menu-740-362.jpg" alt="">
                                        </span>
                                        <span class="card-body">
                                            <span class="card-title h5">White Left Menu</span>
                                        </span>
                                    </a>
                                </div>
                                <div class="swiper-slide" style="width: 220px; margin-right: 30px;">
                                    <a href="creative-agency.html" class="card card-demo text-white">
                                        <span class="card-img">
                                            <img src="assets/images/demos/dark-center-menu-740-362.jpg" alt="">
                                        </span>
                                        <span class="card-body">
                                            <span class="card-title h5">Dark Center Menu</span>
                                        </span>
                                    </a>
                                </div>
                                <div class="swiper-slide" style="width: 220px; margin-right: 30px;">
                                    <a href="left-menu.html" class="card card-demo text-white">
                                        <span class="card-img">
                                            <img src="assets/images/demos/left-menu-740-362.jpg" alt="">
                                        </span>
                                        <span class="card-body">
                                            <span class="card-title h5">Left Menu</span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        <div class="swiper-scrollbar"><div class="swiper-scrollbar-drag" style="transform: translate3d(0px, 0px, 0px); width: 274.639px;"></div></div><span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                        <div class="swiper-scrollbar"></div>
                    </div>
                </div>
            </div>
            <div class="pt-70 overflow-hidden" style="background-color: #f5f5f5;">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-1 d-none d-lg-block order-lg-2"></div>
                        <div class="col-lg-5 col-xl-4 pt-100 pb-60 pb-lg-160 order-lg-3">
                            <h2 class="h3 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="10" data-show-delay="50" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">Fully responsive and retina ready 👑</h2>
                            <p class="mb-12 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="10" data-show-delay="150" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">Themebau is designed to look great on desktop computers, tablets and mobile devices. Every element 100% responsive &amp; retina ready.</p>
                        </div>
                        <div class="col-lg-6 order-lg-1 show-on-scroll show-on-scroll-ready" data-show-duration="800" data-show-distance="50" data-show-delay="200" style="transform: translateY(0px); transition-duration: 800ms; opacity: 1;">
                            <img class="w-100 mb-n60" src="assets/images/demos/responsive-1200-1070.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="py-160">
                <div class="container">
                    <div class="row gh-1 gv-3">
                        <div class="col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="50" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <div class="feature">
                                <div class="feature-icon"><svg width="71" height="70" viewBox="0 0 71 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.18911 17.7887L35 0.57735L64.8109 17.7887V52.2113L35 69.4226L5.18911 52.2113V17.7887Z" stroke="currentColor"></path>
                                        <path d="M18.2867 65.3084L1.0754 35.4976L18.2867 5.68667H52.7094L69.9207 35.4976L52.7094 65.3084H18.2867Z" stroke="currentColor"></path></svg><svg width="17" height="23" viewBox="0 0 17 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 11.5H10.2308C11.4548 11.5 12.6288 10.9469 13.4943 9.96231C14.3599 8.97774 14.8462 7.64239 14.8462 6.25C14.8462 4.85761 14.3599 3.52226 13.4943 2.53769C12.6288 1.55312 11.4548 1 10.2308 1H1V11.5ZM1 11.5H11.3846C12.6087 11.5 13.7826 12.0531 14.6482 13.0377C15.5137 14.0223 16 15.3576 16 16.75C16 18.1424 15.5137 19.4777 14.6482 20.4623C13.7826 21.4469 12.6087 22 11.3846 22H1V11.5Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></div>
                                <div class="feature-body">
                                    <h4 class="feature-title">Bootstrap 4</h4>
                                    <p class="feature-text">Themebau based on Bootstrap 4, so layout changes is so much easily.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="150" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <div class="feature">
                                <div class="feature-icon"><svg width="71" height="70" viewBox="0 0 71 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.18911 17.7887L35 0.57735L64.8109 17.7887V52.2113L35 69.4226L5.18911 52.2113V17.7887Z" stroke="currentColor"></path>
                                        <path d="M18.2867 65.3084L1.0754 35.4976L18.2867 5.68667H52.7094L69.9207 35.4976L52.7094 65.3084H18.2867Z" stroke="currentColor"></path></svg><svg width="25" height="21" viewBox="0 0 25 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M4.39014 19.6899V12.6899M4.39014 8.68994V1.68994M12.3901 19.6899V10.6899M12.3901 6.68994V1.68994M20.3901 19.6899V14.6899M20.3901 10.6899V1.68994M1.39014 12.6899H7.39014M9.39014 6.68994H15.3901M17.3901 14.6899H23.3901" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></div>
                                <div class="feature-body">
                                    <h4 class="feature-title">Sass Available</h4>
                                    <p class="feature-text">Easy customization with SASS variables. You can change colors, typography and more.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="250" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <div class="feature">
                                <div class="feature-icon"><svg width="71" height="70" viewBox="0 0 71 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.18911 17.7887L35 0.57735L64.8109 17.7887V52.2113L35 69.4226L5.18911 52.2113V17.7887Z" stroke="currentColor"></path>
                                        <path d="M18.2867 65.3084L1.0754 35.4976L18.2867 5.68667H52.7094L69.9207 35.4976L52.7094 65.3084H18.2867Z" stroke="currentColor"></path></svg><svg width="17" height="25" viewBox="0 0 17 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8.5 1H4.75C3.75544 1 2.80161 1.40387 2.09835 2.12276C1.39509 2.84165 1 3.81667 1 4.83333C1 5.85 1.39509 6.82502 2.09835 7.54391C2.80161 8.2628 3.75544 8.66667 4.75 8.66667M8.5 1V8.66667M8.5 1H12.25C12.7425 1 13.2301 1.09915 13.6851 1.2918C14.14 1.48444 14.5534 1.7668 14.9017 2.12276C15.2499 2.47872 15.5261 2.9013 15.7145 3.36638C15.903 3.83146 16 4.32993 16 4.83333C16 5.33673 15.903 5.83521 15.7145 6.30029C15.5261 6.76537 15.2499 7.18795 14.9017 7.54391C14.5534 7.89987 14.14 8.18223 13.6851 8.37487C13.2301 8.56751 12.7425 8.66667 12.25 8.66667M8.5 8.66667H4.75M8.5 8.66667H12.25M8.5 8.66667V16.3333M4.75 8.66667C3.75544 8.66667 2.80161 9.07053 2.09835 9.78942C1.39509 10.5083 1 11.4833 1 12.5C1 13.5167 1.39509 14.4917 2.09835 15.2106C2.80161 15.9295 3.75544 16.3333 4.75 16.3333M12.25 8.66667C11.7575 8.66667 11.2699 8.76582 10.8149 8.95846C10.36 9.1511 9.94657 9.43347 9.59835 9.78942C9.25013 10.1454 8.97391 10.568 8.78545 11.033C8.597 11.4981 8.5 11.9966 8.5 12.5C8.5 13.0034 8.597 13.5019 8.78545 13.967C8.97391 14.432 9.25013 14.8546 9.59835 15.2106C9.94657 15.5665 10.36 15.8489 10.8149 16.0415C11.2699 16.2342 11.7575 16.3333 12.25 16.3333C12.7425 16.3333 13.2301 16.2342 13.6851 16.0415C14.14 15.8489 14.5534 15.5665 14.9017 15.2106C15.2499 14.8546 15.5261 14.432 15.7145 13.967C15.903 13.5019 16 13.0034 16 12.5C16 11.9966 15.903 11.4981 15.7145 11.033C15.5261 10.568 15.2499 10.1454 14.9017 9.78942C14.5534 9.43347 14.14 9.1511 13.6851 8.95846C13.2301 8.76582 12.7425 8.66667 12.25 8.66667ZM4.75 16.3333C3.75544 16.3333 2.80161 16.7372 2.09835 17.4561C1.39509 18.175 1 19.15 1 20.1667C1 21.1833 1.39509 22.1584 2.09835 22.8772C2.80161 23.5961 3.75544 24 4.75 24C5.74456 24 6.69839 23.5961 7.40165 22.8772C8.10491 22.1584 8.5 21.1833 8.5 20.1667V16.3333M4.75 16.3333H8.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></div>
                                <div class="feature-body">
                                    <h4 class="feature-title">Figma Files Included</h4>
                                    <p class="feature-text">We provided a source Figma file with Themebau.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="350" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <div class="feature">
                                <div class="feature-icon"><svg width="71" height="70" viewBox="0 0 71 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.18911 17.7887L35 0.57735L64.8109 17.7887V52.2113L35 69.4226L5.18911 52.2113V17.7887Z" stroke="currentColor"></path>
                                        <path d="M18.2867 65.3084L1.0754 35.4976L18.2867 5.68667H52.7094L69.9207 35.4976L52.7094 65.3084H18.2867Z" stroke="currentColor"></path></svg><svg width="23" height="20" viewBox="0 0 23 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M20.3807 2.59133C19.8676 2.08683 19.2583 1.68663 18.5878 1.41358C17.9172 1.14054 17.1985 1 16.4727 1C15.7468 1 15.0281 1.14054 14.3576 1.41358C13.687 1.68663 13.0778 2.08683 12.5646 2.59133L11.4997 3.63785L10.4348 2.59133C9.39834 1.57276 7.99258 1.00053 6.52679 1.00053C5.06099 1.00053 3.65523 1.57276 2.61876 2.59133C1.58229 3.6099 1 4.99139 1 6.43187C1 7.87235 1.58229 9.25383 2.61876 10.2724L11.4997 19L20.3807 10.2724C20.8941 9.76814 21.3013 9.16942 21.5791 8.51045C21.857 7.85148 22 7.14517 22 6.43187C22 5.71857 21.857 5.01225 21.5791 4.35328C21.3013 3.69431 20.8941 3.09559 20.3807 2.59133Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></div>
                                <div class="feature-body">
                                    <h4 class="feature-title">Modern Design</h4>
                                    <p class="feature-text">High usability, organizing content, fully responsive design as per latest design trends.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="450" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <div class="feature">
                                <div class="feature-icon"><svg width="71" height="70" viewBox="0 0 71 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.18911 17.7887L35 0.57735L64.8109 17.7887V52.2113L35 69.4226L5.18911 52.2113V17.7887Z" stroke="currentColor"></path>
                                        <path d="M18.2867 65.3084L1.0754 35.4976L18.2867 5.68667H52.7094L69.9207 35.4976L52.7094 65.3084H18.2867Z" stroke="currentColor"></path></svg><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8.799 8.7C9.05761 7.96483 9.56807 7.34492 10.24 6.95005C10.9118 6.55518 11.7018 6.41083 12.4699 6.54258C13.238 6.67433 13.9347 7.07368 14.4366 7.66988C14.9385 8.26609 15.2132 9.02067 15.212 9.8C15.212 12 11.912 13.1 11.912 13.1M12 17.5H12.011M23 12C23 18.0751 18.0751 23 12 23C5.92487 23 1 18.0751 1 12C1 5.92487 5.92487 1 12 1C18.0751 1 23 5.92487 23 12Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></div>
                                <div class="feature-body">
                                    <h4 class="feature-title">Customer Support</h4>
                                    <p class="feature-text">We are here to help you if you have any queries about template.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="20" data-show-delay="550" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                            <div class="feature">
                                <div class="feature-icon"><svg width="71" height="70" viewBox="0 0 71 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.18911 17.7887L35 0.57735L64.8109 17.7887V52.2113L35 69.4226L5.18911 52.2113V17.7887Z" stroke="currentColor"></path>
                                        <path d="M18.2867 65.3084L1.0754 35.4976L18.2867 5.68667H52.7094L69.9207 35.4976L52.7094 65.3084H18.2867Z" stroke="currentColor"></path></svg><svg width="23" height="20" viewBox="0 0 23 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M22 1.9979V7.99947M22 7.99947H16.2727M22 7.99947L17.5709 3.63833C16.545 2.56276 15.2758 1.77704 13.8818 1.3545C12.4877 0.931957 11.0142 0.886355 9.59882 1.22195C8.1834 1.55755 6.87217 2.2634 5.78749 3.27365C4.70281 4.2839 3.88002 5.56562 3.39591 6.99921M1 18.0021V12.0005M1 12.0005H6.72727M1 12.0005L5.42909 16.3617C6.45499 17.4372 7.72417 18.223 9.11823 18.6455C10.5123 19.068 11.9858 19.1136 13.4012 18.778C14.8166 18.4425 16.1278 17.7366 17.2125 16.7263C18.2972 15.7161 19.12 14.4344 19.6041 13.0008" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></div>
                                <div class="feature-body">
                                    <h4 class="feature-title">Regular Updates</h4>
                                    <p class="feature-text">Lifetime reliable and regular updates with your purchase.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="py-130 bg-dark overflow-hidden shape-parent">
                <div class="shape justify-content-end mt-n130">
                    <svg class="mt-n160 mr-n60" width="640" height="640" viewBox="0 0 640 640" fill="none" xmlns="http://www.w3.org/2000/svg" style="transform: translate3d(0px, 100px, 0px);">
                        <circle cx="320" cy="320" r="320" fill="#202020"></circle>
                    </svg>
                </div>
                <div class="container">
                    <div class="row gh-1 gv-xs mt-n30">
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="650" data-show-distance="20" data-show-delay="50" style="transform: translateY(0px); transition-duration: 650ms; opacity: 1;">
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">11 Homepage variations</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">19 Portfolio styles &amp; 6 Single Projects pages</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">4 Menu &amp; 3 Footer styles</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">Creative Blog &amp; Inner pages</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">100% Responsive &amp; Retina ready</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 show-on-scroll show-on-scroll-ready" data-show-duration="650" data-show-distance="20" data-show-delay="150" style="transform: translateY(0px); transition-duration: 650ms; opacity: 1;">
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">Gulp Tooling to automate the Workflow</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">W3C valid HTML</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">Easy customization via HTML classes &amp; attributes</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">Smooth Animations</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">Smooth Parallax for images &amp; videos</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 col-xl-3 show-on-scroll show-on-scroll-ready" data-show-duration="650" data-show-distance="20" data-show-delay="250" style="transform: translateY(0px); transition-duration: 650ms; opacity: 1;">
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">Developers ready: Webpack, Gulp, SCSS, Nunjucks, NPM</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">Google Fonts</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">Included generated HTML version (ready to use without developer tools)</h6>
                                </div>
                            </div>
                            <div class="row gh-xs mt-25">
                                <div class="col-auto">
                                    <svg class="mt-n4" width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.5 1L12.1265 6.26604L18 7.11567L13.75 11.2124L14.753 17L9.5 14.266L4.247 17L5.25 11.2124L1 7.11567L6.8735 6.26604L9.5 1Z" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="col">
                                    <h6 class="font-size-16 mb-5 text-white">Google Maps</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center mt-70 pt-3 mb-n8 show-on-scroll show-on-scroll-ready" data-show-duration="500" data-show-distance="10" data-show-delay="350" style="transform: translateY(0px); transition-duration: 500ms; opacity: 1;">
                        <a href="#" class="text-white font-size-18 font-weight-medium">and more... 🔥</a>
                    </div>
                </div>
            </div>
            <div class="pt-100 mt-3 pb-130 text-center text-md-left">
                <div class="container">
                    <div class="row gv-1 align-items-center justify-content-center justify-content-md-between">
                        <div class="col-md-10 mr-md-auto">
                            <div class="interactive-links">
                                <img class="interactive-links-image" src="assets/images/demos/themebau-460-520.jpg" width="230" alt="" style="margin-top: -130px; margin-left: -115px;">
                                <a href="https://themes.getbootstrap.com/product/themebau/" class="nav-link display-4"><u>Get Themebau</u></a>
                            </div>
                        </div>
                        <div class="col-auto">
                            <a href="home.html" class="btn btn-clean mr-xl-100">
                                <svg class="icon-arrow icon-arrow-right" width="69" height="30" viewBox="0 0 69 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M54 2L67 15L54 28" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M17 15L67 15" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- START: Scripts -->
        <!-- Object Fit Polyfill -->
        <script src="assets/vendor/object-fit-images/dist/ofi.min.js"></script>
        <!-- Popper -->
        <script src="assets/vendor/popper.js/dist/umd/popper.min.js"></script>
        <!-- Bootstrap -->
        <script src="assets/vendor/bootstrap/dist/js/bootstrap.min.js"></script>
        <!-- Bootstrap Validator -->
        <script src="assets/vendor/bootstrap-validator/dist/validator.min.js"></script>
        <!-- ImagesLoaded -->
        <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
        <!-- Swiper -->
        <script src="assets/vendor/swiper/dist/js/swiper.min.js"></script>
        <!-- Animejs -->
        <script src="assets/vendor/animejs/lib/anime.min.js"></script>
        <!-- Rellax -->
        <script src="assets/vendor/rellax/rellax.min.js"></script>
        <!-- Countdown -->
        <script src="assets/vendor/jquery-countdown/dist/jquery.countdown.min.js"></script>
        <!-- Moment.js -->
        <script src="assets/vendor/moment/min/moment.min.js"></script>
        <script src="assets/vendor/moment-timezone/builds/moment-timezone-with-data.min.js"></script>
        <!-- Isotope -->
        <script src="assets/vendor/isotope-layout/dist/isotope.pkgd.min.js"></script>
        <script src="assets/vendor/isotope-packery/packery-mode.pkgd.min.js"></script>
        <!-- Jarallax -->
        <script src="assets/vendor/jarallax/dist/jarallax.min.js"></script>
        <script src="assets/vendor/jarallax/dist/jarallax-video.min.js"></script>
        <!-- Fancybox -->
        <script src="assets/vendor/fancybox/dist/jquery.fancybox.min.js"></script>
        <!-- Themebau -->
        <script src="assets/js/themebau.min.js"></script>
        <!-- END: Scripts -->
    
</body></html>