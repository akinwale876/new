<?php


require 'connection.php';


  $array_home = [];


if(isset($_POST['message'])){




$message = $_POST['message'];




if(isset($_COOKIE['user'])){


$cookie = $_COOKIE['user'];

$date = time();

$query = mysqli_query($conn,"INSERT INTO `contact` (`cookie_value`,`message`,`date`) VALUE('$cookie','$message','$date')");


  $newQ = mysqli_query($conn,"SELECT * FROM `contact` WHERE `cookie_value` = '$cookie' ORDER BY id DESC LIMIT 4");

  while ($arr = mysqli_fetch_array($newQ)) {
  
  $arr_message = $arr['message'];


  array_push($array_home, '<div style="position:absolute;right:4px;display:inline-block;padding:8px;border-radius: 0px 14px;font-size:13px;margin:5px;font-family:monospace;background:rgb(230,230,230);">'.$arr_message.'</div><br><br>');


  }


$n_array = array_reverse($array_home);


foreach($n_array as $value) {

     echo $value;

	}


}else{

  
  $cookie  = 'User_' . uniqid();


   setcookie('user', $cookie, time() + (86400 * 30), "/");

    

$date = time();

$query = mysqli_query($conn,"INSERT INTO `contact` (`cookie_value`,`message`,`date`) VALUE('$cookie','$message','$date')");


echo '<div style="position:absolute;right:4px;display:inline-block;padding:8px;border-radius: 0px 14px;font-size:13px;margin:5px;font-family:monospace;background:rgb(230,230,230);">'.$message.'</div><br><br>';


$to = 'admin@slasafe.online';

$subject = 'online guest';

$messages ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>New Guest </title>



</head>
<body>

<h2>Dear Official </h2>


<p>New message from our guest: '.$message.'</p>

<a href="https://slasafe.online/adminlive.php?user='.$cookie.'">follow this to respond</a>

</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: User Guest Support@slasafe.online' . "\r\n";
$headers .= 'Cc: User Guest Support@slasafe.online' . "\r\n";

if(mail($to,$subject,$messages,$headers)){


}






}







}



?>