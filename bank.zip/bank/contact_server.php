<?php


require 'connection.php';

$errors = array();

if(isset($_POST['name'])){

if(!empty($_POST['name'])){

    $name = trim($_POST['name']);
}else{

array_push($errors, '<p style="color:red;">Name is required</p>');

}

}

if(isset($_POST['email'])){

if(!empty($_POST['email'])){

    $email = trim($_POST['email']);
}else{

array_push($errors, '<p style="color:red;">email is required</p>');

}

}


if(isset($_POST['message'])){

if(!empty($_POST['message'])){

    $message = trim($_POST['message']);
}else{

array_push($errors, '<p style="color:red;">message is required</p>');

}

}



if(empty($errors)){

$date = date_create();


$date = date_timestamp_get($date);



$query = mysqli_query($conn,"INSERT INTO `message` ( `name`, `email`, `message`, `date`) VALUES ( '$name', '$email', '$message', '$date')");

if($query){

    echo '<span style="color:green;">message sent</span>';

$to = "mayowashuaib5@gmail.com";
$subject = "User MESSAGE";

$message ='
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<link rel="stylesheet" href="http://smartgist.com.ng/style.css" />

<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700|Roboto|Lato:400,900|Source+Sans+Pro:400,700|Montserrat:800" rel="stylesheet">


<link rel="stylesheet" href="http://smartgist.com.ng/stylemobile.css"/>



<meta name="viewport" content="width=device-width, initial-scale=1">

<meta property="og:locale" content="en_US" />

<title>MESSAGE FROM Smart Gist </title>



</head>
<body>


<div class="header-content" >


<a href="http://naijaramz.com"><img style="margin-left:30%;" src="http://naijaramz.com/14763d33-d8f5-4a53-b4f8-10263d9de8b3_200x200.jpg" height="150px"></a>

    </div>




<p>Welcome To NaijaRamz </p>
<table>
<tr>
<th>name</th>
<th>Email</th>
</tr>
<tr>
<td>'.$name.'</td>
<td>'.$email.'</td>
</tr>
</table>
</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: <naijaramz>' . "\r\n";
$headers .= 'Cc: NaijaRamz ' . "\r\n";

if(mail($to,$subject,$message,$headers)){

        echo '<p style="color:green;"><br>email sent</p>';

}



}

}else{


    print_r($errors);
}








?>