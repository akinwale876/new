<!DOCtype
 html>
 
 
 <?php
 
 require 'admin_init.php';
 
 


 
 
 
 if(!isset($_SESSION['access'])){
     
     echo '<script>
     
     
     window.location ="https://slasafe.online/new-account.php"
     
     </script>';
     
 }
 
 
 
 ?>
 
 
 
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>My Account(<?php echo $firstname;?>)</title>
<meta name="discription"
content="" />


<?php

include "head.php";

?>


</head>


<body style="background:rgb(30,30,30);">
     
<div class="container">
    
    
    
   <div class="leftsider">
    <div style="background:white;padding:5px;padding-top:7px;padding-bottom:10px;min-height:90px;">
        <br>
   
    <center>
<div class="header-image" style="display:inline-block;">  

</div>
  </center>
    <center><h4 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;color:black;">Slasafe Online Bank</h4>
    </center>
     <br>
    </div>
    <ul class="ul-list-account">
        
        <li>
            <a href="#dashboard" class="tablinks" onclick="openTab(event,'dashboard')" id="defaltOpen"><i class="fas fa-chart-line"></i>
<span class="text-icon">Dashboard</span></a>
        </li>
        
        <li>
            <a href="#message" class="tablinks" onclick="openTab(event,'message')"><i class="fas fa-envelope"></i><span class="text-icon">Messages</span></a>
        </li>
        <li>
            <a href="#transfer" class="tablinks" onclick="openTab(event,'fund')"><i class="fas fa-exchange-alt"></i><span class="text-icon">Fund transfer</span></a>
        </li>
        
        <li>
            <a href="#History" class="tablinks" onclick="openTab(event,'transaction')"><i class="fas fa-history"></i><span class="text-icon">Withdraw Fund</span></a>
        </li>
        
        <li>
            <a href="#statement" class="tablinks" onclick="openTab(event,'statement')"><i class="fas fa-book-open"></i><span class="text-icon">Account Statement</span></a>
        </li>
        
        <li>
            <a href="#profile" class="tablinks" onclick="openTab(event,'profile')"><i class="fas fa-user"></i><span class="text-icon">My profile</span></a>
        </li> 
        
        <li>
            <a href="#credit" class="tablinks" onclick="openTab(event,'card')"><i class="fab fa-cc-mastercard"></i><span class="text-icon">Add Credit Card</span></a>
        </li>
        
        <li>
            <a href="#settings" class="tablinks" onclick="openTab(event,'settings')"><i class="fa fa-cog"></i><span class="text-icon">Account Settings</span></a>
        </li>
        
             
        <li>
            <a href="#document" class="tablinks" onclick="openTab(event,'adddocument')"><i class="fa fa-book"></i><span class="text-icon">Add Document</span></a>
        </li>
        
         <li>
            <a href="#profile" class="tablinks" onclick="openTab(event,'ssn')"><i class="fas fa-qrcode"></i><span class="text-icon"> Add SSN </span></a>
        </li>
        <li>
            <a href="https://slasafe.online/contact" ><i class="far fa-address-card"></i><span class="text-icon">Contact us</span></a>
        </li>
        <li>
             <a href="logout.php"><i class="fas fa-sign-out-alt"></i><span class="text-icon">Logout</span></a>
        </li>
        
        
    </ul>
    
    
    
   </div>
   
   
   

   <div class="mainview">
       <div style="margin-top:9px;"></div>
   
               
               <div style="display:inline-block;font-size:13px;color:white;">
           <marquee style="margin:0;">
               
               
               <?php 
               
    
               
               
               $str = 'GBP/JPY = 137.9894 ▲ GBP/KES = 145.47741 ▲GBP/KMF = 551.96041 ▲GBP/KRW = 1481.54397 ▲GBP/KWD = 0.40622 ▲GBP/KYD = 1.10728 ▲  GBP/KZT = 568.61943 ▲GBP/LBP = 2019.3117 ▲GBP/LKR = 246.01014 ▲GBP/LSL = 20.35391 ▲GBP/MAD = 12.11004 ▲GBP/MDL = 22.74011 ▲GBP/MKD = 69.02863 ▲GBP/MNT = 3777.68975 ▲GBP/MOP = 10.61088 ▲GBP/MRO = 474.30452 ▲GBP/MUR = 52.94164 ▲GBP/MVR = 20.47348 ▲GBP/MWK = 1013.04537 ▲GBP/MXN = 26.71413 ▲GBP/MYR = 5.43723 ▲GBP/NAD = 20.36719 ▲GBP/NGN = 506.19054 ▲GBP/NIO = 46.32773 ▲GBP/NOK = 11.98589 ▲GBP/NPR = 157.54632 ▲GBP/NZD = 1.91716 ▲GBP/OMR = 0.5115 ▲GBP/PAB = 1.32858 ▲GBP/PEN = 4.77261 ▲GBP/PGK = 4.6899 ▲GBP/PHP = 64.08252 ▲GBP/PKR = 213.56989 ▲GBP/PLN = 5.00925 ▲GBP/PYG = 9351.22572 ▲GBP/QAR = 4.83737 ▲GBP/RON = 5.45556 ▲GBP/RUB = 101.25657 ▲GBP/RWF = 1313.30537 ▲GBP/SAR = 4.98283 ▲GBP/SBD = 10.71808 ▲GBP/SCR = 27.62177 ▲GBP/SEK = 11.45529 ▲GBP/SGD = 1.78495 ▲GBP/SLL = 13398.04835 ▲GBP/SVC = 11.62681 ▲GBP/SZL = 20.35391 ▲GBP/THB = 40.21727 ▼GBP/TND = 3.64896 ▲GBP/TOP = 3.05255 ▲GBP/TRY = 10.14494 ▲GBP/TTD = 9.01885 ▲GBP/TWD = 37.91952 ▲GBP/TZS = 3080.9865 ▲GBP/UAH = 37.68398 ▲GBP/UGX = 4922.83509 ▲GBP/USD = 1.32858 ▲GBP/UYU = 56.90628 ▲GBP/VEF = 330136.72757 ▲GBP/VUV = 149.11771 ▲GBP/WST = 3.4289 ▲GBP/XAF = 735.02552 ▲GBP/XCD = 3.59056 ▲GBP/XOF = 735.02552 ▲GBP/XPF = 133.71589 ▲GBP/YER = 332.61097 ▲GBP/ZAR = 20.47259= 8.47223 ▲GBP/HTG = 85.36325 ▲GBP/HUF = 403.68563 ▲GBP/IDR = 18842.77071 ▲GBP/ILS = 4.43768 ▲GBP/INR = 98.53132 ▲GBP/IQD = 1581.01506 ▲GBP/IRR = 55940.03303 ▲GBP/ISK = 180.51472 ▲GBP/JMD = 195.8197 ▲GBP/JOD = 0.94197 ▲';
               
               
             $mainstr =    str_replace('▲','<span style="color:green;">▲</span>',$str);
             
             echo   str_replace('▼','<span style="color:red;">▼</span>',$mainstr);
               
               
               ?>
           </marquee>
</div>
<br>
    <span class="iconn" style="font-size: 29px;"><i class="fa fa-user"></i><span class="text-icon"><?php echo ucfirst($firstname) . ' ' . ucfirst($lastname); ?></span></span>
  

    <span class="iconn" style="float:right;font-size: 29px;margin-right: 30px;"> <i class="fa fa-envelope" ></i><span class="text-icon"><?php 
    
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);

    $queryvtrans2 = mysqli_query($conn,"SELECT * FROM `transactions` WHERE `to` = '$account_number' ");
    
    
    
       
echo mysqli_num_rows($queryvtrans) + mysqli_num_rows($queryvtrans2);
    
    ?></span></span>
    
    <br>
    <h5 style="margin-bottom:1px;">Account</h5>
      
       <div name="dashboard" class="tabcontents" id="dashboard">
               
           
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Dashboard</h2>
               
<div class="shortscroll">
    
    
<div class="acct-page-d">
    
    <style type="text/css">
    	
.shortscroll{

height:280px;overflow:auto;

}

.shortscroll::-webkit-scrollbar {
  width: 6px;
  border-radius: 10px;
}

/* Track */
.shortscroll::-webkit-scrollbar-track {
  background: #f1f1f1;

  border-radius: 10px;
}

/* Handle */
.shortscroll::-webkit-scrollbar-thumb {
  background: #888;

  border-radius: 10px;
}

/* Handle on hover */
.shortscroll::-webkit-scrollbar-thumb:hover {
  background: rgb(90,40,40);
}



@media screen and (max-width: 900px){



.shortscroll{

height:auto;overflow:none;

}


}



    </style>
    
    
      

    <center> <h4>Message</h4>
   <br>
  <a href="#message" class="tablinks" onclick="openTab(event,'message')"> <i class="fas fa-envelope-open" style="font-size:27px;color: white;"></i></a> </center> 
    
    
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ORDER BY id DESC";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        

      $datatrans = mysqli_fetch_array($queryvtrans);

       $to = $datatrans['to'];
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
       
echo '<p style="color:white;"> <span style="color:green;">'. $currency . number_format($amount) . '</span> Sent To '. $to. '</p>';
    
                
        
    }else{
        
    }
}
    
 
    ?>
    
        
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `to` = '$account_number' ORDER BY id DESC";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        

      $datatrans = mysqli_fetch_array($queryvtrans);

       $from = $datatrans['from_name'];
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
       
echo '<p style="color:white;"> <span style="color:green;">'. $currency . number_format($amount) . '</span> Recieved From '. $from. '</p>';
    
                
        
    }else{
        
        
    }
}
    
 
    ?>
    
    
    
</div>
<div class="acct-page-d">
    
    
    
     <center>  <h4>My profile</h4>
    
  <a href="#profile" class="tablinks" onclick="openTab(event,'profile')"><img src="<?php echo $pic;?>" style="border-radius:50%;height:60px;width:60px;">
  </a>  <br>
    <?php
    
    
    
    
    echo '<h5>' . $firstname . ' ' . $lastname . '</h5>';
    
    
    ?>
    </center>
    
    
</div>



<div class="acct-page-d">
    
    
    <center> <h4>Transfer Fund</h4> <a href="#transfer" class="tablinks" onclick="openTab(event,'fund')"><i class="fas fa-exchange-alt" style="font-size:33px;color: white;"></i></a> </center> 
    
    
    
    
    
</div>

<div class="acct-page-d">
    
    
    <center> <h4>Withdraw Fund</h4> <a href="#History" class="tablinks" onclick="openTab(event,'transaction')">
        
       <i class="fas fa-arrow-alt-circle-down" style="font-size:33px;color: white;"></i> </a> </center> 
    
    
    
    
    
</div>

<div class="acct-page-d">
    

    <center> <h4>Notification</h4>
   <br> <i class="fas fa-bell" style="font-size:27px;color: white;"></i> </center> 
    
    
   <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ORDER BY id DESC ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        
        $datatrans = mysqli_fetch_array($queryvtrans);
        
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
       $to_date = $datatrans['date'];
       
       
        $to_date  = date('d/m/Y',$to_date);
        
        
echo '<p style="color:white;"> <span style="color:red;">Your Account has been debited with '. $currency . number_format($amount) . '</span> On '. $to_date. '</p>';
    
                
        
    }else{
        
    }
}
    
    
    
    ?>
    
        <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `to` = '$account_number' ORDER BY id DESC";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        

      $datatrans = mysqli_fetch_array($queryvtrans);

       $date = $datatrans['date'];
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
               $to_date  = date('d/m/Y',$date);

echo '<p style="color:white;"> <span style="color:green;">Your Account has been Credited with'. $currency . number_format($amount) . '</span> On: '. $to_date. '</p>';
    
                
        
    }else{
        
        
    }
}
    
 
    ?>
    
    
    
    
</div>

<div class="acct-page-d">
    
    
    <center> <h4>My Card</h4>
    
    <i class="far fa-credit-card" style="font-size:20px;"></i> </center> 
     <?php
    
    
         
$sqltranss = "SELECT * FROM `card` WHERE `account_number` = '$account_number' ORDER BY id DESC";
    
    $queryvtranss = mysqli_query($conn,$sqltranss);
    
    
    
    if($queryvtranss){
    
    if(mysqli_num_rows($queryvtranss)> 0){
        
        $datatranss = mysqli_fetch_array($queryvtranss);

       $cardnumber = $datatranss['card_number'];
       $cardexp = $datatranss['card_exp'];
       
echo '<p style="color:white;">'.  $cardnumber . '  <b>Exp:</b>'.  $cardexp . '</p>';
    
                
        
    }else{
        
        echo 'No Card';
    }
}
    
    
    
    ?>

    </center> 
    
    
    
    
    
</div>


<div class="acct-page-d">
    
    
    <center> <h4>SSN</h4>
    
    
   <br> <i class="fas fa-card" style="font-size:27px;"></i> </center> 
    
     <?php
    
    
         
$sqltrans = "SELECT * FROM `ssn` WHERE `account_number` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        
        
        $datatrans = mysqli_fetch_array($queryvtrans);

       $ssn = $datatrans['ssn'];
       
echo '<p style="color:white;">My SSN: <b>'. $ssn. '</b></p>';
    
                
        
    }else{
        
        echo 'Empty';
    }
}
    
    
    
    ?>

    </center> 
    
    
    
    
</div>



<div class="acct-page-d">
    
    
    <center> <h4>Int Passport</h4>
    
    </center> 
    
    
     <?php
    
    
         
$sqltrans = "SELECT * FROM `passport` WHERE `account_number` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        
$datatrans  = mysqli_fetch_array($queryvtrans);

       $passport = $datatrans['url'];;
     
       
       echo '
    <center>
  <a href="https://slasafe.online/'. $passport . '" style="color:white;"><i class="fa fa-book" style="font-size:27px;"></i> </a>
    </center>';
                
        
    }else{
   echo '
    <center><b>None</b></center>';
                

    }
}
    
    
    
    ?>
    
    
    
    
    
</div>

<div class="acct-page-d">
    
    
    <center> <h4>Driver License</h4>
     </center> 
    
    
     
     <?php
    
    
         
$sqltrans = "SELECT * FROM `driver_license` WHERE `account_number` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        
$datatrans  = mysqli_fetch_array($queryvtrans);

       $passport = $datatrans['url'];;
     
       
       echo '  <center><a href="https://slasafe.online/'. $passport . '"><i class="fa fa-car" style="font-size:27px;"></i></a> </center>';
                
        
    }else{
   echo '
    <center><b>None</b></center>';
                

    }
}
    
    
    
    ?>
    
</div>





</div>




       </div>
           
           
       <div name="transfer" class="tabcontents" id="fund">
               
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Fund transfer</h2>


<div class="acct-page" style="margin:0;padding:10px;position:relative;height: 340px;">
       <div style="background:rgb(30,40,30);padding:7px;">
           <b>Make Payment</b>
</div>
    <br>
    
   <div style="display:inline-block;margin-left:40px;">
       
    <form action="/" method="post" onsubmit="return false" id="form">
        
        
        <select name="transaction_type" id="transaction_type" required>
          
           <option value="">Select transaction type</option>
           <option value="payment">Payment</option>
           <option value="tax">Tax</option>

        </select> 
        
        <br>
        <input type="number" placeholder="Account Number"  name="to_account" id="to_account" required/><span style="font-size: 10px;" id="showmehere"></span>
        <br>
        <select name="currency" id="currency" required>
          
           <option value="">Select Currency</option>
           <option value="$">USD</option>
           <option value="$">EUR</option>
           <option value="$">GPD</option>

        </select>
         <br>
         
        <input type="number" placeholder="amount" name="amount" id="amount" required/>
        <br>
    



    <script>

$("#to_account").keyup(function(){
  

var q = $(this).val();

  $.post("account_server.php?q="+ q, function(data){

     $("#showmehere").html(data);

  });
});
               
 


    </script>
        
       
        <input type="submit" style="background: rgb(160,30,30);border:none;color: white;" id="sendfund" value="Send" />
        
        
    </form>
    
    
<span id="statust"></span>
                              

    
</div>
 

<script>



$("#sendfund").click(function(){
  

var transaction_type = $('#transaction_type').val();
var amount = $('#amount').val();
var currency = $('#currency').val();
var to_account = $('#to_account').val();

  $.post("transaction.php",{transaction_type:transaction_type,to_account:to_account,currency:currency,amount:amount}, function(data){

     $("#statust").html(data);


     $('#form').trigger("reset");
  });
});
               
 

  

</script>

 </div>
 
           
       </div>
           
                      
       <div name="card" class="tabcontents" id="card">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>ADD CREDIT CARD</h2>




<div class="input-container" style="height:310px;">
    
    
  <p style="font-style: cursive;font-size: 10px;color:gold;">Card information</p>
  
  
  <form action="addcard.php" method="post">
      
      
      <!---  card info  -->
  

<input type="number"  id="card_number" name="card_number" placeholder="Card Number">
  
<input type="text"  id="card_number" name="card_name" placeholder="Name on Card">

<input type="hidden"  value="billing" name="card_billing" >

<input type="text"  id="card_cvv" name="card_cvv" placeholder="CVV">

<input type="text"  id="card_exp" name="card_exp" placeholder="Expire date(M/Y)">

<input type="text"  id="billing" name="big" placeholder="Billing Address">

<input type="number"  id="pin" name="card_pin" placeholder="Card Pin">
    
<input type="submit" style="background: rgb(160,30,30);border:none;color: white;" value="Add card" >



  </form>
  

</div>

    
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ";
    
    ?>

       </div>
           
           
       <div name="History" class="tabcontents" id="transaction">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Withdraw Fund</h2>
 
<div class="acct-page"  style="margin:0;padding:10px;position:relative;height:360px;overflow:auto;">

       <div style="background:rgb(30,40,30);padding:7px;">
           <b style="font-family: monospace;"> <i class="fas fa-hand-holding-usd"></i>Withdraw to bank</b>
</div>
    <form action="withdrawfund.php" method="post" onsubmit="return rrw();">
        

  
<p id="statusw"></p>

        
            <input name="country" id="country" placeholder="Country" required="" >
            <input name="banks" id="bank" placeholder="Bank Name" required="" >

            <input name="swiftcode" id="swift_code" placeholder="Swift Code" required="" >
                
     
        <input type="number" placeholder="Account Number" name="account_number" id="account_numberw" required="" />
         
        <input type="text" placeholder="Account Name" name="account_name" id="account_namew" required="" />
 
        <input type="number" placeholder="amount" name="amount" id="amountw" required="" />
        
        <input type="submit" value="Withdraw Fund" id="buttow" style="background: rgb(160,30,30);border:none;color: white;"  onclick="rrw()" />
        
        
    </form>
   

<style>
    
   .input-container{
       
       margin:0;
   }
    
    
    .hidew{
        display:none;
        position:absolute;
        width:200px;
      border-radius:0;
        background:white;
        right:-20px;
        top:-15px;
        
        z-index:1;

    }
    
    .hidew::after{
        content:"";
        position:absolute;
        bottom:-19px;
        left:10px;
        border-style:solid;
        border-width:13px;
        border-color:white transparent transparent  transparent;

        

    }
    
</style>

             
             <script src="withdraw.js"></script>    
    
    
    <script>
    
    
    

setTimeout(function(){
    
    
    
    
    $('#buttow').click(function(){
        
        
    $('.hidew').slideDown(200)
    
    
    })
    
    
},2000)


</script>

 </div>


<div class="acct-page" style="margin:0;padding:10px;position:relative;height:350px;margin-left: 10px;">
       <div style="background:rgb(30,40,30);padding:7px;">
           <b style="font-family: monospace;"> <i class="fa fa-box"></i> Withdraw to my card</b>
</div>
    <br>
    
   <div style="display:inline-block;margin-left:40px;">
       
    <form action="fundcard.php" method="post">
        
        
        <label>Withdraw To card</label>
        
        <input type="number"  placeholder="amount" name="amount" id="amountw" required>
        <br>
        <select id="currency"  name="currency" required>
            
            
            <option value="$">USD</option>
            <option value="EUR">EUR</option>
            <option value="GPD">GPD</option>
            
            </select>
         <br>
         
      <input type="submit" style="background: rgb(160,30,30);border:none;color: white;" value="Send To card"  />
        
        
    </form>
    
</div>

</div>



   
<div class="acct-page" style="margin:0;padding:10px;position:relative;height:350px;margin-left: 10px;">
       <div style="background:rgb(30,40,30);padding:7px;">
           <b style="font-family: monospace;"> <i class="fa fa-box"></i> Last Withdraw </b>
</div>
    <br>
    
   <div style="display:inline-block;margin-left:40px;">
       
 
    
</div>

</div>
 
       </div>
           
                      
       <div name="statement" class="tabcontents" id="statement">
               

           <?php 
           
         include 'accountdetails.php';

           
?>
               <h2>Account Statement</h2>

           
<div class="acct-page" style="margin:0;padding:0px;">
    
    
    <h4>Lists</h4>
    
    <ul class="profile-list">
        
 This Month 
    </ul>
 
 
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
        
    $datatrans = mysqli_fetch_array($queryvtrans);
    


       $to_name = $datatrans['to_name'];
       $amount = $datatrans['amount'];
       
echo '<p style="color:white;"> <span style="color:green;">'. $currency . number_format($amount) . '</span> Sent To '. $to_name. '</p>';


    }
    
    
    
    ?>
    </div>
       </div>  
       

       <div name="message" class="tabcontents" id="message">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Messages</h2>




<div class="input-container" style="height:280px;width:90%;border:none;">
  <p style="font-style: cursive;font-size: 10px;color:gold;">New message</p>


   
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ORDER BY id DESC";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        

      while($datatrans = mysqli_fetch_array($queryvtrans)){

       $to = $datatrans['to'];
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
       
echo '<p style="color:white;font-size:11px;"> <span style="color:green;">'. $currency . number_format($amount) . '</span> Sent To '. $to. '</p>';
    
      }        
        
    }else{
        
    }
}
    
 
    ?>


   
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `to` = '$account_number' ORDER BY id DESC";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        

      while($datatrans = mysqli_fetch_array($queryvtrans)){

       $from = $datatrans['from_name'];
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
       
echo '<p style="color:white;font-size:11px;"> <span style="color:green;">'. $currency . number_format($amount) . '</span> Receive From '. $from. '</p>';
    
      }        
        
    }else{
        
    }
}
    
 
    ?>


</div>

    
       </div>
           




       <div name="ssn" class="tabcontents" id="ssn">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>ADD SSN</h2>




<div class="input-container" style="height:300px;">
  <p style="font-style: cursive;font-size: 10px;color:gold;">SSN information</p>


  
  <form action="addssn.php" method="post">
      
      
      <!---  ssn info  -->
  

<input type="number"  id="ssn" name="ssn" placeholder="SSN NUMBER">
  
<input type="submit" value="Add SSN" >



  </form>
  
</div>

    
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ";
    

    
    
    ?>

       </div>
           
       <div name="document" class="tabcontents" id="adddocument">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Upload Your document</h2>



<div class="input-container" style="height:280px;border:none;">
    
  <p style="font-style: cursive;font-size: 10px;color:gold;">Upload Passport</p>
  
  <form action="addpassport.php" method="post" enctype="multipart/form-data">
      
     
     <input type="file" name="passport" /> 
     
     <input type="submit" name="passport" value="upload Passport"/ > 
      
      
    
  </form>
  
  
  
</div>
<div class="input-container" style="height:280px;border:none;">
    
  <p style="font-style: cursive;font-size: 10px;color:gold;">Upload Drivers license</p>
  
  <form action="adddrivers_license.php" method="post" enctype="multipart/form-data">
      
     
     <input type="file" name="drivers_license" /> 
     
     <input type="submit" style="background: rgb(160,30,30);border:none;color: white;" name="passport" value="upload Drivers License"/ > 
      
      
    
  </form>
  
  
  
</div>

    
    
       </div>
           
       
       
       <div name="settings" class="tabcontents" id="settings">
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               
               <h2>Account Settings</h2>
               
               
<div class="acct-page" style"margin:0;padding:10px;">
    
               <h3 style="margin:3px;">Update Your Personal Info</h3>
               

    <form action="" method="" >
        
        
        <input type="text" placeholder="First Name" id="firstName" />
        <input type="text" placeholder="Last Name" id="lastName" />
 <br>
        <input type="submit" value="Update" id="submit" />
        
        
    </form>
    
 
        
    </ul>
 
 
    </div>
    
<div class="acct-page" style"margin:0;padding:10px;">
    
               <h3 style="margin:3px;">Update Your Password</h3>
               

    <form action="" method="" >
        
        
 
        <input type="text" placeholder="Old password" id="Oldpassword" />
        <input type="text" placeholder="New password" id="Newpassword" />
        <input type="text" placeholder="Confirm New password" id="ConNewpassword" />
  
  <br>
    
        <input type="submit" style="background: rgb(160,30,30);border:none;color: white;" value="Update" id="submit" />
        
        
    </form>

 
        
    </ul>
 
 
    </div>
    
           






       </div>
                   
       <div name="profile" class="tabcontents" id="profile">
               
           
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>My profile</h2>
           
  
  
  
  
<div class="acct-page">

    
     <center>  
    
    <h4>My profile Picture</h4>
  <img src="<?php echo $pic;?>" style="border-radius:50%;height:90px;width:90px;">
    <br>
    <?php
    
    
    
    
    echo '<h5>' . $firstname . ' ' . $lastname . '</h5>';
    
    
    ?>
    </center>
    
    </div>
    
<div class="acct-page" style"margin:0;padding:0px;">
    
    
     <div style="background:rgb(30,40,30);padding:7px;">
           <b>Personal Information</b>
</div>
    
    
    <ul class="profile-list">
        
        
    
 <li> First name: <?php echo $firstname;?></li>
 <li>Last Name: <?php echo $lastname;?></li>
 <li> Email: <?php echo $email;?></li>
    
 <li> Address: <?php echo $address;?></li>
 <li>State: <?php echo $state;?></li>
 <li> Country: <?php echo $country;?></li>
 
 
        
    </ul>
 
 
    </div>
    
<div class="acct-page" style"margin:0;padding:0px;">
    
     <div style="background:rgb(30,40,30);padding:7px;">
           <b>Account Information</b>
</div>
    
    
    <ul class="profile-list">
        
 <li>Account Number: <?php echo $account_number;?></li>
 <li>Account Name: <?php echo $account_name;?></li>
 
        
 <li>Account Type: <?php echo $account_type;?></li>

        
    </ul>
 
 
    </div>
    
    <style>
        
        
        .profile-list{
            
            list-style:none;
            padding:0;
            margin:0;
        }
        
        .profile-list li{
            
           background:#262b2d;
           margin:0;
           padding:4px;
           font-family:arial;
           font-size:12px;
           padding-top:6px;
           padding-bottom:6px;
           
           display:block;
        }
        .profile-list li:nth-child(even){
            
           background:rgb(10,20,10);
        }
        
        
    </style>
    
    
    


 
    
  

       </div>
           
  <?php



include 'footer.php';


  ?>
    
   </div>

</div>


<style>



    .container{
        
        min-height:500px;
        background:rgb(22,22,22);
        
    }
    
    .leftsider{
        float:left;
        width:180px;
        min-height:600px;
        background:rgb(50,50,90);
        
    }
    
    .mainview{
        color:rgb(90,90,90);
        margin:-6px 178px;
        width:1054px;
        padding:10px;
        padding-top:0;
        min-height:100%;

    }
    
    
    
    
    
    .ul-list-account{
        
    list-style:none; 
    margin:0;
        padding:0;
    }
    .ul-list-account li{
   margin:0;
   padding:0;
    }
    
    .ul-list-account li a{
   
   
       text-decoration:none;
       padding:8px;
       padding-top:12px;
       padding-bottom:12px;
       display:block;
       color:white;
       font-size:13px;
       
       
    }
    .ul-list-account li a:hover{
   
   
      background:rgb(22,22,22);
       
       
    }
    
  .ul-list-account li a.active {
  background-color:rgb(22,22,22);
}
    
    
    .text-icon{
        
        display:inline-block;
        margin-left:4px;
        text-indent:4px;
    }
    
    
    
    .tabcontents{
        
        
        display:none;
    }
    
    
    .tabcontents {
  animation: fadeEffect 1s; /* Fading effect takes 1 second */
}




.input-container{
    background:#262b2d;
    width:230px;
    height:90px;
    box-shadow:none;
    overflow:hidden;
    padding:9px;
    color:white;
    border-radius:3px 0px;
    position:relative;
    
}

.acct-page{
    background:#262b2d;
    width:310px;
    height:260px;
    display:inline-block;
    box-shadow:none;
    overflow:hidden;
    padding:9px;
    color:white;
    border-radius:3px 0px;
    position:relative;
    
}

.acct-page-d{
    background:#262b2d;
    width:230px;
    height:155px;
    display:inline-block;
    box-shadow:none;
    overflow:hidden;
    padding:9px;
    color:white;
    border-radius:3px 0px;
    position:relative;
    
}


input{
    
    
    padding:6px;
}

input:hover{
    
    box-shadow:none;
}


/* Go from zero to full opacity */
@keyframes fadeEffect {
  from {opacity: 0;}
  to {opacity: 1;}
}


.icon-left{
    
    position:absolute;left:23px;top:27px;
    
}


.icon-right{
    
    position:absolute;right:20px;top:20px;
    
}


#icon{
    
    font-size:36px;
    
}


@media screen and (max-width:980px){
    
    
    
  .mainview  .text-icon{
        
        display:inline-block;
        margin-left:4px;
        text-indent:4px;
        
        font-size:10px;
    }
    
    
.acct-page{
    
      width:95%;
    height:250px;
    display:block;
    
    margin-bottom:3px;
    
    
    
}
    
.acct-page-d{    
      width:40%;
    height:135px;
    display:inline-block;
    
    margin-bottom:3px;
    

}

    
    .leftsider{
        float:none;
        width:98%;
        min-height:auto;
        background:rgb(50,50,90);
        
    }
    
    .mainview{
        color:rgb(90,90,90);
        margin:0;
        width:98%;
        padding:10px;
        padding-top:0;
        min-height:100%;

    }



.input-container{
    background:#262b2d;
    width:42%;
    height:60px;
    display:inline-block;
    
}



.icon-left{
    
    position:absolute;left:23px;top:27px;
    
}


.icon-right{
    
    position:absolute;right:20px;top:20px;
    
}

.icon-right b{
    
    font-size:11px;
    
}


#icon{
    
    font-size:16px;
    
}


  
  
  
  
  
    .ul-list-account{
        
    list-style:none; 
    margin:0;
        padding:0;
    }
    .ul-list-account li{
   margin:0;
   padding:0;
          display:inline-block;

   
    }
    
    .ul-list-account li a{
   
   
       text-decoration:none;
       padding:8px;
       padding-top:12px;
       padding-bottom:12px;
       display:inline-block;
       color:white;
       font-size:13px;
       
       
    }
    .ul-list-account li a:hover{
   
   
      background:rgb(22,22,22);
       
       
    }
    
  .ul-list-account li a.active {
  background-color:rgb(22,22,22);
}
      
    
}




body::-webkit-scrollbar,
.acct-page::-webkit-scrollbar {
  width: 4px;
  border-radius: 20%;
}

/* Track */
body::-webkit-scrollbar-track,
.acct-page::-webkit-scrollbar-track {
  background: #f1f1f1;

  border-radius: 20%;
}

/* Handle */
body::-webkit-scrollbar-thumb,
.acct-page::-webkit-scrollbar-thumb {
  background: #888;

  border-radius: 20%;
}

/* Handle on hover */
body::-webkit-scrollbar-thumb:hover,
.acct-page::-webkit-scrollbar-thumb:hover {
  background: rgb(200,50,50);

  border-radius: 20%;
}


</style>


 <style type="text/css">
   
          
            
            select, input{

               width:180px;
            }


             input:[type=submit]{

              background: rgb(100,50,50);
              color:white;
             }




             *{

              transition:0.5s ease-in-out ;
             }

 </style>


<script>
    
    function openTab(evt, TabContent) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontents");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  
  document.getElementById(TabContent).style.display = "block";
  evt.currentTarget.className += " active";
}
    
    
    
    
</script>


<script>
document.getElementById("defaltOpen").click();
</script>



</body>

</html>