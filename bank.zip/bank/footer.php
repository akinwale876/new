 

<p style="color:rgb(100,100,100);font-weight:400;">
    
    
   
<small style="font-size:9px;">

<script language="JavaScript">

document.write('&copy;' );
document.write(' <b><i>Slasafe Online  Bank</i> ');
document.write(new Date().getFullYear());
document.write(' </b> Alright Reserved   <a style="color:red;margin-left:20px;" href="https://slasafe.online/privacy-policy">Privacy Policy</a>  <a style="color:white;margin-left:20px;" href="https://slasafe.online/tos.php">Terms of use</a>');

</script>

</small>
 
</p>
    
<div id="supportcontainer" style="position: fixed;right: 25px;bottom: 90px;background:white;width:0;height:0;overflow:hidden;box-shadow: 0px 3px 3px 0px gray;border-radius:0px 12px">
	


	<div style="background:rgb(103, 61, 230);color: white;position: relative;padding: 15px;"><h5 style="display: inline-block;margin: 5px;">Contact Support</h5>
		
		<span title="close window." style="font-size:26px;font-weight:700;position: absolute;right: 7px;top: 6px;color:white;text-shadow:0px 3px red;cursor: pointer;" id="close">&times;</span>
	</div>




<div>
	

<div style="padding: 14px;">

<div style="margin:0 10px;font-size: 13px;font-family: monospace;">reach us here our live specialist will attend to you</div>

</div>



<br>
<br>




<div style="padding: 12px;">
	<img src="https://slasafe.online/sophia.jpg"  style="width:35px;height:35px;border-radius:50%;float: left;font-size: 30px;">

<div style="margin:0 40px;width: 260px;font-size: 11px;font-family: arial;"><p id="talk"><img src="hloading.gif" style="height:40px;width:60px;" />
    </p></div>

</div>


<?php 

if (isset($firstname)) {
	echo '<input type="hidden" id="namedata" value="'. $firstname. '">';
}else{

	echo '<input type="hidden" id="namedata" value="Guest">';


}


    ?>





</div>


    <div id="mainmessage" style="width: 320px;height: 150px;padding: 5px;position: relative;">
    	


    </div>



<div style="width:98%;position: absolute;padding: 8px;bottom: 0;background: rgb(240,240,240);">

<form id="fform" action="/" method="" onsubmit="return false;">
	

<label style="font-family: cursive;font-size:11px;">Message:</label><input type="text" id="mailmessage" style="border: none;outline: none;background: rgb(240,240,240);" name="">

<button id="ssmail" style="display:inline-block;margin-left:27px;font-size:13px;cursor:pointer;border: none;outline: none;color:rgb(103, 61, 230);font-weight: 800;"><i style="display: inline-block;" class="fas fa-paper-plane"></i></button>


</form>

<script type="text/javascript">
	

       $("#ssmail").click(function(){

           

           var input = $("#mailmessage").val();


           $.post("supportcontact.php",{message:input}, function(data){
                         

            $("#mainmessage").html(data);
  });  


        
         $("#fform").trigger('reset');
  
              

       });

</script>



<script type="text/javascript">
	
         	



</script>


</div>










</div>








    <span style="cursor:pointer;display:inline-block;position: fixed;z-index:1;right: 26px;bottom:28px;padding: 18px;border-radius:50%;background:rgb(103, 61, 230);color:white;box-shadow: 0px 2px 2px gray;"
class="support" id="support" 
    >
    	<i class="fas fa-comments"></i>

    </span>



    

<script type="text/javascript">
	
var userdata = $('#namedata').val();


$('#support').click(function(){


	$('#supportcontainer').animate({height: "470px",width: "320px"});


	setInterval(function(){ 
         	$('#talk').html("I'm Jessica lora welcome to slasafe, <b>Hi " + userdata + "</b> how may i help you");
        
}, 5000);

})


$('#close').click(function(){


	$('#supportcontainer').animate({height: "0",width: "0"});

})





</script>



