
var firstname,lastname,email,phone_number,state,day,month,year,hometown,currency,country,file,account_type,address,password,confirm,data;

// preparing variables 

function _(el){

return document.getElementById(el);


}




// ..beginning of form validation...



function register(){


firstname = _('firstname');
lastname =_('lastname');
email = _('email');
phone_number = _('phone_number');
state = _('state');
hometown = _('hometown');
address = _('address');
day = _('day');
month = _('month');
year = _('year');
currency = _('currency');
country = _('country');
account_type = _('account_type');
file = _('file');
 password = _('password');
confirm = _('confirm');




file = _('file').files[0];






var formdata = new FormData();

formdata.append('firstname', firstname.value);
formdata.append('lastname', lastname.value);
formdata.append('email', email.value);
formdata.append('phone_number', phone_number.value);
formdata.append('state', state.value);
formdata.append('hometown', hometown.value);
formdata.append('country', country.value);
formdata.append('address', address.value);
formdata.append('day', day.value);
formdata.append('month', month.value);
formdata.append('year', year.value);
formdata.append('account_type', account_type.value);
formdata.append('currency', currency.value);
formdata.append('password', password.value);
formdata.append('confirm', confirm.value);
formdata.append('file', file);


var ajax = new XMLHttpRequest();

ajax.upload.addEventListener('progress', progressHandle, false);
ajax.addEventListener('load', completeHandle, false);
ajax.addEventListener('error', errorHandle, false);
ajax.addEventListener('abort', abortHandle, false);
ajax.open("POST", "register_server.php");
ajax.send(formdata);



}


function progressHandle(event){

    _('loaded').innerHTML = "uploaded " + event.loaded + "bytes of " + event.total;

var percent = (event.loaded / event.total) * 100;

_('progressbar').value = Math.round(percent);
_('status').innerHTML = Math.round(percent) + "% upload... please wait";


}

function completeHandle(event){

_('status').innerHTML = event.target.responseText;

_('progressbar').value = 0;

}

function errorHandle(event){

_('status').innerHTML = "upload failed";



}

function abortHandle(event){

_('status').innerHTML = "upload aborted";



}




