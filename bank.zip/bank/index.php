<!DOCtype
 html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Slasafe online bank</title>
<?php

require 'start.php';

include "head.php";

?>


<meta name="description" content="" />

		
<meta http-equiv="x-ua-compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no " />
<link rel="canonical" href=""  />


<meta property="og:site_name" content="" />
<meta property="og:url" content="" />
<meta property="og:title" content="" />

<meta property="og:description" content="" />
<meta property="og:image" content=""/>
<meta property="og:image:width" content="500" />
<meta property="og:image:height" content="500" />
<meta property="og:type" content="website" />





</head>


<body >


<?php

include "header.php";

?>

<img class="ghgh" src="poster.jpg"  width="100%">


<div style="background-image: url('photo.jpg');background-color: #cccccc;background-position: center; background-repeat: no-repeat; 
  background-size: cover;min-height:500px;">


    
    <br>

<center>

<div class="g-contain" style="margin:5px;margin-top:20px;background:white;height:440px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
    
    <img src="newaccount.jpg" width="100%" height="200px">
    
    
    <br>
    <br>
    
    <center>
        
        

<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;line-height: 31px;">   <a href="/new-account.php">       Open an account
</a></h1>

      <div class="columns large-8 large-push-4 small-11 small-push-1 content-wrapper">

    <p class="cnx-regular copy ">
            Consider the benefits of opening a Slasafe bank Advantage Banking Account.
    </p>


    <span class="cta-container primaryCta ">
          <span class="spa-btn spa-btn--primary spa-btn--medium masthead-cta-btn"><a href="author_reg.php">Open account<span class="ada-hidden"> Click to open a checking account.</span></a></span>
    </span>


</div>
      
      
</center>

    
</div>





<div class="g-contain" style="margin:5px;margin-top:20px;background:white;height:440px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
    
    <img src="loan.jpg" width="100%" height="200px">
    
    
    
    <br>
    
    <br>
    <center>
        
        

<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;line-height: 31px;">   <a href="/apply-for-loan">  Apply for loan
</a></h1>

      <div class="columns large-8 large-push-4 small-11 small-push-1 content-wrapper">

    <p class="cnx-regular copy ">
           See the benefits of opening a Slasafe loan  Account.
    </p>


    <span class="cta-container primaryCta ">
          <span class="spa-btn spa-btn--primary spa-btn--medium masthead-cta-btn"><a href="author_reg.php">Open account<span class="ada-hidden"> Click to open a loan account.</span></a></span>
    </span>


</div>
      
      
</center>

    
</div>







<div class="g-contain" style="margin:5px;margin-top:20px;background:white;height:440px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
        
        <img src="creditcard.jpg" width="100%" height="200px">

    
    
    <br>
    
    <br>
    <center>
        
 

<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;line-height: 31px;">    <div tabindex="-1" class="heading">Add your credit card </div>
</h1>

      
      <div class="info-box">
    <div tabindex="-1" class="ada-hidden ios-fix"></div>
    <div tabindex="-1" class="subheading">Get the right card for you. You can check for personalized offers in 60&nbsp;seconds.</div>
      <div tabindex="-1" class="link chevron-right" style="">Get started<span class="ada-hidden"> Check credit card offers</span></div>
  </div>
      
      
      
</center>
    <br>


    
</div>



<div class="g-contain" style="margin:5px;margin-top:20px;background:white;height:440px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
    
    <img src="ads.jpg" width="100%" height="200px">
    
    
    
    <br>
    
    
    <br>
    
    
    <center>
        
        

<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;line-height: 32px;">   <a href="/about"> Our financial company
</a></h1>

      <div class="columns large-8 large-push-4 small-11 small-push-1 content-wrapper">

    <p class="cnx-regular copy ">
        
       Slasafe Corporation is an American multinational investment bank and financial services holding company headquartered in Charlotte, North Carolina.
    </p>


   

</div>
      
      
</center>

    
</div>

      
</center>


  <br>

  <br>


<br>
<br>
<br>
<br>

 <center>
   
      <img class="ghgh" src="slasafe.jpg" >



 </center>   


    
</div>



</center>

</div>

<div >


  <br>
  <br>
  <br>
<center >





<div class="rc-subtitle"><h1 style="font-style: 38px;">Successful Clients</h1></div>
<h2 class="rc-title">Trusted By 100,000+ Users</h2>
<div class="rc-description"><h4 class="dsds" style="font-style: 28px;">Slasafe is one of the <b>world’s largest and most secure online banking platform</b> used by thousands of clients.</h4></div>
</div>
<div class="clearboth"></div>
</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">

</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
<div id="text-block-8" class="mk-text-block   ">
<p><a href="https://www.google.com/maps/contrib/100895882319332074954/place/ChIJhw2dypSXwoARSdJlxDl--9g/@34.6163804,-108.4824378,4z/data=!4m6!1m5!8m4!1e1!2s100895882319332074954!3m1!1e1?hl=en-US"><img loading="lazy" class="alignnone wp-image-20161 size-medium" src="https://bitcoinira.com/wp-content/uploads/2020/09/frame-2-1-300x233.png" alt="" width="300" height="233" srcset="https://bitcoinira.com/wp-content/uploads/2020/09/frame-2-1-300x233.png 300w, https://bitcoinira.com/wp-content/uploads/2020/09/frame-2-1.png 588w" sizes="(max-width: 300px) 100vw, 300px"></a></p>
<div class="clearboth"></div>
</div>
</div></div></div>
</div>
<div id="featured-row-listing" class="wpb_row vc_inner vc_row vc_row-fluid    attched-false   ">
<div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
<div id="text-block-9" class="mk-text-block   ">

<div class="clearboth"></div>
</div>
</div>

</center>

</div>


<center>
  
  <h2 class="">Why choose Slasafe Online bank?</h2>

</center>





<div class="MuiBox-root-112">


  <div class="MuiGrid-root-380 ">

    <div class="MuiGrid-root-380 ">

    <div class="MuiBox-root-112 jss486 jss483" data-testid="reason-item">


<center>
    <img loading="lazy" data-src="https://www.worldremit.com/public-assets/static/8dcaa4f4aef514e44255226e4ee1f5f2/clock.svg" src="https://www.worldremit.com/public-assets/static/8dcaa4f4aef514e44255226e4ee1f5f2/clock.svg" alt="icon of a clock" class=" ls-is-cached lazyloaded" title="clock icon" width="64" height="64"></center>

    <div class="MuiBox-root-112 jss487">

    <h3 class="MuiTypography">We're Fast</h3><p class="MuiTypography">95% of our transfers are ready in minutes.</p></div>


  </div>

</div>
<div class="MuiGrid-root-380" style="display: inline-block;"><div class="MuiBox-root-112 jss488 jss483" data-testid="reason-item">


<center>

  <img loading="lazy" data-src="https://www.worldremit.com/public-assets/static/3b2d692d19d77c74d508c007927eba43/safe.svg" src="https://www.worldremit.com/public-assets/static/3b2d692d19d77c74d508c007927eba43/safe.svg" alt="icon illustrating a debit or credit card with a padlock to represent security" class=" ls-is-cached lazyloaded" title="safe icon" width="64" height="64">

</center>
  <div class="MuiBox-root-112 jss489">


  <h3 class="MuiTypography">We're Safe</h3><p class="MuiTypography">We use industry-leading technology to protect your money.</p></div></div></div><div class="MuiGrid-root-380 MuiGrid-item-382 MuiGrid-grid-sm-4-432">

  <div class="MuiBox-root-112 jss490 jss483" data-testid="reason-item">

<center>
    <img loading="lazy" data-src="https://www.worldremit.com/public-assets/static/b199e02fdc7aea2b68f7bf7259fc2040/value.svg" src="https://www.worldremit.com/public-assets/static/b199e02fdc7aea2b68f7bf7259fc2040/value.svg" alt="icon of a price tag with a percentage symbol in the middle " class=" ls-is-cached lazyloaded" title="value icon" width="64" height="64">

</center>

    <div class="MuiBox-root-112 jss491"><h3 class="MuiTypography">We're Low-Cost</h3><p class="MuiTypography">We offer better exchange rates and lower fees than most conventional banks and money transfer services.</p></div></div></div>
</div>

</div>


<style type="text/css">
  


  .MuiGrid-root-380{


    display: inline-block;
    margin: 9px;
  }


.MuiBox-root-112{

background: rgb(10,40,10);


}

  .MuiGrid-root-380{

color: white;
  }

.MuiBox-root-112{

color: white;


}

.MuiTypography{

  color: white;
}


@media screen and (max-width:980px){
    
  .MuiGrid-root-380{

color: white;
  }

.MuiBox-root-112{

color: white;


}

.MuiTypography{

  color: white;
}


  }



</style>

<div style="padding: 6px;">

  <br>

<div class="g-contain" id="g-contain" style="margin:5px;margin-top:20px;background:white;box-shadow:none;padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
    



<div class="slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" style="width: 256px;"><div><div class="vertical-col wpb_column vc_column_container vc_col-sm-4" style="width: 100%; display: inline-block;"><div class="vc_column-inner"><div class="wpb_wrapper">
                <div class="icon-holder element-heading  ">
                  <div class="icon">
                    <div class="svg-icon-sc icon-freelancer-8 new-brand">

<center>
                      <svg xmlns="http://www.w3.org/2000/svg" height="58" viewBox="0 0 58 58" width="58">
  <defs>
    <style>
    .new-brand.icon-freelancer-8 .st-1 {
      fill: #e2e4e6;
    }

      .new-brand.icon-freelancer-8 .st-2,
    .new-brand.icon-freelancer-8 .st-5 {
      fill: #fff;
    }

    .new-brand.icon-freelancer-8 .st-2,
    .new-brand.icon-freelancer-8 .st-4 {
      stroke: #333;
      stroke-miterlimit: 10;
      stroke-width: 1.5px;
    }

    .new-brand.icon-freelancer-8 .st-3 {
      fill: #ff4800;
    }

    .new-brand.icon-freelancer-8 .st-4 {
      fill: none;
    }
    </style>
  </defs>
  <circle class="st-1" cx="29" cy="29" r="29"></circle>
  <g transform="translate(3.7 4)">
    <g transform="translate(13.3 1)">
      <path class="st-2" d="M31.1,49H0V0H31.1A3.842,3.842,0,0,1,35,3.9V45.1A3.842,3.842,0,0,1,31.1,49Z" transform="translate(3)"></path>
      <g transform="translate(0 6.5)">
        <path class="st-2" d="M6,.5H0"></path>
        <path class="st-2" d="M6,.5H0" transform="translate(0 7)"></path>
        <path class="st-2" d="M6,.5H0" transform="translate(0 14)"></path>
        <path class="st-2" d="M6,.5H0" transform="translate(0 21)"></path>
        <path class="st-2" d="M6,.5H0" transform="translate(0 28)"></path>
        <path class="st-2" d="M6,.5H0" transform="translate(0 35)"></path>
      </g>
      <rect class="st-3" height="49" transform="translate(25)" width="5"></rect>
      <rect class="st-4" height="49" transform="translate(25)" width="5"></rect>
    </g>
    <path class="st-2" d="M0,10V1.9A2.042,2.042,0,0,1,2.2,0H5.9A2.011,2.011,0,0,1,8,1.9V10Z" transform="translate(0.3)"></path>
    <path class="st-3" d="M8,34.6,4,41.4,0,34.6V0H8Z" transform="translate(0.3 10)"></path>
    <path class="st-5" d="M8,0H0L4,7.1Z" transform="translate(0 44)"></path>
    <path class="st-4" d="M8,33.7,4.5,40.4a.488.488,0,0,1-.9,0L0,33.7V0H8Z" transform="translate(0.3 10)"></path>
    <path class="st-2" d="M.5,34V0" transform="translate(3.8 10)"></path>
    <path class="st-2" d="M8,.5H0" transform="translate(0.3 43.5)"></path>
    <path class="st-2" d="M0,5V1.9A2.042,2.042,0,0,1,2.2,0H5.9A2.011,2.011,0,0,1,8,1.9V5Z" transform="translate(0.3)"></path>
  </g>
</svg>

</center>






<br>









</div>
                  </div>
                  <div class="icon-content">
                    
                    <p></p>
<h2>Freelancers &amp; service providers</h2>
<p></p>
                  </div>
                </div><div class="vc_row wpb_row section vc_row-fluid vc_inner  disable_negative_margin" style=" text-align:left;"><div class=" full_section_inner clearfix"><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-xs-6"><div class="vc_column-inner"><div class="wpb_wrapper">
  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-fiverr-grey-1.png.webp" type="image/webp"><img width="77" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-fiverr-grey-1.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-upwork-grey.png.webp" type="image/webp"><img width="89" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-upwork-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-shutterstock-grey.png.webp" type="image/webp"><img width="123" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-shutterstock-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-crossover-grey.png.webp" type="image/webp"><img width="135" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-crossover-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-xs-6"><div class="vc_column-inner"><div class="wpb_wrapper">
  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-adobe-grey.png.webp" type="image/webp"><img width="88" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-adobe-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-onehourtranslator-grey.png.webp" type="image/webp"><img width="111" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-onehourtranslator-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-gettyimages-grey.png.webp" type="image/webp"><img width="124" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-gettyimages-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-welocalize-grey.png.webp" type="image/webp"><img width="127" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-welocalize-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>
</div></div></div></div></div></div></div></div></div></div>





    
</div>






<div class="g-contain" id="g-contain" style="margin:5px;margin-top:20px;background:white;box-shadow:none;padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
   


<div class="slick-slide slick-active" data-slick-index="1" aria-hidden="false" style="width: 256px;"><div><div class="vertical-col wpb_column vc_column_container vc_col-sm-4" style="width: 100%; display: inline-block;"><div class="vc_column-inner"><div class="wpb_wrapper">
                <div class="icon-holder element-heading  ">
                  <div class="icon">
                    <div class="svg-icon-sc icon-ecommerce-7 new-brand">
<center>
                      <svg xmlns="http://www.w3.org/2000/svg" height="66" viewBox="0 0 66 66" width="66">
  <defs>
    <style>
    .new-brand.icon-ecommerce-7 .st-1 {
      fill: #e2e4e6;
    }

    .new-brand.icon-ecommerce-7 .st-2 {
      fill: none;
      stroke: #333;
      stroke-miterlimit: 10;
      stroke-width: 1.064px;
    }

    .new-brand.icon-ecommerce-7 .st-3 {
      fill: #fff;
    }

    .new-brand.icon-ecommerce-7 .st-4 {
      fill: #ff8ccb;
    }

    .new-brand.icon-ecommerce-7 .st-5 {
      fill: #da54d8;
    }
    </style>
  </defs>
  <circle class="st-1" cx="33" cy="33" r="33"></circle>
  <path class="st-2" d="M.519.5.5.5.481.5Z" transform="translate(9 30)"></path>
  <rect class="st-3" height="27" transform="translate(9 26)" width="49"></rect>
  <path class="st-4" d="M.519.5.5.5.481.5Z" transform="translate(9 30)"></path>
  <path class="st-4" d="M.5.5h0Z" transform="translate(25 30)"></path>
  <path class="st-5" d="M46.5,0H4.428L0,10.917A8.141,8.141,0,0,0,7.77,19a8.106,8.106,0,0,0,7.729-8.08A8.185,8.185,0,0,0,23.345,19,8.019,8.019,0,0,0,31,10.917,8.229,8.229,0,0,0,38.9,19h.048A7.934,7.934,0,0,0,46.5,10.917,8.274,8.274,0,0,0,54.447,19h.1A7.85,7.85,0,0,0,62,10.917L57.569,0Z" transform="translate(2 12)"></path>
  <path class="st-3" d="M.519.5.5.5.481.5Z" transform="translate(9 30)"></path>
  <path class="st-3" d="M.5.5h0Z" transform="translate(25 30)"></path>
  <path class="st-2" d="M49,0V18H0V0" transform="translate(9 36)"></path>
  <path class="st-2" d="M0,13V0H8V13" transform="translate(39 38)"></path>
  <rect class="st-2" height="8" transform="translate(20 39)" width="10"></rect>
  <path class="st-2" d="M.519.5.5.5.481.5Z" transform="translate(9 31)"></path>
  <path class="st-2" d="M.5.5h0Z" transform="translate(25 31)"></path>
  <path class="st-2" d="M45.75,0H4.357L0,11.492c0,4.342,3.392,8.487,7.645,8.5,4.253-.017,7.6-4.163,7.6-8.5C15.25,15.843,18.7,20,22.97,20s7.53-4.157,7.53-8.508C30.5,15.843,34,20,38.271,20h.047c4.266,0,7.432-4.157,7.432-8.508C45.75,15.843,49.3,20,53.571,20h.1C57.933,20,61,15.843,61,11.492L56.643,0Z" transform="translate(3 12)"></path>
  <path class="st-2" d="M.5,8V0" transform="translate(17 16)"></path>
  <path class="st-2" d="M.5,8V0" transform="translate(33 16)"></path>
  <path class="st-2" d="M.5,8V0" transform="translate(48 16)"></path>
</svg>

</center>


</div>
                  </div>
                  <div class="icon-content">
                    
                    <p></p>
<h2>E-commerce marketplace sellers</h2>
<p></p>
                  </div>
                </div><div class="vc_row wpb_row section vc_row-fluid vc_inner  disable_negative_margin" style=" text-align:left;"><div class=" full_section_inner clearfix"><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-xs-6"><div class="vc_column-inner"><div class="wpb_wrapper">
  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-ebay-grey.png.webp" type="image/webp"><img width="65" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-ebay-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-amazon-grey.png.webp" type="image/webp"><img width="83" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-amazon-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-shopee-grey.png.webp" type="image/webp"><img width="103" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-shopee-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-cdiscount-grey.png.webp" type="image/webp"><img width="109" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-cdiscount-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-xs-6"><div class="vc_column-inner"><div class="wpb_wrapper">
  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-wish-grey.png.webp" type="image/webp"><img width="64" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-wish-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-lazadagroup-grey.png.webp" type="image/webp"><img width="85" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-lazadagroup-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-rakuten-grey.png.webp" type="image/webp"><img width="105" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-rakuten-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-tophatter-grey.png.webp" type="image/webp"><img width="126" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-tophatter-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>
</div></div></div></div></div></div></div></div></div></div>



</div>


<div class="g-contain" id="g-contain" style="margin:5px;margin-top:20px;background:white;box-shadow:none;padding:8px;display:inline-block;border-radius:0px 8px 0px 8px;overflow:hidden;">
   





<div class="slick-slide slick-active" data-slick-index="2" aria-hidden="false" style="width: 256px;"><div><div class="vertical-col wpb_column vc_column_container vc_col-sm-4" style="width: 100%; display: inline-block;"><div class="vc_column-inner"><div class="wpb_wrapper">
                <div class="icon-holder element-heading  ">
                  <div class="icon">
                    <div class="svg-icon-sc icon-marketing-9 new-brand">

<center>
                      <svg xmlns="http://www.w3.org/2000/svg" height="66" viewBox="0 0 66 66" width="66">
  <defs>
    <style>
    .new-brand.icon-marketing-9 .st-1 {
      fill: #e2e4e6;
    }

    .new-brand.icon-marketing-9 .st-2 {
      fill: #fff;
    }

    .new-brand.icon-marketing-9 .st-2,
    .new-brand.icon-marketing-9 .st-3 {
      stroke: #333;
      stroke-miterlimit: 10;
      stroke-width: 1.064px;
    }

    .new-brand.icon-marketing-9 .st-3 {
      fill: #0092f4;
    }
    </style>
  </defs>
  <circle class="st-1" cx="33" cy="33" r="33"></circle>
  <rect class="st-2" height="46.87" rx="1.552" transform="translate(5.739 8.609)" width="51.652"></rect>
  <path class="st-2" d="M0,.478H40.174" transform="translate(6.696 15.304)"></path>
  <path class="st-2" d="M23.911,30v6.221a1.937,1.937,0,0,1-.856,1.7,2.034,2.034,0,0,1-1.924.19L0,28.458V9.945L21.131.158a2.034,2.034,0,0,1,1.924.19,1.937,1.937,0,0,1,.856,1.7V25.869" transform="translate(40.174 16.261)"></path>
  <path class="st-3" d="M0,28.23,19.087,37.3l.044-.028V.034L19.077,0,0,9.074Z" transform="translate(39.217 16.261)"></path>
  <path class="st-2" d="M2.864,17.726l21.049,1.4V0L2.864,1.4A2.858,2.858,0,0,0,0,4.034V15.1A2.858,2.858,0,0,0,2.864,17.726Z" transform="translate(16.261 26.783)"></path>
  <path class="st-3" d="M4.414,11.478,0,0,10.432.721l2.959,10.758Z" transform="translate(21.043 43.043)"></path>
</svg>

</center>



</div>
                  </div>
                  <div class="icon-content">
                    
                    <p></p>
<h2>Digital marketing &amp; beyond</h2>
<p></p>
                  </div>
                </div><div class="vc_row wpb_row section vc_row-fluid vc_inner  disable_negative_margin" style=" text-align:left;"><div class=" full_section_inner clearfix"><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-xs-6"><div class="vc_column-inner"><div class="wpb_wrapper">
  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-google-grey.png.webp" type="image/webp"><img width="76" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-google-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-taboola-grey.png.webp" type="image/webp"><img width="78" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-taboola-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-cj-grey.png.webp" type="image/webp"><img width="130" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-cj-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-tradedoubler-grey.png.webp" type="image/webp"><img width="136" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-tradedoubler-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-xs-6"><div class="vc_column-inner"><div class="wpb_wrapper">
  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-airbnb-grey.png.webp" type="image/webp"><img width="96" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-airbnb-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-tujia-grey.png.webp" type="image/webp"><img width="94" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-tujia-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>

  <div class="wpb_single_image wpb_content_element vc_align_center">
    <div class="wpb_wrapper">
      
      <div class="vc_single_image-wrapper   vc_box_border_grey"><picture><source srcset="https://www.payoneer.com/wp-content/uploads/logo-homeaway-grey.png.webp" type="image/webp"><img width="139" height="70" src="https://www.payoneer.com/wp-content/uploads/logo-homeaway-grey.png" class="vc_single_image-img attachment-medium webpexpress-processed" alt="" loading="lazy"></picture></div>
    </div>
  </div>
</div></div></div></div></div></div></div></div></div></div>



</div>



  <br>


</div>

<?php



include 'footer.php';


?>


<style type="text/css">
  

    .ghgh{
    height: auto;
 width:100%;
  }
    


@media screen and (max-width:980px){
    
    body{
      background: white;
    }
    .ghgh{
    margin-top:-118px ;
height: 235px;
 width:100%;

  }
    
    .header{

      min-height: 200px;
    }


    .header-image{

       margin: 24px;
       margin-left: 140px;


    }
}

</style>

<style type="text/css">
  

h1{


  line-height: 32px;
}

.featured-item{


  display: inline-block;

  margin: 8px;
}


    .g-contain{

width:270px;

  }
    



    #g-contain{

width:400px;

  }


@media screen and (max-width:980px){
    
    .g-contain{
 
width:87%;

  }


.rc-subtitle,.dsds,.featured-item,.rc-title{


  color:;
}


    #g-contain{

width:92%;

  }
    
    
}



</style>


</body>

</html>