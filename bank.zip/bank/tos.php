<?php 

?>
<!DOCTYPE html>
<html>
<head>
	<title>Terms of Use</title>



<?php

include 'head.php';

?>
</head>
<body>

<?php

include 'header.php';

?>



<br>

<h1>Terms of service</h1>







<?php

include 'footer.php';

?>



</body>
</html>