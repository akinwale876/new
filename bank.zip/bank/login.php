<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>login - Slasafe Online Bank</title>


<meta property="og:locale" content="en_US">
<?php

include "head.php";

?>



<meta name="robot" content="noindex" />

</head>




<body style="background-image: url('photo.jpg');background-color: #cccccc;background-position: center;
  background-repeat: no-repeat;
  background-size: cover; ">
    


    
<div style="margin-top:40px;">

 
    


<center>
    
<div  style="margin-top:90px;background:white;width:300px;min-height:360px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;border-radius:0px 8px 0px 8px;">
    
    
    <center>
        
        

<a href="https://<?php echo $_SERVER['SERVER_NAME']?>">
    
    
    <div class="header-image" style="display:inline-block;">  

</div>
<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;color:black;line-height: 32px;">Slasafe Online Bank</h1>
</a>  

      <h4>Login to your account</h4>
</center>
 

    
        <form method="post" action="admin.php" name="form" id="sub">
            
                 <div>
                        <input type="email" name="email" id="email" placeholder="Enter Email" required>
                 </div>
            
                 <div>
                        <input type="password" placeholder="Enter Password" id="password" name="password">
                 </div>
            
                 <div>
                        <button class="logbutton" type="submit" style="border:none;cursor:pointer;padding:9px;"   name="submit">Login! <i class="fas fa-sign-in-alt"></i></button>
                 </div>
            
            
        </form>
    <br>

    
      <div style="font-size:14px;font-family:cursive;">don't have an account:<a href="/create" style="margin-left:3px;">create one</a></div>


    
</div>
</center>

<script>
    
    
    
    
    
$('#sub').submit(function(){

var email = $('#email').val();
var password = $('#password').val();


  if(email == '' || password == ''){
      
      alert('fill in your details')
  }
          
});

    
    
    
    
</script>

</div>


<?php

include "footer.php";

?>

<style>
    
    
    .logbutton{
        
        
         background:black;
         color:white;
        
    }
    
    .logbutton:hover{
        
        
         background:rgb(30,30,190);
         color:white;
        
    }
    
    
</style>



</body>

</html>