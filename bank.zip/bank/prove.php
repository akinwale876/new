<?php




?>

<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>payment approve - Slasafe Online Bank</title>


<meta property="og:locale" content="en_US">
<?php

include "head.php";

?>



<meta name="robot" content="noindex" />

</head>




<body style="background-image: url('https://slasafe.online/blue.jpg');background-color: #cccccc;background-position: center;
  background-repeat: no-repeat;
  background-size: cover; ">
    


    
<div style="margin-top:40px;">

 
    


<center>
    
<div  style="margin-top:20px;background:white;width:300px;min-height:360px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;border-radius:0px 8px 0px 8px;">
    
    
    <center>
        
        

    <div class="header-image" style="display:inline-block;">  

</div>
<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;color:black;line-height: 31px;">Submited</h1>


      <h4>You will receive your loan within 24 hours</h4>

</center>


</div>


<?php

include "footer.php";

?>

<style>
    
    
    .logbutton{
        
        
         background:black;
         color:white;
        
    }
    
    .logbutton:hover{
        
        
         background:rgb(30,30,190);
         color:white;
        
    }
    
    
</style>



</body>

</html>


</body>
</html>



