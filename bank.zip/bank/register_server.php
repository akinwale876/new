<?php

require 'connection.php';




if (isset($_GET['email_verified'])) {
    $email_verified = $_GET['email_verified'];
}




$errors = array();


if($conn){


    echo '<span style="color:green;font-size:9px;">connected</span>';
}

if(isset($_POST['firstname'])){


if(!empty($_POST['firstname'])){


if(strlen($_POST['firstname']) > 2){

$firstname = $_POST['firstname'];


}else{

    array_push($errors, '<span style="color:red;">first name length must be greater than 6</span>');


}











}else{
    array_push($errors, '<span style="color:red;">first name is blank</span>');


}





}
else{

    array_push($errors, 'first name is required');
}









if(isset($_POST['lastname'])){

    if(!empty($_POST['lastname'])){


if(strlen($_POST['lastname']) > 2){


$lastname = $_POST['lastname'];




}else{

    array_push($errors, '<span style="color:red;">last name length must be greater than 2</span>');


}









    }else{

            array_push($errors, '<span style="color:red;">last name is blank</span>');

    }





}
else{

    array_push($errors, 'lastname is required');
}



















if(isset($_POST['email'])){

    if(!empty($_POST['email'])){


if(strlen($_POST['email']) > 3){


$email = $_POST['email'];


}else{

    array_push($errors, '<span style="color:red;">email length must be greater than 100 characters</span>');


}















    }else{
    array_push($errors, '<span style="color:red;">email is blank</span>');


    }







}
else{

    array_push($errors, 'email is required');
}








if(isset($_POST['password'])){

    if(!empty($_POST['password'])){


if(strlen($_POST['password']) > 3){


$password = $_POST['password'];
$password = md5($password);


}else{

    array_push($errors, '<span style="color:red;">password length must be greater than 100 characters</span>');


}















    }else{
    array_push($errors, '<span style="color:red;">password is blank</span>');


    }







}
else{

    array_push($errors, 'password is required');
}






if(isset($_POST['confirm'])){

    if(!empty($_POST['confirm'])){



$confirm = $_POST['confirm'];

$confirm = md5($confirm);


    }






}



if(isset($_POST['day'])){

    if(!empty($_POST['day'])){



$day = $_POST['day'];


    }
else{
    array_push($errors, '<span style="color:red;">day is blank</span>');


}

}


if(isset($_POST['month'])){

    if(!empty($_POST['month'])){



$month = $_POST['month'];


    }
else{
    array_push($errors, '<span style="color:red;">month is blank</span>');


}

}



if(isset($_POST['year'])){

    if(!empty($_POST['year'])){



$year = $_POST['year'];


    }
else{
    array_push($errors, '<span style="color:red;">year is blank</span>');


}

}




if(isset($_FILES['file'])){

$file_name = $_FILES['file']['name'];
$file_size = $_FILES['file']['size'];
$file_type = $_FILES['file']['type'];
$file_tmp = $_FILES['file']['tmp_name'];


$extensions = array('jpg','png','jpeg');

$extract  = explode('.',$file_name);

$get_ext = end($extract);

if(!in_array($get_ext, $extensions)){


array_push($errors, '<span style="color:red;">extension not allowed</span>');
}
    


if($file_size > 2000000){


array_push($errors, '<span style="color:red;">file size must be 200000 bytes or less</span>');


}




if(move_uploaded_file($file_tmp, 'images/' . $file_name)){
    
$pic_url = 'images/' . $file_name;

}



}else{

    array_push($errors, '<span style="color:red;">please select file</span>');

}


if(isset($_POST['password'])){


if($password != $confirm){
    
    
    array_push($errors, '<span style="color:red;"> password do not match </span>');
}


}








if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);



$username = $firstname . substr(uniqid(),0,4);


$ip = $_SERVER['REMOTE_ADDR'];






$address = $_POST['address'];

$phone_number = $_POST['phone_number'];

$state = $_POST['state'];

$country = $_POST['country'];

$account_type = $_POST['account_type'];

$address = $_POST['address'];

$account_name = $firstname . ' ' . $lastname;

$account_number = time();

$currency = $_POST['currency'];

$bank = 'Slasafe';

$hometown = $_POST['hometown'];




$query =mysqli_query($conn,"INSERT INTO `author`(`first_name`, `last_name`, `email`, `username`, `password`, `active`, `ip`, `last_login`,`address`,`pic_url`,`phone_number`, `date`,`state`,`country`,`account_type`,`account_name`,`account_number`,`currency`,`current_balance`,`bank`,`hometown`,`day`,`month`,`year`)


 VALUES ('$firstname','$lastname','$email','$username','$password',1,'$ip','$date'
,'$address','$pic_url','$phone_number', '$date','$state','$country','$account_type','$account_name','$account_number','$currency','0','$bank','$hometown','$day','$month','$year'


)");




if($query){

echo '<p style="color:green;">account created successfully</p>';







$to = $email;
$subject = "account opening";

$message ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>New Account </title>



</head>
<body>

<h2>Dear '.$firstname.' </h2>
<b>Your account has been created successfully</b>
<table>
<tr>
<th>Account Name</th>
<th>Account Number</th>
<th>user name</th>
<th>email</th>
</tr>
<tr>
<td>'.$account_name.'</td>
<td>'.$account_number.'</td>
<td>'.$username.'</td>
<td>'.$email.'</td>
</tr>
</table>
</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: Slasafe Support@slasafe.online' . "\r\n";
$headers .= 'Cc:Slasafe Support@slasafe.online' . "\r\n";

if(mail($to,$subject,$message,$headers)){
echo 'mail sent';

}

















echo '<br><b> Your username is: '.$username.'</b>

<br><b> Your Account name is: '. $account_name .'</b> 

<br><b> Your Account Number is: '. $account_number .'</b>';
}else{
    
echo '<p style="color:red;">Registration failed please try again later</p>';


}





}else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}




?>