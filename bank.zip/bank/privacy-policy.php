

<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Privacy Policy - Slasafe online bank</title>

<?php

require 'start.php';

include "head.php";

?>


<meta name="description" content="Privacy Policy - Slasafe online bank" />

		
<meta http-equiv="x-ua-compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no " />
<link rel="canonical" href=""  />


<meta property="og:site_name" content="" />
<meta property="og:url" content="" />
<meta property="og:title" content="" />

<meta property="og:description" content="Privacy Policy - Slasafe online bank" />
<meta property="og:image" content=""/>
<meta property="og:image:width" content="500" />
<meta property="og:image:height" content="500" />
<meta property="og:type" content="website" />


</head>

<body style="background: white;">




<?php

include "header.php";

?>


<div style="background-image: url('policy.jpg');background-color: #cccccc;background-position: center; background-repeat: no-repeat; 
  background-size: cover;min-height:200px;">


</div>

<h1>Privacy Policy</h1>
<p>


<p>International Privacy Notices
The following privacy notices apply as described more specifically in the notices, for example, they apply to personal data that Slasafe businesses outside of the United States collect about representatives of their commercial customers. For privacy notices that apply to certain non-Slasafe employees, such as employees of vendors providing services to Slasafe, see the International Non-Employee Privacy Notices below.

<p>
The following apply internationally except for the European Union and countries and businesses which have separate privacy notices (see below):

<p>
International Privacy Notice (English) (PDF)
International Privacy Notice (Chinese - Simplified) (PDF)
International Privacy Notice (Chinese - Traditional) (PDF)
International Privacy Notice (Japanese) (PDF)
International Privacy Notice (Spanish-Latin America) (PDF)
The following apply to the specific regions and businesses listed below:

<p>
Australia
Canada
European Union (EU)
New Zealand
South Korea
⁠International Non-Employee Privacy Notices
The following privacy notices apply to certain non-slasafe employees, for example, employees of vendors providing services to slasafe, as described more specifically in the notices.

<p>
The following Non-Employee privacy notice applies internationally except for the European Union and countries which have separate privacy notices (see below):

International Non-Employee Privacy Notice - General (English) (PDF)
The following Non-Employee privacy notices apply to the specific regions listed below:

<p>
Canada
European Union
South Korea
Global Data Access
slasafe strives to satisfy our customers’ financial needs and provide services to help you succeed financially. To do this, slasafe, our affiliated companies, and our service providers located throughout the world may need to access your information. When your information is accessed, we maintain protective measures as described in our privacy policies and notices.


</body>
</html>




