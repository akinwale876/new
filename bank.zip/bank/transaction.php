<?php




require 'connection.php';



include 'admin_init.php';




$errors = array();


if($conn){


}

if(isset($_POST['to_account'])){


if(!empty($_POST['to_account'])){


if(strlen($_POST['to_account']) > 3){

$to_account = $_POST['to_account'];


}else{

    array_push($errors, '<span style="color:red;">account name length must be greater than 6</span>');


}











}else{
    array_push($errors, '<span style="color:red;">to account is blank</span>');


}





}
else{

    array_push($errors, 'to account is required');
}














if(isset($_POST['currency'])){

    if(!empty($_POST['currency'])){


$currency = $_POST['currency'];

}

}

if(isset($_POST['transaction_type'])){

    if(!empty($_POST['transaction_type'])){


if(strlen($_POST['transaction_type']) > 3){


$transaction_type = $_POST['transaction_type'];


}else{

    array_push($errors, '<span style="color:red;">transaction type length must be greater than 100 characters</span>');


}






    }else{
    array_push($errors, '<span style="color:red;">type is blank</span>');


    }


}
else{

    array_push($errors, 'type is required');
}








if(isset($_POST['amount'])){

    if(!empty($_POST['amount'])){


if(strlen($_POST['amount']) > 2){


$amount = $_POST['amount'];

}else{

    array_push($errors, '<span style="color:red;">amount length must be greater than 100 characters</span>');


}















    }else{
    array_push($errors, '<span style="color:red;">amount is blank</span>');


    }







}
else{

    array_push($errors, 'amount is required');
}






if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);



$qquery =mysqli_query($conn,"SELECT * FROM `author` WHERE account_number = '$account_number' LIMIT 1");

if(mysqli_num_rows($qquery) == 1){
    
$dsd  = mysqli_fetch_array($qquery);

$testamount = $dsd['current_balance'];

if($testamount > $amount){
    

 

$qqueryy = mysqli_query($conn,"SELECT * FROM `author` WHERE account_number = '$to_account' LIMIT 1");

if(mysqli_num_rows($qqueryy) > 0){
    
    
    
    
mysqli_query($conn,"UPDATE `author` SET `current_balance` = `current_balance` + '$amount' WHERE `account_number` = '$to_account' LIMIT 1");




$qqueryyes = mysqli_query($conn,"UPDATE `author` SET `current_balance` = `current_balance` - '$amount' WHERE `account_number` =  '$account_number' LIMIT 1");


if($qqueryyes){
    
    
    echo 'Transaction successful - ';
    
    $qqu = mysqli_query($conn,"SELECT * FROM `author` WHERE account_number = '$to_account' LIMIT 1");
    
    mysqli_query($conn,"INSERT INTO `transactions`(`transaction_type`,`from_name`,`amount`,`from`,`to`,`currency`,`date`) VALUES('$transaction_type','$account_name','$amount','$account_number','$to_account','$currency','$date') ");

    
    
$dss  = mysqli_fetch_array($qqu);

$to_email = $dss['email'];
$to_name = $dss['account_name'];
$to_currency = $dss['currency'];
    
$to = $to_email;
$subject = "Credit";

$message ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>Credit</title>



</head>
<body>

<h2>Dear '.$to_name.' </h2><p>Your account has been credited with <b>'.$to_currency. number_format($amount). '</b></p>

<table>
<tr>
<th>From</th>
<th>Account Number</th>
<th>Amount</th>
</tr>
<tr>
<td>'.$account_name.'</td>
<td>'.$account_number.'</td>
<td>'.$amount.'</td>
</tr>
</table>
</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: Slasafe Support@slasafe.online' . "\r\n";
$headers .= 'Cc:Slasafe Support@slasafe.online' . "\r\n";

if(mail($to,$subject,$message,$headers)){
echo 'o';

}



$subject2 = "Credit";

$message2 ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>Debit</title>



</head>
<body>

<h2>Dear '.$account_name.' </h2><p>Your account has been Debited with <b>'.$to_currency. number_format($amount). '</b></p>


</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: Slasafe Support@slasafe.online' . "\r\n";
$headers .= 'Cc:Slasafe Support@slasafe.online' . "\r\n";

if(mail($email,$subject2,$message2,$headers)){
echo 'k';

}








    
}


$qqueryye = mysqli_query($conn,"SELECT * FROM `author` WHERE account_number = '$to_account' LIMIT 1");


}else{
    
    echo '<b style="color:red;font-size:19px;">receipent account does not exist</b>';
}
 
    
}
else{
    
   echo '<span style="color:red;font-size:19px;">insufficient fund</span>';
}




    
}else{
    
    
    echo 'no rows' . $account_number;
}


}else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}




?>