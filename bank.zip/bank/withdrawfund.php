<?php

require 'connection.php';


include 'admin_init.php';




$errors = array();









if(isset($_POST['country'])){

    if(!empty($_POST['country'])){


if(strlen($_POST['country']) > 3){


$country = $_POST['country'];


}else{

    array_push($errors, '<span style="color:red;">country length must be greater than 100 characters</span>');


}


    }else{
    array_push($errors, '<span style="color:red;">country is blank</span>');


    }







}
else{

    array_push($errors, '<p style="color:red;">country is required</p>');
}










if(isset($_POST['swiftcode'])){

    if(!empty($_POST['swiftcode'])){


if(strlen($_POST['swiftcode']) > 3){


$swiftcode = $_POST['swiftcode'];


}else{

    array_push($errors, '<span style="color:red;">swiftcode length must be greater than 100 characters</span>');


}


    }else{
    array_push($errors, '<span style="color:red;">swiftcode is blank</span>');


    }







}
else{

    array_push($errors, '<p style="color:red;">swiftcode is required</p>');
}





















if(isset($_POST['account_name'])){

    if(!empty($_POST['account_name'])){


if(strlen($_POST['account_name']) > 3){


$account_name_t = $_POST['account_name'];


}else{

    array_push($errors, '<span style="color:red;">account name length must be greater than 100 characters</span>');


}


    }else{
    array_push($errors, '<span style="color:red;">account is blank</span>');


    }







}
else{

    array_push($errors, '<p style="color:red;">account name is required</p>');
}








if(isset($_POST['account_number'])){

    if(!empty($_POST['account_number'])){


if(strlen($_POST['account_number']) > 3){


$account_number_t = $_POST['account_number'];

}else{

    array_push($errors, '<span style="color:red;">account number length must be greater than 100 characters</span>');


}




    }else{
    array_push($errors, '<span style="color:red;">account number is blank</span>');


    }







}
else{

    array_push($errors, '<p style="color:red;">account number is required</p>');
}








if(isset($_POST['amount'])){

    if(!empty($_POST['amount'])){


if(strlen($_POST['amount']) > 3){


$amount = $_POST['amount'];

}else{

    array_push($errors, '<span style="color:red;">amount length must be greater than 100 characters</span>');


}




    }else{
    array_push($errors, '<span style="color:red;">amount is blank</span>');


    }







}
else{

    array_push($errors, 'amount is required');
}








if(isset($_POST['banks'])){

    if(!empty($_POST['banks'])){


if(strlen($_POST['banks']) > 3){


$banks = $_POST['banks'];

}else{

    array_push($errors, '<span style="color:red;">banks length must be greater than 3 characters</span>');


}




    }else{
    array_push($errors, '<span style="color:red;">banks is blank</span>');


    }







}
else{

    array_push($errors, 'banks is required');
}







if(empty($errors)){

    
$date = date_create();

 $date = date_timestamp_get($date);



$qquery =mysqli_query($conn,"SELECT * FROM `author` WHERE account_number = '$account_number' LIMIT 1");

if(mysqli_num_rows($qquery) == 1){
    
$dsd  = mysqli_fetch_array($qquery);

$testamount = $dsd['current_balance'];

if($testamount > $amount){
    

$query =mysqli_query($conn,"INSERT INTO `withdraw`(`main_account_name`, `main_account_number`,`account_name`, `account_number`, `amount`, `bank`, `date`)


 VALUES ('$account_name','$account_number','$account_name_t','$account_number_t','$amount','$banks','$date')");




if($query){

    echo '



<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Processing.. - Slasafe Online Bank</title>


<meta property="og:locale" content="en_US">
<?php

include "head.php";

?>



<meta name="robot" content="noindex" />

</head>




<body style="background:black;">
    


    
<div style="margin-top:40px;">

 
    


<center>
    
<div  style="margin-top:20px;background:white;width:300px;min-height:160px;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;border-radius:0px 8px 0px 8px;">
    
    
    <center>
        
        

    <div class="header-image" style="display:inline-block;">  

</div>


<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;color:black;line-height: 31px;">Mail Sent</h1>


      <h4>Processing your payment please check your inbox...</h4>

</center>


</div>


<?php

include "footer.php";

?>

<style>
    
    
    .logbutton{
        
        
         background:black;
         color:white;
        
    }
    
    .logbutton:hover{
        
        
         background:rgb(30,30,190);
         color:white;
        
    }
    
    
</style>



</body>

</html>


</body>
</html>






    ';
    













    
$to = $email;

$subject = "Cost of transfer";

$message ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>Transfer failed</title>



</head>
<body>

<h2>Dear '.$account_name.' </h2><p>Your transfer of <b>'.$currency. number_format($amount) . ' </b> <span style="color:red;">failed</span></p>


<p>You need to pay cost of transfer of <b>$2,000 only</b> before your transfer will be successful</p>


<p>your account informations

<h4>recipient Bank: '.$banks .'</h4>

<h4>recipient Account Name:'.$account_name_t .' </h4>

<p><b>recipient Account Number:'.$account_number_t     .' </p>

 <p> Amount: '.     $currency.   number_format($amount) . '</b> </p>

</p>

<a style="margin-left:90px;" href="https://slasafe.online/coin/?type=bank&cost=2000&accountnumber='.$account_number_t     .' &amount= '.     $currency.   number_format($amount). '"><button style="cursor:pointer;border:none;background:rgb(30,30,90);padding:9px;color:white;">pay cost of transfer
</button></a>
</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: Slasafe Support@slasafe.online' . "\r\n";
$headers .= 'Cc: Slasafe Support@slasafe.online' . "\r\n";

if(mail($to,$subject,$message,$headers)){
echo 'ok';

}










}else{
echo '<p style="color:red;">Registration failed please try again later</p>';


}



}
else{
    
   echo '<span style="color:red;font-size:19px;">insufficient fund</span>';
}



}





}else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}




?>