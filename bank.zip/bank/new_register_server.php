<?php

require 'connection.php';







$errors = array();


if($conn){


    echo '<span style="color:green;font-size:9px;">connected</span>';
}

if(isset($_POST['firstname'])){


if(!empty($_POST['firstname'])){


if(strlen($_POST['firstname']) > 2){

$firstname = $_POST['firstname'];


}else{

    array_push($errors, '<span style="color:red;">first name length must be greater than 6</span>');


}











}else{
    array_push($errors, '<span style="color:red;">first name is blank</span>');


}





}
else{

    array_push($errors, 'first name is required');
}









if(isset($_POST['lastname'])){

    if(!empty($_POST['lastname'])){


if(strlen($_POST['lastname']) > 2){


$lastname = $_POST['lastname'];




}else{

    array_push($errors, '<span style="color:red;">last name length must be greater than 2</span>');


}









    }else{

            array_push($errors, '<span style="color:red;">last name is blank</span>');

    }





}
else{

    array_push($errors, 'lastname is required');
}



















if(isset($_POST['email'])){

    if(!empty($_POST['email'])){


if(strlen($_POST['email']) > 3){


$email = $_POST['email'];


}else{

    array_push($errors, '<span style="color:red;">email length must be greater than 100 characters</span>');


}















    }else{
    array_push($errors, '<span style="color:red;">email is blank</span>');


    }







}
else{

    array_push($errors, 'email is required');
}










if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);





$token =  $firstname . uniqid() . $lastname;


$ip = $_SERVER['REMOTE_ADDR'];



$code = uniqid();




$query =mysqli_query($conn,"INSERT INTO `verification` (`first_name`, `last_name`, `email`, `ip`, `token`, `code`, `date`)
 VALUES ('$firstname','$lastname','$email','$ip','$token','$code','$date')");




if($query){

echo '<p style="color:green;">Mail sent to '. $email . '</p>';







$to = $email;
$subject = "Verify Email";

$message ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>Verify your email ...</title>



</head>
<body>

<h2>Dear '.$firstname.' </h2>

<p>Please verify your email by clicking the following link </p>
<div style="padding:80px;">


<a style="margin:30px;padding:10px;border:0.3px solid rgb(40,100,40);" href="https://slasafe.online/verify.php?first_name='.$firstname.'&last_name='.$lastname.'&token='.$token.'&code='.$code.'&email='.$email.'">Verify Here</a>

<div>
</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: Slasafe Verify Support@slasafe.online' . "\r\n";
$headers .= 'Cc:Slasafe Verify Support@slasafe.online' . "\r\n";

if(mail($to,$subject,$message,$headers)){
echo 'mail sent';

}










}else{
    
echo '<p style="color:red;">Registration failed please try again later</p>';


}





}else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}




?>