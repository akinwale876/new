<?php



require 'connection.php';

include 'admin_init.php';






$errors = array();


if(isset($_FILES['passport'])){

$file_name = $_FILES['passport']['name'];
$file_size = $_FILES['passport']['size'];
$file_type = $_FILES['passport']['type'];
$file_tmp = $_FILES['passport']['tmp_name'];


$extensions = array('jpg','png','jpeg');

$extract  = explode('.',$file_name);

$get_ext = end($extract);

if(!in_array($get_ext, $extensions)){


array_push($errors, '<span style="color:red;">extension not allowed</span>');
}
    


if($file_size > 2000000){


array_push($errors, '<span style="color:red;">file size must be 200000 bytes or less</span>');


}




if(move_uploaded_file($file_tmp, 'document/' . $file_name)){
    
$url = 'document/' . $file_name;

}



}else{

    array_push($errors, '<span style="color:red;">please select file</span>');

}



if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);
 
 

$query =mysqli_query($conn,"INSERT INTO `passport` (`account_name`, `account_number`, `url`, `date`) VALUES ('$account_name','$account_number','$url','$date')");



if($query){
    
    echo 'add successfully';
    
}

}
else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}









?>