


<?php   


define('root', $_SERVER['DOCUMENT_ROOT'] );


?>