<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>About us - Slasafe Online Bank </title>

<?php

include "head.php";

?>


</head>


<body>

<?php

include "header.php";

?>




<br>
<br>


<h1 style="font-style: 42px;margin-top: 0;">About Us</h1>




<div class="mas" style="background-image: url('photo.jpg');background-color: #cccccc;background-position: center; background-repeat: no-repeat; 
  background-size: cover;">


    </div>

<div class="body">
<br>
<br>

<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;line-height: 32px;"> Our financial company
</h1>

      <div class="columns large-8 large-push-4 small-11 small-push-1 content-wrapper">

    <p class="cnx-regular copy ">
        
       Slasafe Corporation is an American multinational investment bank and financial services holding company headquartered in Charlotte, North Carolina. The bank was founded in San Francisco, and took its present form when NationsBank of Charlotte acquired it in 1998.
    </p>


   

</div>

   
<div>
  

    
    <br>
    <br>


<div class="main">
  
        

<h2>One of the most trusted, licensed online banking service in the world
</h2>
 

<div class="grid-col grid-col--desktopSmall-6 grid-col--flushRight">
          <div class="licensing-subtitle">Headquartered in Charlotte, North Carolina, slasafe.online is licensed, bonded and regularly audited.</div>
          <p class="sectionHeading-subTitle">Government agencies perform regular audits of independently licensed banking companies. The audit examinations serve to protect public funds, determine safety and soundness of operations and determine compliance with bankin statutes and regulations.</p>
        </div>



</div>

<div class="sidebar">
  
      <img src="map.jpg" width="auto" height="200px">

</div>

</div>



    
    <br>
  








<h2>Making an Impact</h2>


<p>
  

Since 2007, our Environmental Business Initiative has helped finance sustainable business activities all across the globe. Our commitment provides financial and intellectual capital to develop solutions to climate change and other environmental challenges. We focus on low-carbon energy, energy efficiency, and sustainable transportation, in addition to addressing water conservation, land use, and more.

</p>




<br>
<br>

<div class="rc-subtitle"><h1 style="font-style: 38px;">Successful Clients</h1></div>
<h2 class="rc-title">Trusted By 100,000+ Users</h2>
<div class="rc-description">Slasafe is one of the <b>world’s largest and most secure online banking platform</b> used by thousands of clients.</div>
</div>
<div class="clearboth"></div>
</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">

</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
<div id="text-block-8" class="mk-text-block   ">
<p><a href="https://www.google.com/maps/contrib/100895882319332074954/place/ChIJhw2dypSXwoARSdJlxDl--9g/@34.6163804,-108.4824378,4z/data=!4m6!1m5!8m4!1e1!2s100895882319332074954!3m1!1e1?hl=en-US"><img loading="lazy" class="alignnone wp-image-20161 size-medium" src="https://bitcoinira.com/wp-content/uploads/2020/09/frame-2-1-300x233.png" alt="" width="300" height="233" srcset="https://bitcoinira.com/wp-content/uploads/2020/09/frame-2-1-300x233.png 300w, https://bitcoinira.com/wp-content/uploads/2020/09/frame-2-1.png 588w" sizes="(max-width: 300px) 100vw, 300px"></a></p>
<div class="clearboth"></div>
</div>
</div></div></div>
</div>
<div id="featured-row-listing" class="wpb_row vc_inner vc_row vc_row-fluid    attched-false   ">
<div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
<div id="text-block-9" class="mk-text-block   ">
<div class="featured-list">
<div class="featured-item title"><b style="'font-style: 30px;">Featured on:</b></div>
<div class="featured-item"><img loading="lazy" class="aligncenter wp-image-19943 size-full" src="https://bitcoinira.com/wp-content/uploads/2020/07/bitmap.png" alt="Bitcoin IRA on Forbes" width="88" height="22"></div>
<div class="featured-item"><img loading="lazy" class="aligncenter wp-image-19946 size-full" src="https://bitcoinira.com/wp-content/uploads/2020/07/wsj.png" alt="Bitcoin IRA on WSJ" width="47" height="23"></div>
<div class="featured-item"><img loading="lazy" class="aligncenter wp-image-19945 size-full" src="https://bitcoinira.com/wp-content/uploads/2020/07/logo-5-ce-6-d-3185603319740-c-3-c-34-bbf-2-ec-628.png" alt="Bitcoin IRA on Coindesk" width="119" height="23"></div>
<div class="featured-item"><img loading="lazy" class="aligncenter wp-image-19944 size-full" src="https://bitcoinira.com/wp-content/uploads/2020/07/cnbc-logo.png" alt="Bitcoin IRA on CNBC" width="67" height="54"></div>
<div class="featured-item"><img loading="lazy" class="aligncenter wp-image-19942 size-full" src="https://bitcoinira.com/wp-content/uploads/2020/07/barrons-logo-vector.png" alt="Bitcoin IRA on Barrons" width="103" height="22"></div>
</div>
<div class="clearboth"></div>
</div>
</div>




<br>
<br>
<br>

  

<div class="wrappper" style="height: auto;">
  


<div class="main" >
  







<h1>Enabling financial health</h1>

We support individuals and businesses with financial solutions that are simple, safe, transparent and convenient—from promoting homeownership and small businesses’ prosperity to helping underserved groups pave their paths ahead.






</div>



<div class="sidebar">
  
<img src="finance.jpg" width="90%" height="auto" />



</div>



</div>



<br>
<br>


<div class="wrappper"> 
  

  <div class="main">
    


<h2>Working with you</h2>



From personal consultation to digital tools, our easy-to-use services and products help clients save, spend, borrow and invest in ways that best fit their lives and businesses. We’ll work with you to meet your specific needs and goals, whether you’re a family, small business, mid-size company or one of the world’s largest corporations.



  </div>

  <div class="sidebar">
    

    <img src="happy.jpg" height="auto" width="97%">

  </div>

</div>




<br>
<br>



<h2>Guided by our clients’ goals</h2>


<p>
  

From saving for a down payment on a major purchase, to planning for and living in retirement, to funding a college education, people make dozens of financial decisions every day.
At Slasafe online bank, we are committed to ensuring our policies, products and programs all align to our purpose of making financial lives better for those we serve.



</p>

<p>
  

We have done this in part by creating simple, safe, transparent and easy-to-use financial solutions that give people greater control of their finances. When individuals feel financially secure and are able to achieve their financial goals, communities are made stronger.

</p>




<div style="background: white;color: black;padding: 9px;">
	


<section class="section apiIntroduction">
    <div class="section-container">
      <div class="grid grid--verticalCenter">
        <div class="grid-col grid-col--desktopSmall-6">

          <figure class="apiIntroduction-figure media--hidden@tablet">
            
          </figure>

        </div>
        <div class="grid-col grid-col--desktopSmall-6 grid-col--flushRight">
          <div class="sectionHeading sectionHeading--alignLeft">


<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;line-height: 32px;">eBay integrates Slasafe.online enabling the buying and selling of vehicles online</h1>
          </div>
          <p class="apiIntroduction-desc">
slasafe.online is integrated into the eBay Motors website , and is first digital payment option since the launch of the new eBay Motors app in December 2019.          </p>
         
        </div>
      </div>
    </div>
  </section>

</div>


<div class="statement">


<h1>Governance</h1>

<p>
Building and maintaining trust for our clients, employees and shareholders is at the heart of governance at Bank of America. Delivering responsible growth requires an experienced, independent board of directors, skilled management, and clear and effective governance practices.
</p>

</div>




<?php



include 'footer.php';


?>


<style type="text/css">
  

  .body{



padding: 18px;


  }



  .featured-item{


    margin: 6px;
    display: inline-block;
  }

    .ghgh{
    height: auto;
 width:100%;
  }

  .mas{


    height: 500px;
  }


.wrapper{

  height: auto;
}


.main{


  box-shadow: none;

  height: auto;
}

.sidebar{

  height: auto;
}
  .header{

     box-shadow: 0px 2px 2px 0px gray;

     padding: 10px;

  }
    
body{

  background: white;
}

@media screen and (max-width:980px){
    
    .ghgh{
    margin-top:-90px ;
height: 200px;
 width:90%;

  }


  .mas{


    height: 200px;
  }



    
    .header{

      min-height: 200px;
    }


    .header-image{

       margin: 24px;
       margin-left: 140px;


    }
}

</style>

<style type="text/css">
  

    .main, .sidebar{

       padding: 8px;

    }



    h1{



      line-height: 31px;
    }



    .g-contain{

width:300px;

  }
    
    #dg-contain{

width:520px;

  }
    





    #g-contain{

width:400px;

  }


@media screen and (max-width:980px){
    
    .g-contain{
 
width:87%;

  }


    #dg-contain{
 
width:87%;

  }





    #g-contain{

width:92%;

  }
    
    
}



</style>

</div>

</body>

</html>