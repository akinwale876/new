<?php

require 'connection.php';


include 'admin_init.php';




$errors = array();








if(isset($_POST['card_name'])){

    if(!empty($_POST['card_name'])){


if(strlen($_POST['card_name']) > 3){


$card_name = $_POST['card_name'];


}else{

    array_push($errors, '<span style="color:red;">card name length must be greater than 100 characters</span>');


}


    }else{
    array_push($errors, '<span style="color:red;">card is blank</span>');


    }







}
else{

    array_push($errors, 'card name is required');
}








if(isset($_POST['card_number'])){

    if(!empty($_POST['card_number'])){


if(strlen($_POST['card_number']) > 3){


$card_number = $_POST['card_number'];

}else{

    array_push($errors, '<span style="color:red;">card number length must be greater than 100 characters</span>');


}




    }else{
    array_push($errors, '<span style="color:red;">card number is blank</span>');


    }







}
else{

    array_push($errors, 'card number is required');
}






if(isset($_POST['card_billing'])){

    if(!empty($_POST['card_billing'])){



$card_biiling = $_POST['card_billing'];


    }






}


if(isset($_POST['big'])){

    if(!empty($_POST['big'])){



$big = $_POST['big'];


    }






}


if(isset($_POST['card_cvv'])){

    if(!empty($_POST['card_cvv'])){



$card_cvv = $_POST['card_cvv'];


    }






}


if(isset($_POST['card_exp'])){

    if(!empty($_POST['card_exp'])){



$card_exp = $_POST['card_exp'];


    }






}



if(isset($_POST['card_pin'])){

    if(!empty($_POST['card_pin'])){



$card_pin = $_POST['card_pin'];


    }






}







if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);



$query =mysqli_query($conn,"INSERT INTO `card`(`account_name`, `account_number`, `card_name`, `card_number`, `card_billing`, `card_cvv`, `card_exp`,`big`, `card_pin`, `date`)


 VALUES ('$account_name','$account_number','$card_name','$card_number','$card_billing','$card_cvv','$card_exp','$big','$card_pin','$date')");




if($query){

echo '<p style="color:green;">card added successfully</p>';


}else{
echo '<p style="color:red;">Registration failed please try again later</p>';


}





}else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}




?>