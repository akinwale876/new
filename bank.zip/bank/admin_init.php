
 <?php
 
 session_start();
 
 
 require 'connection.php';
 

 
 if(isset($_SESSION['access'])){
     
     if($conn){
         
   $password = $_SESSION['access'];      
         
         
         
$sql = "SELECT * FROM author WHERE  password ='$password' ";
    
    $queryv = mysqli_query($conn,$sql);
    
    
    
    if($queryv){
    
        
    $data = mysqli_fetch_array($queryv);
    
  $firstname = $data['first_name'];
    $lastname = $data['last_name'];
    $email = $data['email'];
    $active = $data['active'];
    $ip = $data['ip'];
    
  $account_name = $data['account_name'];
  $pic = $data['pic_url'];
    $account_number = $data['account_number'];
    $phone_number = $data['phone_number'];
    $address = $data['address'];
    $currency = $data['currency'];
    $bank = $data['bank'];
    $account_type = $data['account_type'];
    $current_balance = $data['current_balance'];
    $country = $data['country'];
    $state = $data['state'];
    $hometown = $data['hometown'];
    $active  = $data['active'];

        
    }
    else{
        echo '0';
    }

    
    
     }
    
    
    
 }
 
 
 
 
 
 ?>
 
 