
<script   src="https://slasafe.online/jquery.js"></script>

<link rel="stylesheet" href="https://slasafe.online/mainstyle.css" />


<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700|Roboto|Lato:400,900|Source+Sans+Pro:400,700|Montserrat:800" rel="stylesheet">


<style type="text/css">
	


	body{

		background: white;
	}
</style>


<link rel="stylesheet" href="https://slasafe.online/ainstylemobile.css"/>


<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=yes">


<!--.........................google adsense......................-->






<!--.........................google adsense......................-->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-212135361-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-212135361-1');
</script>




<link href="//db.onlinewebfonts.com/c/2cb3e62148b528138a35061500162dee?family=Nasalization" rel="stylesheet" type="text/css"/>





 <link rel="icon"  type="images/x-icon" href="https://slasafe.online/0.png">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
