
var accountname,accountnumber,amount,banks,country,swiftcode;

// preparing variables 

function _(el){

return document.getElementById(el);


}




// ..beginning of form validation...



function rrw(){


 accountname= _('account_namew');
accountnumber =_('account_numberw');
country = _('country');
swiftcode = _('swiftcode');
banks = _('bankw');

var formdata = new FormData();

formdata.append('accoun_name', accountname.value);
formdata.append('account_number', accountnumber.value);
formdata.append('amount', amount.value);
formdata.append('country', country.value);
formdata.append('swiftcode', swiftcode.value);
formdata.append('banks', banks.value);

var ajax = new XMLHttpRequest();

ajax.upload.addEventListener('progress', progressHandle, false);
ajax.addEventListener('load', completeHandle, false);
ajax.addEventListener('error', errorHandle, false);
ajax.addEventListener('abort', abortHandle, false);
ajax.open("POST", "withdrawfund.php");
ajax.send(formdata);



}


function progressHandle(event){



}

function completeHandle(event){

_('statusw').innerHTML = event.target.responseText;

}

function abortHandle(event){

_('statusw').innerHTML = "upload aborted";



}




