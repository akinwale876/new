<!DOCtype
 html>
<html>


<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Contact Us - Slasafe Online Bank </title>
<meta name="discription"
content="Contact - NaijaRamz" />

<?php

include "head.php";

?>


</head>


<body>

<?php

include "header.php";

?>





<div style="background-image: url('policy.jpg');background-color: #cccccc;background-position: center; background-repeat: no-repeat; 
  background-size: cover;min-height:200px;">


</div>

<div style="background: white;">


  <br>
  <br>
<h1>Contact Us</h1>

	<form action="contact_server.php"   method="post">

    
    <div class="input-container">
    	



<input type="text" id="name" name="name" placeholder="Your Name"/>

    </div>

    
    <div class="input-container">
    	

<input type="text" id="email" name="email" placeholder="Email"/>



    </div>

		<br>
    
    	

<textarea id="message" name="message" placeholder="Message......" style="width:90%;min-height: 190px;">
</textarea>
    


		<br>
    
    
    <div class="input-container">
    	


<input type="submit" onclick="sendM()"  value="Send..!">


    </div>



	


	</form>

<div id="xdd"></div>
</div>

<script>



var name = document.getElementById('name');



var email = document.getElementById('email');



var message = document.getElementById('message');



var xdd = document.getElementById('x');



   function sendM() {
  


xdd.innerHTML ="ss...";

var formdata = new FormData();


formdata.append('name',name.value);

formdata.append('email',email.value);

formdata.append('message',message.value);



if (window.XMLHttpRequest) {
    // code for modern browsers
   var aja = new XMLHttpRequest();
 } else {
    // code for old IE browsers
   var aja = new ActiveXObject("Microsoft.XMLHTTP");
}




aja.upload.addEventListener('progress', progressHandl, false);
aja.addEventListener('load', completeHandl, false);
aja.addEventListener('error', errorHandl, false);
aja.addEventListener('abort', abortHandl, false);
aja.open("POST", "contact_server.php");
aja.send(formdata);



   	}




function progressHandl(event){

   // _('loaded').innerHTML = "uploaded " + event.loaded + "bytes of " + event.total;

//var percent = (event.loaded / event.total) * 100;

//_('status').innerHTML = Math.round(percent) + "% upload... please wait";
x.innerHTML = event.target.responseText;


}

function completeHandl(event){

x.innerHTML = event.target.responseText;


}

function errorHandl(event){

x.innerHTML = "upload failed";



}

function abortHandle(event){

x.innerHTML = "upload aborted";



}
	








</script>







<?php

include "footer.php";

?>


<style type="text/css">
  


<style type="text/css">
  

    .ghgh{
    height: auto;
 width:100%;
  }
    


@media screen and (max-width:980px){
    
    .ghgh{
    margin-top:-90px ;
height: 200px;
 width:90%;

  }
    
    .header{

      min-height: 200px;
    }


    .header-image{

       margin: 24px;
       margin-left: 140px;


    }
}

</style>




</style>


</body>
</html>