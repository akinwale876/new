<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


  <title>Create Slasafe Online account</title>

    
<?php

include 'head.php';






if (isset($_GET['email'])) {
    $email_verified = $_GET['email'];
}


if (isset($_GET['first_name'])) {
    $first_name_verified = $_GET['first_name'];
}


if (isset($_GET['last_name'])) {
    $last_name_verified = $_GET['last_name'];
}else{


  header('location: https://slasafe.online/new-account.php');
}




?>


<meta name="robot" content="noindex" />

</head>
<body  style="background-image: url('photo.jpg');background-color: #cccccc;background-position: center;
  background-repeat: no-repeat;
  background-size:cover;">



<center>
<div class="containerr" style="position:relative;margin-top:30px;background:white;box-shadow:0px 2px 2px 0px rgb(100,100,100);padding:8px;border-radius:0px 8px 0px 8px;">  

<div class="header-image" style="display:inline-block;">  

</div>
<h1 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;">Slasafe Online Banking</h1>
</a>  

    

                       <center><h5>Complete Your account creation</h5></center>



    <center>

                                    <form name="form" action="/" method="get" onsubmit="return false">

<div class="input-container">
  
<input type="text"  id="firstname" style="border: none;outline: none;" onchange="return false;" value="<?php echo $first_name_verified; ?>" placeholder="First Name">


</div>

<div class="input-container">
  


<input type="text" id="lastname" style="border: none;outline: none;" value="<?php echo $last_name_verified; ?>" placeholder="Last Name">
</div>







<div class="input-container">
  
<input type="text"  style="border: none;outline: none;" id="email" value="<?php  if(isset($_GET['email'])){

  echo $email_verified;
  
}   ?>" placeholder="Email">

</div>

<div class="input-container">
  
<input type="text"  id="phone_number" placeholder="Phone number">

</div>
<div class="input-container">
  

 <label>Select Country</label> <select id="country">
    <option value="">Select Country</option>
    <option value="united states">United States</option>
    <option value="united kingdom">United Kingdom</option>
    <option value="Canada">Canada</option>
    <option value="Australia">Australia</option>
    <option value="South Africa">South Africa</option>

  </select>

</div>
<div class="input-container">
  
<input type="text"  id="state" placeholder="Your State">

</div>

<div class="input-container">
  
<input type="text"  id="hometown" placeholder="Your City">

</div>
<div class="input-container">
  
<input type="text"  id="address" placeholder="Residential address">

</div>


<div class="input-container">



 <label>Select Account Type</label><select id="account_type" class="form-control" name="account_type" required="">
                                <option value="">Type of Account</option>
                                <option value="Current account">Current account </option>
                                <option value="Savings account">Savings account</option>
                                <option value="Joint account">Joint account</option>
                                <option value="Offshore account">Offshore account</option>
                                <option value="IRA Accounts">IRA Accounts (Individual Retirement Accounts)</option>
                                <option value="Money Market Account">Money Market Account</option>
                                <option value="Certificate of Deposit (CD)">Certificate of Deposit (CD)</option>
                                <option value="Loan account">Loan account</option>
                                <option value="Military savings account">Military savings account</option>
                                <option value="Student Loan account">Student Loan account</option>
                                <option value="Mortgage account">Mortgage account</option>
                                </select>
  

</div>


<div class="input-container">
 <label>Select Currency</label> <select id="currency">
    <option value="$">USD</option>
    <option value="£">GBP</option>
    <option value="€">EURO</option>

  </select>

</div>
<div class="input-container">
    
 <label>Date Of Birth</label> 
 <select id="day">
    <option value="">day</option>

  <?php
  

    


  
  
  
for ($x = 0; $x <= 30; $x++) {
    
    
    $i = 1;
    
    
    $i += $x;
    
    
    
  echo '<option value="'. $i .'">' . $i . '</option>';
  
  
}



?>
  </select>

 <select id="month">
    <option value="">Month</option>
    <option value="Jan">Jan</option>
    <option value="Feb">Feb</option>
    <option value="Mar">Mar</option>
    <option value="Apr">Apr</option>
    <option value="May">May</option>
    <option value="Jun">Jun</option>
    <option value="Jul">Jul</option>
    <option value="Aug">Aug</option>
    <option value="Sept">Sept</option>
    <option value="Oct">Oct</option>
    <option value="Nov">Nov</option>
    <option value="Dec">Dec</option>
  </select>
  
 <select id="year">
     
     
    <option value="">Year</option>
    
    
  <?php
  

    


  
  
  
for ($x = 0; $x <= 100; $x++) {
    
    
    $i = 1912;
    
    
    $i += $x;
    
    
    
  echo '<option value="'. $i .'">' . $i . '</option>';
  
  
}



?>
    
  </select>
</div>

<br>

<div class="input-container">
  
<input type="password"  id="password" placeholder="Create a Password">
</div>




<div class="input-container">
  
<input type="password"  id="confirm" placeholder="Confirm Password">

</div>



<center>
    <div style="width:35%;border:1px solid rgb(210,210,200);">
<label>Upload Image</label>
<input style="border:none;" type="file"  id="file">
</div>
</center>




<br>
<input type="submit"  name="submit" onclick="register()" id="butto" value="Create" >

</form>



                            <p>already have account <a href="/login">Login</a></p>

</center>

    
    <div class="hide">
    
<p id="status"></p>
               
<p style="display:none;" id="loaded"></p>
               
<progress id="progressbar" style="display:none;" value="" max="100"></progress>

    </div>
    
</div>

<style>
    
   .input-container{
       
       margin:0;
   }
    
    
    .hide{
        display:none;
        position:absolute;
        width:200px;
      border-radius:0 40px 40px 40px;
        background:white;
        right:-220px;
        top:80px;
        
        

    }
    
    .hide::after{
        content:"";
        position:absolute;
        top:-1px;
        left:-25px;
        border-style:solid;
        border-width:13px;
        border-color:transparent white transparent transparent;

        

    }
    
    .containerr{
        
        
        width:700px;
        
    }
    
    
  @media screen and (max-width: 600px) {

   .containerr{
        
        
        width:95%;
        
    }

    .hide{
        display:none;
        position:static;
        width:200px;
      border-radius:0 40px 40px 40px;
        background:white;
        right:0px;
        top:0px;
        
        

    }
    



}
    
</style>





<style>
    
    

    
    
    
    
</style>

</center>



<?php


include 'footer.php';

?>



<script src="reg.js"></script>





<script>
    
    
    

setTimeout(function(){
    
    
    
    
    $('#butto').click(function(){
        
        
    $('.hide').slideDown(200)
    
    
    })
    
    
    
    
    
    
},2000)


</script>
</body>
</html>