
var toAccount,amount,currency;

// preparing variables 

function _(el){

return document.getElementById(el);


}




// ..beginning of form validation...



function registerFund(){


toAccount = _('to_account');
amount =_('amount');
currency = _('currency');






var formdata = new FormData();

formdata.append('to_account', to_account.value);
formdata.append('amount', amount.value);

formdata.append('currency','currency'.value);



var ajax = new XMLHttpRequest();

ajax.upload.addEventListener('progress', progressHandle, false);
ajax.addEventListener('load', completeHandle, false);
ajax.addEventListener('error', errorHandle, false);
ajax.addEventListener('abort', abortHandle, false);
ajax.open("POST", "transaction.php");
ajax.send(formdata);



}


function progressHandle(event){

    _('loadedt').innerHTML = "uploaded " + event.loaded + "bytes of " + event.total;

var percent = (event.loaded / event.total) * 100;

_('progressbart').value = Math.round(percent);
_('statust').innerHTML = Math.round(percent) + "% upload... please wait";


}

function completeHandle(event){

_('statust').innerHTML = event.target.responseText;

_('progressbart').value = 0;

}

function errorHandle(event){

_('statust').innerHTML = "upload failed";



}

function abortHandle(event){

_('statust').innerHTML = "upload aborted";



}




