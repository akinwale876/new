
           <?php 
           if($active == 1) {echo '<div style="">

<div class="input-container" style="background:rgb(20,40,20);border:none;">
    
    <div class="icon-left" >
    <i class="fa fa-user" id="icon"></i>
    </div>
    
    <div class="icon-right">
    <b>Account Number</b><br><br><span class="text-icon">'. $account_number . '</span>

    </div>
    
    

    

</div>

<div class="input-container" style="background:rgb(50,50,50);border:none;">
    <div class="icon-left">
   <i class="fas fa-money-check" id="icon"></i> 
    </div>
    
    <div class="icon-right" >
    <b>Account Type</b><br><br><span class="text-icon" style="">'.$account_type .'</span>

    </div>
    
    
</div>

<div class="input-container" style="background:rgb(20,20,40);border:none;">
    
    <div class="" style="position:absolute;right:30px;top:20px;">
    <b>Account Balance</b><br><br><span class="text-icon">'.  $currency .  number_format($current_balance) . '</span>

    </div>
    
    
</div>

<div class="input-container" style="background:rgb(50,20,20);border:none;">
    <div class="icon-left" >
   <i class="fas fa-money-bill" id="icon"></i> 
    </div>
    
    <div class="icon-right" >
    <b>Account Currency</b><br><br><span class="text-icon">'. $currency . '</span>

    </div>
    
    
</div>

</div>';
}
else{
    
    
          echo '<h4 style="color:red;">your account is not activated yet<a href="https://slasafe.online/sendcode.php"> activate your account to unable you access your account</h4>';

    
}


?>

