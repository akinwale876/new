<?php



require 'connection.php';









if (isset($_GET['email'])) {
	

	$email = $_GET['email'];
}


if (isset($_GET['token'])) {
	

	$token = $_GET['token'];
}


if (isset($_GET['code'])) {
	

	$code = $_GET['code'];
}


if (isset($_GET['first_name'])) {
	

	$first_name = $_GET['first_name'];
}


if (isset($_GET['last_name'])) {
	

	$last_name = $_GET['last_name'];
}




$query = mysqli_query($conn, "SELECT * FROM `verification` WHERE `first_name` = '$first_name' AND `last_name` = '$last_name' AND `email` = '$email' AND `token` = '$token' AND `code` = '$code' LIMIT 1");




if (mysqli_num_rows($query) == 1) {
	

	header('location: https://slasafe.online/create?email='. $email .' &first_name=' . $first_name . '&last_name='. $last_name);
}





?>