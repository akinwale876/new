

     


           <?php 

    echo time() - $date;


           if($active == 1) {echo '<div class="ssaa" style="overflow-x:auto;height:125px;">


<div style="width:1180px;">

<div class="input-container" style="background:rgb(240,240,240);border:none;display:inline-block;">
    
    <div class="" style="padding:10px;color:black;">
    <b>Total Deposit</b><br><br><span class="text-icon" style="font-size:38px;color:black;">'. '$' .  number_format($bitcoin + $ethereum + $litecoin ) . '</span>

    </div>
    
    
</div>



<div class="input-container" style="background:rgb(240,240,240);border:none;display:inline-block;">
    
    <div class="" style="padding:10px;color:black;">
    <b>Bitcoin</b><br><br><span class="text-icon" style="font-size:38px;color:black;">'. '$' .  number_format($bitcoin) . '</span>

    </div>
    
    
</div>


<div class="input-container" style="background:rgb(240,240,240);border:none;display:inline-block;">
    
    <div class="" style="padding:10px;color:black;">
    <b>Ethereum</b><br><br><span class="text-icon" style="font-size:38px;color:black;">'. '$' .  number_format($ethereum) . '</span>

    </div>
    
    
</div>






<div class="input-container" style="background:rgb(240,240,240);border:none;display:inline-block;">
    
    <div class="" style="padding:10px;color:black;">
    <b>Today so far</b><br><br><span class="text-icon" style="font-size:38px;color:black;">'. '$' .  number_format(($bitcoin + $ethereum + $litecoin) / 100 * 0.2) . '</span>

    </div>
    
    
</div>


<div class="input-container" style="background:rgb(240,240,240);border:none;display:inline-block;">
    
    <div class="" style="padding:10px;color:black;">
    <b>Profit So far(<small style="color:red;">withdrawable</small>)</b><br><br><span class="text-icon" style="font-size:38px;color:black;">'. '$' .  number_format(($bitcoin + $ethereum + $litecoin) * 0.2) . '</span>

    </div>
    
    
</div>


</div>
</div><br>';
}
else{
    
    
          echo '<h4 style="color:red;">your account is not activated yet<a href="https://slasafe.online/sendcode.php"> activate your account to unable you access your account</h4>';

    
}


?>

