<?php


require 'connection.php';

if(isset($_GET['user'])){




$user = $_GET['user'];



  $newQ = mysqli_query($conn,"SELECT * FROM `contact` WHERE `cookie_value` = '$user' ORDER BY id DESC LIMIT 1");


 $arr = mysqli_fetch_array($newQ);
  
  $arr_message = $arr['message'];

  echo $arr_message;


}



?>