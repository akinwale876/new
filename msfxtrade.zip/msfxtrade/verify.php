<?php



require 'connection.php';




if (isset($_GET['email'])) {
	

	$email = $_GET['email'];
}


if (isset($_GET['token'])) {
	

	$token = $_GET['token'];
}


if (isset($_GET['code'])) {
	

	$code = $_GET['code'];
}





$query = mysqli_query($conn, "SELECT * FROM `verification` WHERE  `email` = '$email' AND `token` = '$token' AND `code` = '$code' LIMIT 1");




if (mysqli_num_rows($query) == 1) {
	

	header('location: https://zifxtrade.online/reset.php?email='. $email .'&code=' . $code . '&token='. $token);
}





?>