<?php




require 'connection.php';



include 'admin_init.php';




$errors = array();


if($conn){


}

if(isset($_POST['to_account'])){


if(!empty($_POST['to_account'])){


if(strlen($_POST['to_account']) > 3){

$to_account = $_POST['to_account'];


}else{

    array_push($errors, '<span style="color:red;">account name length must be greater than 6</span>');


}











}else{
    array_push($errors, '<span style="color:red;">Enter Wallet Address</span>');


}





}
else{

    array_push($errors, 'Please Enter Wallet Address');
}














if(isset($_POST['transaction_type'])){

    if(!empty($_POST['transaction_type'])){


if(strlen($_POST['transaction_type']) > 3){


$transaction_type = $_POST['transaction_type'];


}else{

    array_push($errors, '<span style="color:red;">transaction type length must be greater than 100 characters</span>');


}






    }else{
    array_push($errors, '<span style="color:red;">Coin type</span>');


    }


}
else{

    array_push($errors, 'type is required');
}








if(isset($_POST['amount'])){

    if(!empty($_POST['amount'])){


if(strlen($_POST['amount']) > 2){


$amount = $_POST['amount'];

}else{

    array_push($errors, '<span style="color:red;">amount length must be greater than 100 characters</span>');


}





    }else{
    array_push($errors, '<span style="color:red;">Enter Amount</span>');


    }



}
else{

    array_push($errors, 'Please Enter Amount');
}





if(isset($_POST['currency'])){

    if(!empty($_POST['currency'])){


$currency = $_POST['currency'];

}else{


        array_push($errors, '<span style="color:red;">Select Coin</span>');

}

}

else{

    array_push($errors, 'Please Select Coin');
}



if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);



$qquery =mysqli_query($conn,"SELECT * FROM `customers` WHERE account_number = '$account_number' LIMIT 1");

if(mysqli_num_rows($qquery) == 1){
    
$dsd  = mysqli_fetch_array($qquery);

$testamount = $dsd[$currency];

if($testamount > $amount){
    

 

$qqueryy = mysqli_query($conn,"SELECT * FROM `customers` WHERE account_number = '$to_account' LIMIT 1");

if(mysqli_num_rows($qqueryy) > 0){
    
    
    
    
mysqli_query($conn,"UPDATE `customers` SET `$currency` = `$currency` + '$amount' WHERE `account_number` = '$to_account' LIMIT 1");




$qqueryyes = mysqli_query($conn,"UPDATE `customers` SET `$currency` = `$currency` - '$amount' WHERE `account_number` =  '$account_number' LIMIT 1");


if($qqueryyes){
    
    $dd = date('h:ma d/m/y',time());
    
    echo '<center><h4 style="color:rgb(80,180,80);">'.$amount.'</h4></center>


      <div style="padding:5px;">
   <h5>Date: <span style="margin-left:40px;">'. $dd  .'</span></h5>
<h5>Status: <span style="margin-left:40px;">Transaction Successful</span></h5>
<h6>Receipent: <span style="margin-left:40px;">'.$to_account.'</span></h6>

      </div>


      <div style="padding:6px;">

<h5>Network Fee: <span style="margin-left:50px;">0.23</span></h5>

      </div>



    ';














    
    $qqu = mysqli_query($conn,"SELECT * FROM `customers` WHERE account_number = '$to_account' LIMIT 1");
    
    mysqli_query($conn,"INSERT INTO `transactions`(`transaction_type`,`from_name`,`amount`,`from`,`to`,`currency`,`date`) VALUES('$transaction_type','$account_name','$amount','$account_number','$to_account','$currency','$date') ");

    
    
$dss  = mysqli_fetch_array($qqu);

$to_email = $dss['email'];
$to_name = $dss['first_name'];
$to_currency = $dss['currency'];
    
$to = $to_email;
$subject = "Fund Receive";

$message ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>Fund Receive</title>



</head>
<body>

<h2>Dear '.$to_name.' </h2><p>Your account has been funded with <b>$'.$to_currency. number_format($amount). '</b></p>

<table>
<tr>
<th>From</th>
<th>Wallet</th>
<th>Amount</th>
</tr>
<tr>
<td>'.$account_name.'</td>
<td>'.$account_number.'</td>
<td>'.$amount.'</td>
</tr>
</table>
</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: Zifx Support@zifxtrade.online' . "\r\n";
$headers .= 'Cc:Zifx Support@zifxtrade.online' . "\r\n";

if(mail($to,$subject,$message,$headers)){
echo 'o';

}



$subject2 = "Debit";

$message2 ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>Debit</title>



</head>
<body>

<h2>Dear '.$firstname.' </h2><p>Your account has been Debited with <b>$'.$to_currency. number_format($amount). '</b></p>


</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: Zifx Support@zifxtrade.online' . "\r\n";
$headers .= 'Cc:Zifx Support@zifxtrade.online' . "\r\n";

if(mail($email,$subject2,$message2,$headers)){
echo 'k';

}








    
}


$qqueryye = mysqli_query($conn,"SELECT * FROM `author` WHERE account_number = '$to_account' LIMIT 1");


}else{
    
    echo '<b style="color:red;font-size:19px;">receipent account does not exist</b>';
}
 
    
}
else{
    
   echo '<span style="color:red;font-size:19px;">insufficient fund</span>';
}




    
}else{
    
    
    echo 'no rows' . $account_number;
}


}else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}




?>