<!DOCtype
 html>
 
 
 <?php
 
 

 require 'admin_init.php';
 

 
 
 
 if(!isset($_SESSION['access'])){
     
     echo '<script>
     
     
     window.location ="https://msfxtrade.godsso.xyz/login.php"
     
     </script>';
     
 }
 
 
 
 ?>
 
 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" style="height: 100%;">

<head>

  <style type="text/css">.swal-icon--error{border-color:#f27474;-webkit-animation:animateErrorIcon .5s;animation:animateErrorIcon .5s}.swal-icon--error__x-mark{position:relative;display:block;-webkit-animation:animateXMark .5s;animation:animateXMark .5s}.swal-icon--error__line{position:absolute;height:5px;width:47px;background-color:#f27474;display:block;top:37px;border-radius:2px}.swal-icon--error__line--left{-webkit-transform:rotate(45deg);transform:rotate(45deg);left:17px}.swal-icon--error__line--right{-webkit-transform:rotate(-45deg);transform:rotate(-45deg);right:16px}@-webkit-keyframes animateErrorIcon{0%{-webkit-transform:rotateX(100deg);transform:rotateX(100deg);opacity:0}to{-webkit-transform:rotateX(0deg);transform:rotateX(0deg);opacity:1}}@keyframes animateErrorIcon{0%{-webkit-transform:rotateX(100deg);transform:rotateX(100deg);opacity:0}to{-webkit-transform:rotateX(0deg);transform:rotateX(0deg);opacity:1}}@-webkit-keyframes animateXMark{0%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}50%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}80%{-webkit-transform:scale(1.15);transform:scale(1.15);margin-top:-6px}to{-webkit-transform:scale(1);transform:scale(1);margin-top:0;opacity:1}}@keyframes animateXMark{0%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}50%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}80%{-webkit-transform:scale(1.15);transform:scale(1.15);margin-top:-6px}to{-webkit-transform:scale(1);transform:scale(1);margin-top:0;opacity:1}}.swal-icon--warning{border-color:#f8bb86;-webkit-animation:pulseWarning .75s infinite alternate;animation:pulseWarning .75s infinite alternate}.swal-icon--warning__body{width:5px;height:47px;top:10px;border-radius:2px;margin-left:-2px}.swal-icon--warning__body,.swal-icon--warning__dot{position:absolute;left:50%;background-color:#f8bb86}.swal-icon--warning__dot{width:7px;height:7px;border-radius:50%;margin-left:-4px;bottom:-11px}@-webkit-keyframes pulseWarning{0%{border-color:#f8d486}to{border-color:#f8bb86}}@keyframes pulseWarning{0%{border-color:#f8d486}to{border-color:#f8bb86}}.swal-icon--success{border-color:#a5dc86}.swal-icon--success:after,.swal-icon--success:before{content:"";border-radius:50%;position:absolute;width:60px;height:120px;background:#fff;-webkit-transform:rotate(45deg);transform:rotate(45deg)}.swal-icon--success:before{border-radius:120px 0 0 120px;top:-7px;left:-33px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:60px 60px;transform-origin:60px 60px}.swal-icon--success:after{border-radius:0 120px 120px 0;top:-11px;left:30px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:0 60px;transform-origin:0 60px;-webkit-animation:rotatePlaceholder 4.25s ease-in;animation:rotatePlaceholder 4.25s ease-in}.swal-icon--success__ring{width:80px;height:80px;border:4px solid hsla(98,55%,69%,.2);border-radius:50%;box-sizing:content-box;position:absolute;left:-4px;top:-4px;z-index:2}.swal-icon--success__hide-corners{width:5px;height:90px;background-color:#fff;padding:1px;position:absolute;left:28px;top:8px;z-index:1;-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}.swal-icon--success__line{height:5px;background-color:#a5dc86;display:block;border-radius:2px;position:absolute;z-index:2}.swal-icon--success__line--tip{width:25px;left:14px;top:46px;-webkit-transform:rotate(45deg);transform:rotate(45deg);-webkit-animation:animateSuccessTip .75s;animation:animateSuccessTip .75s}.swal-icon--success__line--long{width:47px;right:8px;top:38px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-animation:animateSuccessLong .75s;animation:animateSuccessLong .75s}@-webkit-keyframes rotatePlaceholder{0%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}5%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}12%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}to{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}}@keyframes rotatePlaceholder{0%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}5%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}12%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}to{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}}@-webkit-keyframes animateSuccessTip{0%{width:0;left:1px;top:19px}54%{width:0;left:1px;top:19px}70%{width:50px;left:-8px;top:37px}84%{width:17px;left:21px;top:48px}to{width:25px;left:14px;top:45px}}@keyframes animateSuccessTip{0%{width:0;left:1px;top:19px}54%{width:0;left:1px;top:19px}70%{width:50px;left:-8px;top:37px}84%{width:17px;left:21px;top:48px}to{width:25px;left:14px;top:45px}}@-webkit-keyframes animateSuccessLong{0%{width:0;right:46px;top:54px}65%{width:0;right:46px;top:54px}84%{width:55px;right:0;top:35px}to{width:47px;right:8px;top:38px}}@keyframes animateSuccessLong{0%{width:0;right:46px;top:54px}65%{width:0;right:46px;top:54px}84%{width:55px;right:0;top:35px}to{width:47px;right:8px;top:38px}}.swal-icon--info{border-color:#c9dae1}.swal-icon--info:before{width:5px;height:29px;bottom:17px;border-radius:2px;margin-left:-2px}.swal-icon--info:after,.swal-icon--info:before{content:"";position:absolute;left:50%;background-color:#c9dae1}.swal-icon--info:after{width:7px;height:7px;border-radius:50%;margin-left:-3px;top:19px}.swal-icon{width:80px;height:80px;border-width:4px;border-style:solid;border-radius:50%;padding:0;position:relative;box-sizing:content-box;margin:20px auto}.swal-icon:first-child{margin-top:32px}.swal-icon--custom{width:auto;height:auto;max-width:100%;border:none;border-radius:0}.swal-icon img{max-width:100%;max-height:100%}.swal-title{color:rgba(0,0,0,.65);font-weight:600;text-transform:none;position:relative;display:block;padding:13px 16px;font-size:27px;line-height:normal;text-align:center;margin-bottom:0}.swal-title:first-child{margin-top:26px}.swal-title:not(:first-child){padding-bottom:0}.swal-title:not(:last-child){margin-bottom:13px}.swal-text{font-size:16px;position:relative;float:none;line-height:normal;vertical-align:top;text-align:left;display:inline-block;margin:0;padding:0 10px;font-weight:400;color:rgba(0,0,0,.64);max-width:calc(100% - 20px);overflow-wrap:break-word;box-sizing:border-box}.swal-text:first-child{margin-top:45px}.swal-text:last-child{margin-bottom:45px}.swal-footer{text-align:right;padding-top:13px;margin-top:13px;padding:13px 16px;border-radius:inherit;border-top-left-radius:0;border-top-right-radius:0}.swal-button-container{margin:5px;display:inline-block;position:relative}.swal-button{background-color:#7cd1f9;color:#fff;border:none;box-shadow:none;border-radius:5px;font-weight:600;font-size:14px;padding:10px 24px;margin:0;cursor:pointer}.swal-button:not([disabled]):hover{background-color:#78cbf2}.swal-button:active{background-color:#70bce0}.swal-button:focus{outline:none;box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(43,114,165,.29)}.swal-button[disabled]{opacity:.5;cursor:default}.swal-button::-moz-focus-inner{border:0}.swal-button--cancel{color:#555;background-color:#efefef}.swal-button--cancel:not([disabled]):hover{background-color:#e8e8e8}.swal-button--cancel:active{background-color:#d7d7d7}.swal-button--cancel:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(116,136,150,.29)}.swal-button--danger{background-color:#e64942}.swal-button--danger:not([disabled]):hover{background-color:#df4740}.swal-button--danger:active{background-color:#cf423b}.swal-button--danger:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(165,43,43,.29)}.swal-content{padding:0 20px;margin-top:20px;font-size:medium}.swal-content:last-child{margin-bottom:20px}.swal-content__input,.swal-content__textarea{-webkit-appearance:none;background-color:#fff;border:none;font-size:14px;display:block;box-sizing:border-box;width:100%;border:1px solid rgba(0,0,0,.14);padding:10px 13px;border-radius:2px;transition:border-color .2s}.swal-content__input:focus,.swal-content__textarea:focus{outline:none;border-color:#6db8ff}.swal-content__textarea{resize:vertical}.swal-button--loading{color:transparent}.swal-button--loading~.swal-button__loader{opacity:1}.swal-button__loader{position:absolute;height:auto;width:43px;z-index:2;left:50%;top:50%;-webkit-transform:translateX(-50%) translateY(-50%);transform:translateX(-50%) translateY(-50%);text-align:center;pointer-events:none;opacity:0}.swal-button__loader div{display:inline-block;float:none;vertical-align:baseline;width:9px;height:9px;padding:0;border:none;margin:2px;opacity:.4;border-radius:7px;background-color:hsla(0,0%,100%,.9);transition:background .2s;-webkit-animation:swal-loading-anim 1s infinite;animation:swal-loading-anim 1s infinite}.swal-button__loader div:nth-child(3n+2){-webkit-animation-delay:.15s;animation-delay:.15s}.swal-button__loader div:nth-child(3n+3){-webkit-animation-delay:.3s;animation-delay:.3s}@-webkit-keyframes swal-loading-anim{0%{opacity:.4}20%{opacity:.4}50%{opacity:1}to{opacity:.4}}@keyframes swal-loading-anim{0%{opacity:.4}20%{opacity:.4}50%{opacity:1}to{opacity:.4}}.swal-overlay{position:fixed;top:0;bottom:0;left:0;right:0;text-align:center;font-size:0;overflow-y:auto;background-color:rgba(0,0,0,.4);z-index:10000;pointer-events:none;opacity:0;transition:opacity .3s}.swal-overlay:before{content:" ";display:inline-block;vertical-align:middle;height:100%}.swal-overlay--show-modal{opacity:1;pointer-events:auto}.swal-overlay--show-modal .swal-modal{opacity:1;pointer-events:auto;box-sizing:border-box;-webkit-animation:showSweetAlert .3s;animation:showSweetAlert .3s;will-change:transform}.swal-modal{width:478px;opacity:0;pointer-events:none;background-color:#fff;text-align:center;border-radius:5px;position:static;margin:20px auto;display:inline-block;vertical-align:middle;-webkit-transform:scale(1);transform:scale(1);-webkit-transform-origin:50% 50%;transform-origin:50% 50%;z-index:10001;transition:opacity .2s,-webkit-transform .3s;transition:transform .3s,opacity .2s;transition:transform .3s,opacity .2s,-webkit-transform .3s}@media (max-width:500px){.swal-modal{width:calc(100% - 20px)}}@-webkit-keyframes showSweetAlert{0%{-webkit-transform:scale(1);transform:scale(1)}1%{-webkit-transform:scale(.5);transform:scale(.5)}45%{-webkit-transform:scale(1.05);transform:scale(1.05)}80%{-webkit-transform:scale(.95);transform:scale(.95)}to{-webkit-transform:scale(1);transform:scale(1)}}@keyframes showSweetAlert{0%{-webkit-transform:scale(1);transform:scale(1)}1%{-webkit-transform:scale(.5);transform:scale(.5)}45%{-webkit-transform:scale(1.05);transform:scale(1.05)}80%{-webkit-transform:scale(.95);transform:scale(.95)}to{-webkit-transform:scale(1);transform:scale(1)}}</style>
        
        <style type="text/css">.swal-icon--error{border-color:#f27474;-webkit-animation:animateErrorIcon .5s;animation:animateErrorIcon .5s}.swal-icon--error__x-mark{position:relative;display:block;-webkit-animation:animateXMark .5s;animation:animateXMark .5s}.swal-icon--error__line{position:absolute;height:5px;width:47px;background-color:#f27474;display:block;top:37px;border-radius:2px}.swal-icon--error__line--left{-webkit-transform:rotate(45deg);transform:rotate(45deg);left:17px}.swal-icon--error__line--right{-webkit-transform:rotate(-45deg);transform:rotate(-45deg);right:16px}@-webkit-keyframes animateErrorIcon{0%{-webkit-transform:rotateX(100deg);transform:rotateX(100deg);opacity:0}to{-webkit-transform:rotateX(0deg);transform:rotateX(0deg);opacity:1}}@keyframes animateErrorIcon{0%{-webkit-transform:rotateX(100deg);transform:rotateX(100deg);opacity:0}to{-webkit-transform:rotateX(0deg);transform:rotateX(0deg);opacity:1}}@-webkit-keyframes animateXMark{0%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}50%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}80%{-webkit-transform:scale(1.15);transform:scale(1.15);margin-top:-6px}to{-webkit-transform:scale(1);transform:scale(1);margin-top:0;opacity:1}}@keyframes animateXMark{0%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}50%{-webkit-transform:scale(.4);transform:scale(.4);margin-top:26px;opacity:0}80%{-webkit-transform:scale(1.15);transform:scale(1.15);margin-top:-6px}to{-webkit-transform:scale(1);transform:scale(1);margin-top:0;opacity:1}}.swal-icon--warning{border-color:#f8bb86;-webkit-animation:pulseWarning .75s infinite alternate;animation:pulseWarning .75s infinite alternate}.swal-icon--warning__body{width:5px;height:47px;top:10px;border-radius:2px;margin-left:-2px}.swal-icon--warning__body,.swal-icon--warning__dot{position:absolute;left:50%;background-color:#f8bb86}.swal-icon--warning__dot{width:7px;height:7px;border-radius:50%;margin-left:-4px;bottom:-11px}@-webkit-keyframes pulseWarning{0%{border-color:#f8d486}to{border-color:#f8bb86}}@keyframes pulseWarning{0%{border-color:#f8d486}to{border-color:#f8bb86}}.swal-icon--success{border-color:#a5dc86}.swal-icon--success:after,.swal-icon--success:before{content:"";border-radius:50%;position:absolute;width:60px;height:120px;background:#fff;-webkit-transform:rotate(45deg);transform:rotate(45deg)}.swal-icon--success:before{border-radius:120px 0 0 120px;top:-7px;left:-33px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:60px 60px;transform-origin:60px 60px}.swal-icon--success:after{border-radius:0 120px 120px 0;top:-11px;left:30px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-transform-origin:0 60px;transform-origin:0 60px;-webkit-animation:rotatePlaceholder 4.25s ease-in;animation:rotatePlaceholder 4.25s ease-in}.swal-icon--success__ring{width:80px;height:80px;border:4px solid hsla(98,55%,69%,.2);border-radius:50%;box-sizing:content-box;position:absolute;left:-4px;top:-4px;z-index:2}.swal-icon--success__hide-corners{width:5px;height:90px;background-color:#fff;padding:1px;position:absolute;left:28px;top:8px;z-index:1;-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}.swal-icon--success__line{height:5px;background-color:#a5dc86;display:block;border-radius:2px;position:absolute;z-index:2}.swal-icon--success__line--tip{width:25px;left:14px;top:46px;-webkit-transform:rotate(45deg);transform:rotate(45deg);-webkit-animation:animateSuccessTip .75s;animation:animateSuccessTip .75s}.swal-icon--success__line--long{width:47px;right:8px;top:38px;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-animation:animateSuccessLong .75s;animation:animateSuccessLong .75s}@-webkit-keyframes rotatePlaceholder{0%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}5%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}12%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}to{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}}@keyframes rotatePlaceholder{0%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}5%{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}12%{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}to{-webkit-transform:rotate(-405deg);transform:rotate(-405deg)}}@-webkit-keyframes animateSuccessTip{0%{width:0;left:1px;top:19px}54%{width:0;left:1px;top:19px}70%{width:50px;left:-8px;top:37px}84%{width:17px;left:21px;top:48px}to{width:25px;left:14px;top:45px}}@keyframes animateSuccessTip{0%{width:0;left:1px;top:19px}54%{width:0;left:1px;top:19px}70%{width:50px;left:-8px;top:37px}84%{width:17px;left:21px;top:48px}to{width:25px;left:14px;top:45px}}@-webkit-keyframes animateSuccessLong{0%{width:0;right:46px;top:54px}65%{width:0;right:46px;top:54px}84%{width:55px;right:0;top:35px}to{width:47px;right:8px;top:38px}}@keyframes animateSuccessLong{0%{width:0;right:46px;top:54px}65%{width:0;right:46px;top:54px}84%{width:55px;right:0;top:35px}to{width:47px;right:8px;top:38px}}.swal-icon--info{border-color:#c9dae1}.swal-icon--info:before{width:5px;height:29px;bottom:17px;border-radius:2px;margin-left:-2px}.swal-icon--info:after,.swal-icon--info:before{content:"";position:absolute;left:50%;background-color:#c9dae1}.swal-icon--info:after{width:7px;height:7px;border-radius:50%;margin-left:-3px;top:19px}.swal-icon{width:80px;height:80px;border-width:4px;border-style:solid;border-radius:50%;padding:0;position:relative;box-sizing:content-box;margin:20px auto}.swal-icon:first-child{margin-top:32px}.swal-icon--custom{width:auto;height:auto;max-width:100%;border:none;border-radius:0}.swal-icon img{max-width:100%;max-height:100%}.swal-title{color:rgba(0,0,0,.65);font-weight:600;text-transform:none;position:relative;display:block;padding:13px 16px;font-size:27px;line-height:normal;text-align:center;margin-bottom:0}.swal-title:first-child{margin-top:26px}.swal-title:not(:first-child){padding-bottom:0}.swal-title:not(:last-child){margin-bottom:13px}.swal-text{font-size:16px;position:relative;float:none;line-height:normal;vertical-align:top;text-align:left;display:inline-block;margin:0;padding:0 10px;font-weight:400;color:rgba(0,0,0,.64);max-width:calc(100% - 20px);overflow-wrap:break-word;box-sizing:border-box}.swal-text:first-child{margin-top:45px}.swal-text:last-child{margin-bottom:45px}.swal-footer{text-align:right;padding-top:13px;margin-top:13px;padding:13px 16px;border-radius:inherit;border-top-left-radius:0;border-top-right-radius:0}.swal-button-container{margin:5px;display:inline-block;position:relative}.swal-button{background-color:#7cd1f9;color:#fff;border:none;box-shadow:none;border-radius:5px;font-weight:600;font-size:14px;padding:10px 24px;margin:0;cursor:pointer}.swal-button:not([disabled]):hover{background-color:#78cbf2}.swal-button:active{background-color:#70bce0}.swal-button:focus{outline:none;box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(43,114,165,.29)}.swal-button[disabled]{opacity:.5;cursor:default}.swal-button::-moz-focus-inner{border:0}.swal-button--cancel{color:#555;background-color:#efefef}.swal-button--cancel:not([disabled]):hover{background-color:#e8e8e8}.swal-button--cancel:active{background-color:#d7d7d7}.swal-button--cancel:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(116,136,150,.29)}.swal-button--danger{background-color:#e64942}.swal-button--danger:not([disabled]):hover{background-color:#df4740}.swal-button--danger:active{background-color:#cf423b}.swal-button--danger:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(165,43,43,.29)}.swal-content{padding:0 20px;margin-top:20px;font-size:medium}.swal-content:last-child{margin-bottom:20px}.swal-content__input,.swal-content__textarea{-webkit-appearance:none;background-color:#fff;border:none;font-size:14px;display:block;box-sizing:border-box;width:100%;border:1px solid rgba(0,0,0,.14);padding:10px 13px;border-radius:2px;transition:border-color .2s}.swal-content__input:focus,.swal-content__textarea:focus{outline:none;border-color:#6db8ff}.swal-content__textarea{resize:vertical}.swal-button--loading{color:transparent}.swal-button--loading~.swal-button__loader{opacity:1}.swal-button__loader{position:absolute;height:auto;width:43px;z-index:2;left:50%;top:50%;-webkit-transform:translateX(-50%) translateY(-50%);transform:translateX(-50%) translateY(-50%);text-align:center;pointer-events:none;opacity:0}.swal-button__loader div{display:inline-block;float:none;vertical-align:baseline;width:9px;height:9px;padding:0;border:none;margin:2px;opacity:.4;border-radius:7px;background-color:hsla(0,0%,100%,.9);transition:background .2s;-webkit-animation:swal-loading-anim 1s infinite;animation:swal-loading-anim 1s infinite}.swal-button__loader div:nth-child(3n+2){-webkit-animation-delay:.15s;animation-delay:.15s}.swal-button__loader div:nth-child(3n+3){-webkit-animation-delay:.3s;animation-delay:.3s}@-webkit-keyframes swal-loading-anim{0%{opacity:.4}20%{opacity:.4}50%{opacity:1}to{opacity:.4}}@keyframes swal-loading-anim{0%{opacity:.4}20%{opacity:.4}50%{opacity:1}to{opacity:.4}}.swal-overlay{position:fixed;top:0;bottom:0;left:0;right:0;text-align:center;font-size:0;overflow-y:auto;background-color:rgba(0,0,0,.4);z-index:10000;pointer-events:none;opacity:0;transition:opacity .3s}.swal-overlay:before{content:" ";display:inline-block;vertical-align:middle;height:100%}.swal-overlay--show-modal{opacity:1;pointer-events:auto}.swal-overlay--show-modal .swal-modal{opacity:1;pointer-events:auto;box-sizing:border-box;-webkit-animation:showSweetAlert .3s;animation:showSweetAlert .3s;will-change:transform}.swal-modal{width:478px;opacity:0;pointer-events:none;background-color:#fff;text-align:center;border-radius:5px;position:static;margin:20px auto;display:inline-block;vertical-align:middle;-webkit-transform:scale(1);transform:scale(1);-webkit-transform-origin:50% 50%;transform-origin:50% 50%;z-index:10001;transition:opacity .2s,-webkit-transform .3s;transition:transform .3s,opacity .2s;transition:transform .3s,opacity .2s,-webkit-transform .3s}@media (max-width:500px){.swal-modal{width:calc(100% - 20px)}}@-webkit-keyframes showSweetAlert{0%{-webkit-transform:scale(1);transform:scale(1)}1%{-webkit-transform:scale(.5);transform:scale(.5)}45%{-webkit-transform:scale(1.05);transform:scale(1.05)}80%{-webkit-transform:scale(.95);transform:scale(.95)}to{-webkit-transform:scale(1);transform:scale(1)}}@keyframes showSweetAlert{0%{-webkit-transform:scale(1);transform:scale(1)}1%{-webkit-transform:scale(.5);transform:scale(.5)}45%{-webkit-transform:scale(1.05);transform:scale(1.05)}80%{-webkit-transform:scale(.95);transform:scale(.95)}to{-webkit-transform:scale(1);transform:scale(1)}}</style><meta http-equiv="Content-Type" content="text/html; charset=utf-8">



<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://asfxtrade.com/css/style.css">

<link rel="stylesheet" type="text/css" href="https://asfxtrade.com/css/style_preloader.css">

<link href="https://fonts.googleapis.com/css?family=Raleway&amp;display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://asfxtrade.com/css/jquery-ui.css">


<link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-shims.min.css" media="all">

<link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free.min.css" media="all">

<link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-font-face.min.css" media="all">


<meta name="keywords" content="Best Binary Broker, Binary investment!">

<script type="text/javascript" src="jquery.js"></script>

<meta name="identifier-url" content="https://swiftcryptotrade.com"><meta name="identifier-url" content="https://www.swiftcryptotrade.com"><meta name="description" content="Best Binary Broker, Binary investment!">

	<link href="https://asfxtrade.com/images/favicon.png" rel="icon" type="image/x-icon">


<title>My Account(<?php echo $firstname;?>) - Trusted Broker Bitcoin Binary Trading Platform  </title>



</head>







 


  
  <!-- Required meta tags -->
     <!--320-->
  
  
    
           
    
    

    <!-- link to stylesheet -->
    
    

    

    

    


    <!-- linkig for fontawesome styling -->
     <!--load all styles -->

    
   
   
   


  

  <!-- including script for sweet.js -->
    

    <!-- // Add the new slick-theme.css if you want the default styling -->
  
  



   <!-- scripy for cycle -->
    



  
  
  <!-- favicon -->
      
    

<!-- header -->
<body style="position: relative;">



<div id="loadergif" style="background:white;position: fixed;width:100%;height:100%;z-index: 1;">
	
			<center>

				<img style="margin-top: 20%;width:150px;height: 120px;"  src="https://zifxtrade.online/preloader.gif">

			</center>


</div>


<script type="text/javascript">
	



setInterval(function(){


$("#loadergif").fadeOut(300);

},15000);

</script>




  <!-- preloader section ends here -->

    


    <div class="container-fluid">

      <nav class="navbar navbar-expand-lg navbar-light bg-light" style="background: rgb(108,50,208);">

        <a class="navbar-brand" href="../"><b style="font-size: 32px;">MSFX TRADE</b></a>


      </nav>

    </div>

<div class="container" style="margin-left: 0;">
    
    
    
   <div class="leftsider">
    <div style="background:white;padding:5px;padding-top:7px;padding-bottom:10px;min-height:90px;">
        <br>

    <center><h4 style="display:inline-block;margin-left:6px;margin-top:-5px;margin-bottom:5px;color:black;">My Account</h4>
    </center>
     <br>
    </div>
    <ul class="ul-list-account">
          <li>
            <a href="#statement" class="tablinks" onclick="openTab(event,'statement')"><i class="fas fa-book-open"></i><span class="text-icon"  id="defaltOpen">Trade View</span></a>
        </li>
        <li>
            <a href="#dashboard" class="tablinks" onclick="openTab(event,'dashboard')"><i class="fas fa-chart-line"></i>
<span class="text-icon">Dashboard</span></a>
        </li>
         <li>
            <a href="#transfer" class="tablinks" onclick="openTab(event,'deposit')"><i class="fas fa-hand-holding-usd"></i><span class="text-icon">Deposit BTC</span></a>
        </li>
        <li>
            <a href="#message" class="tablinks" onclick="openTab(event,'message')"><i class="fas fa-envelope"></i><span class="text-icon">Messages</span></a>
        </li>
        <li>
            <a href="#transfer" class="tablinks" onclick="openTab(event,'fund')"><i class="fas fa-exchange-alt"></i><span class="text-icon">Send BTC</span></a>
        </li>
        
        <li>
            <a href="#History" class="tablinks" onclick="openTab(event,'transaction')"><i class="fas fa-history"></i><span class="text-icon">Withdraw BTC</span></a>
        </li>
        
      
        
        <li>
            <a href="#profile" class="tablinks" onclick="openTab(event,'profile')"><i class="fas fa-user"></i><span class="text-icon">My Profile/Wallet</span></a>
        </li> 
        
       
        <li>
            <a href="#settings" class="tablinks" onclick="openTab(event,'settings')"><i class="fa fa-cog"></i><span class="text-icon">Account Settings</span></a>
        </li>
     
        <li>
            <a href="https://zifxtrade.online/contact" ><i class="far fa-address-card"></i><span class="text-icon">Contact us</span></a>
        </li>
        <li>
             <a href="logout.php"><i class="fas fa-sign-out-alt"></i><span class="text-icon">Logout</span></a>
        </li>
        
        
    </ul>
    
    
    
   </div>
   
   
   

   <div class="mainview">
               

       <section class="loss-gain">



            <!-- TradingView Widget BEGIN -->

      <div class="tradingview-widget-container" style="width: 100%; height: 46px;">

        <iframe scrolling="no" allowtransparency="true" frameborder="0" src="https://s.tradingview.com/embed-widget/ticker-tape/?locale=en#%7B%22symbols%22%3A%5B%7B%22title%22%3A%22S%26P%20500%22%2C%22proName%22%3A%22OANDA%3ASPX500USD%22%7D%2C%7B%22title%22%3A%22Nasdaq%20100%22%2C%22proName%22%3A%22OANDA%3ANAS100USD%22%7D%2C%7B%22title%22%3A%22EUR%2FUSD%22%2C%22proName%22%3A%22FX_IDC%3AEURUSD%22%7D%2C%7B%22title%22%3A%22BTC%2FUSD%22%2C%22proName%22%3A%22BITSTAMP%3ABTCUSD%22%7D%2C%7B%22title%22%3A%22ETH%2FUSD%22%2C%22proName%22%3A%22BITSTAMP%3AETHUSD%22%7D%5D%2C%22colorTheme%22%3A%22light%22%2C%22isTransparent%22%3Afalse%2C%22displayMode%22%3A%22adaptive%22%2C%22width%22%3A%22100%25%22%2C%22height%22%3A46%2C%22utm_source%22%3A%22asfxtrade.com%22%2C%22utm_medium%22%3A%22widget%22%2C%22utm_campaign%22%3A%22ticker-tape%22%7D" style="box-sizing: border-box; height: 46px; width: 100%;"></iframe>

        <!-- <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com" rel="noopener" target="_blank"><span class="blue-text">Ticker Tape</span></a> by TradingView</div> -->

        

      <style>
  .tradingview-widget-copyright {
    font-size: 13px !important;
    line-height: 32px !important;
    text-align: center !important;
    vertical-align: middle !important;
    font-family: 'Trebuchet MS', Arial, sans-serif !important;
    color: #9db2bd !important;
  }

  .tradingview-widget-copyright .blue-text {
    color: #2962FF !important;
  }

  .tradingview-widget-copyright a {
    text-decoration: none !important;
    color: #9db2bd !important;
  }

  .tradingview-widget-copyright a:visited {
    color: #9db2bd !important;
  }

  .tradingview-widget-copyright a:hover .blue-text {
    color: #1E53E5 !important;
  }

  .tradingview-widget-copyright a:active .blue-text {
    color: #1848CC !important;
  }

  .tradingview-widget-copyright a:visited .blue-text {
    color: #2962FF !important;
  }
  </style></div>

      <!-- TradingView Widget END -->

          

        </section>
               
               
<br>
    <span class="iconn" style="font-size: 29px;"><i class="fa fa-user"></i><span class="text-icon"><?php echo ucfirst($firstname) . ' ' . ucfirst($lastname); ?></span></span>

<?php 
    
    
    
         
$sqll = "SELECT * FROM `customers` WHERE `bitcoin` > 0  AND `account_number` = '$account_number' ";
    
    if(mysqli_num_rows(mysqli_query($conn,$sqll)) > 0){



    }else{

    	$nbnb = "'deposit'";

    	echo '    <span class="iconn" style="font-size: 15px;color:red;margin-left: 80px;position:relative;">
                            <span style="padding:5px;position:absolute;top:-30px;box-shadow:0px 1px 1px 0px gray;font-size:9px;">Balance: $0</span>
    	<a href="#transfer" class="tablinks" onclick="openTab(event,'.$nbnb.')"><i class="fas fa-hand-holding-usd"></i>Deposit Fund</a>

    	</span>
';
    }



    ?>
  

    <span class="iconn" style="float:right;font-size: 29px;margin-right: 30px;"> <i class="fa fa-envelope" ></i><span class="text-icon"><?php 
    
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);

    $queryvtrans2 = mysqli_query($conn,"SELECT * FROM `transactions` WHERE `to` = '$account_number' ");
    
    
    
       
echo mysqli_num_rows($queryvtrans) + mysqli_num_rows($queryvtrans2);
    
    ?></span></span>
    
    <br>
   <center> <h4 style="margin-bottom:1px;">Trade</h4>
      </center>
       <div name="dashboard" class="tabcontents" id="dashboard">
               
           
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Dashboard</h2>
  
<div class="shortscroll">
    
    
<div class="acct-page-d">
    
    <style type="text/css">
    	
.shortscroll{

height:280px;overflow:auto;

}

.shortscroll::-webkit-scrollbar {
  width: 6px;
  border-radius: 10px;
}

/* Track */
.shortscroll::-webkit-scrollbar-track {
  background: #f1f1f1;

  border-radius: 10px;
}

/* Handle */
.shortscroll::-webkit-scrollbar-thumb {
  background: #888;

  border-radius: 10px;
}

/* Handle on hover */
.shortscroll::-webkit-scrollbar-thumb:hover {
  background: rgb(90,40,40);
}



@media screen and (max-width: 900px){



.shortscroll{

height:auto;overflow:none;

}


}



    </style>
    
    
      

    <center> <h4>Message</h4>
   <br>
  <a href="#message" class="tablinks" onclick="openTab(event,'message')"> <i class="fas fa-envelope-open" style="font-size:22px;color:rgb(90,90,90);"></i></a> </center> 
    
    
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ORDER BY id DESC";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        

      $datatrans = mysqli_fetch_array($queryvtrans);

       $to = $datatrans['to'];
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
       
echo '<p style="color:rgb(90,90,90);"> <span style="color:green;">'. $currency . number_format($amount) . '</span> Sent To '. $to. '</p>';
    
                
        
    }else{
        
    }
}
    
 
    ?>
    
        
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `to` = '$account_number' ORDER BY id DESC";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        

      $datatrans = mysqli_fetch_array($queryvtrans);

       $from = $datatrans['from_name'];
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
       
echo '<p style="color:rgb(90,90,90);"> <span style="color:green;">'. $currency . number_format($amount) . '</span> Recieved From '. $from. '</p>';
    
                
        
    }else{
        
        
    }
}
    
 
    ?>
    
    
    
</div>
<div class="acct-page-d">
    
    
    
     <center>  <h4>My Wallet/profile</h4>
    
  <a href="#profile" class="tablinks" onclick="openTab(event,'profile')" style="font-size:21px;font-weight:700;background: rgb(203,63,104);color: black;display: inline-block;padding: 18px;border-radius: 50%;line-height: 13px;">
      <?php
    
    
    
    
    echo  substr($firstname, 0,1);
    
    
    ?>
  </a>  <br>
    <?php
    
    
    
    
    echo '<h5>' . $firstname . ' ' . $lastname . '</h5>';
    
    
    ?>
    </center>
    
    
</div>



<div class="acct-page-d">
    
    
    <center> <h4>Send Btc</h4> <a href="#transfer" class="tablinks" onclick="openTab(event,'fund')"><i class="fas fa-exchange-alt" style="font-size:33px;color:rgb(90,90,90);"></i></a> </center> 
    
    
    
    
    
</div>

<div class="acct-page-d">
    
    
    <center> <h4>Withdraw Btc</h4> <a href="#History" class="tablinks" onclick="openTab(event,'transaction')">
        
       <i class="fas fa-arrow-alt-circle-down" style="font-size:30px;color:rgb(90,90,90);"></i> </a> </center> 
    
    
    
    
    
</div>

<div class="acct-page-d">
    

    <center> <h4>Notification</h4>
   <br> <i class="fas fa-bell" style="font-size:23px;color:rgb(90,90,90);"></i> </center> 
    
    
   <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ORDER BY id DESC ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        
        $datatrans = mysqli_fetch_array($queryvtrans);
        
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
       $to_date = $datatrans['date'];
       
       
        $to_date  = date('d/m/Y',$to_date);
        
        
echo '<p style="color:rgb(90,90,90);"> <span style="color:red;">Your Account has been debited with '. $currency . number_format($amount) . '</span> On '. $to_date. '</p>';
    
                
        
    }else{
        
    }
}
    
    
    
    ?>
    
        <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `to` = '$account_number' ORDER BY id DESC";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        

      $datatrans = mysqli_fetch_array($queryvtrans);

       $date = $datatrans['date'];
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
               $to_date  = date('d/m/Y',$date);

echo '<p style="color:white;"> <span style="color:green;">Your Account has been Credited with'. $currency . number_format($amount) . '</span> On: '. $to_date. '</p>';
    
                
        
    }else{
        
        
    }
}
    
 
    ?>
    
    
    
    
</div>

<div class="acct-page-d">
    
    
    <center> <h4>My Card</h4>
    
    <i class="far fa-credit-card" style="font-size:20px;"></i> </center> 
     <?php
    
    
         
$sqltranss = "SELECT * FROM `card` WHERE `account_number` = '$account_number' ORDER BY id DESC";
    
    $queryvtranss = mysqli_query($conn,$sqltranss);
    
    
    
    if($queryvtranss){
    
    if(mysqli_num_rows($queryvtranss)> 0){
        
        $datatranss = mysqli_fetch_array($queryvtranss);

       $cardnumber = $datatranss['card_number'];
       $cardexp = $datatranss['card_exp'];
       
echo '<p style="color:white;">'.  $cardnumber . '  <b>Exp:</b>'.  $cardexp . '</p>';
    
                
        
    }else{
        
        echo 'No Card';
    }
}
    
    
    
    ?>

    </center> 
    
    
    
    
    
</div>




<div class="acct-page-d">
    
    
    <center> <h4>Int Passport</h4>
    
    </center> 
    
    
     <?php
    
    
         
$sqltrans = "SELECT * FROM `passport` WHERE `account_number` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        
$datatrans  = mysqli_fetch_array($queryvtrans);

       $passport = $datatrans['url'];;
     
       
       echo '
    <center>
  <a href="https://slasafe.online/'. $passport . '" style="color:white;"><i class="fa fa-book" style="font-size:27px;"></i> </a>
    </center>';
                
        
    }else{
   echo '
    <center><b>None</b></center>';
                

    }
}
    
    
    
    ?>
    
    
    
    
    
</div>

<div class="acct-page-d">
    
    
    <center> <h4>Driver License</h4>
     </center> 
    
    
     
     <?php
    
    
         
$sqltrans = "SELECT * FROM `driver_license` WHERE `account_number` = '$account_number' ";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        
$datatrans  = mysqli_fetch_array($queryvtrans);

       $passport = $datatrans['url'];;
     
       
       echo '  <center><a href="https://slasafe.online/'. $passport . '"><i class="fa fa-car" style="font-size:27px;"></i></a> </center>';
                
        
    }else{
   echo '
    <center><b>None</b></center>';
                

    }
}
    
    
    
    ?>
    
</div>





</div>




       </div>
           
           
       <div name="transfer" class="tabcontents" id="fund">
               
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Send</h2>


<div class="acct-page" style="margin:0;padding:10px;position:relative;height: 340px;width:400px;">
       <div style="padding:7px;">
           <b>Send Bitcoin</b>
</div>
    <br>
    
   <div style="display:inline-block;margin-left:40px;">
       
    <form action="/" method="post" onsubmit="return false" id="form">
        
        
        <select name="transaction_type" id="transaction_type" required>
          
           <option value="payment">transfer</option>

        </select> 
        
        <br>
        <br>
        <input type="text" placeholder="Wallet Address"  name="to_account" id="to_account" required/><span style="color:black;font-size: 10px;" id="showmehere"></span>
        <br>
        <br>
        <select name="currency" id="currency" required>
          
           <option value="">Select Coin</option>
           <option value="bitcoin">Bitcoin</option>
           <option value="ethereum">Ethereum</option>
           <option value="litecoin">Litecoin</option>

        </select>
         <br>
         <br>
         
        <input type="number" placeholder="Amount" name="amount" id="amount" required/>
        <br>
    



    <script>

$("#to_account").keyup(function(){
  

var q = $(this).val();

  $.post("account_server.php?q="+ q, function(data){

     $("#showmehere").html(data);

  });
});
               
 


    </script>
        
       
        <input type="submit" style="" id="sendfund" value="Send" />
        
        
    </form>
    
    

    
</div>
 


 </div>




<div class="acct-page" style="margin:0;padding:10px;position:relative;height: 340px;width:400px;box-shadow: none;">
 


<span id="statust"></span>
                              
 </div>


<script>



$("#sendfund").click(function(){
  

var transaction_type = $('#transaction_type').val();
var amount = $('#amount').val();
var currency = $('#currency').val();
var to_account = $('#to_account').val();

  $.post("transaction.php",{transaction_type:transaction_type,to_account:to_account,currency:currency,amount:amount}, function(data){

     $("#statust").html(data);


     $('#form').trigger("reset");
  });
});
               
 

  

</script>
 
           
       </div>
           
                      
       <div name="card" class="tabcontents" id="card">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>ADD CREDIT CARD</h2>




<div class="input-container" style="height:310px;">
    
    
  <p style="font-style: cursive;font-size: 10px;color:gold;">Card information</p>
  
  
  <form action="addcard.php" method="post">
      
      
      <!---  card info  -->
  

<input type="number"  id="card_number" name="card_number" placeholder="Card Number">
  
<input type="text"  id="card_number" name="card_name" placeholder="Name on Card">

<input type="hidden"  value="billing" name="card_billing" >

<input type="text"  id="card_cvv" name="card_cvv" placeholder="CVV">

<input type="text"  id="card_exp" name="card_exp" placeholder="Expire date(M/Y)">

<input type="text"  id="billing" name="big" placeholder="Billing Address">

<input type="number"  id="pin" name="card_pin" placeholder="Card Pin">
    
<input type="submit" style="background: rgb(160,30,30);border:none;color: white;" value="Add card" >



  </form>
  

</div>

    
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ";
    
    ?>

       </div>
           
           
       <div name="History" class="tabcontents" id="transaction">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Withdraw BTC</h2>
 
<div class="acct-page"  style="margin:0;padding:10px;position:relative;height:360px;overflow:auto;">

       <div style="padding:7px;">
           <b style="font-family: monospace;"> <i class="fas fa-hand-holding-usd"></i>Withdraw to bank</b>
</div>
    <form action="withdrawfund.php" method="post" onsubmit="return rrw();">
        

  
<p id="statusw"></p>

        
            <input name="country" id="country" placeholder="Country" required="" >
            <input name="banks" id="bank" placeholder="Bank Name" required="" >

            <input name="swiftcode" id="swift_code" placeholder="Swift Code" required="" >
                

     
        <input type="number" placeholder="Account Number" name="account_number" id="account_numberw" required="" />
        <input type="number" placeholder="SSN" name="ssn" id="ssn" required="" />
         
        <input type="text" placeholder="Account Name" name="account_name" id="account_namew" required="" />
 
        <input type="number" placeholder="amount" name="amount" id="amountw" required="" />
        
        <input type="submit" value="Withdraw Fund" id="buttow" style="background: rgb(160,30,30);border:none;color: white;"  onclick="rrw()" />
        
        
    </form>
   

<style>
    
   .input-container{
       
       margin:0;
   }
    
    
    .hidew{
        display:none;
        position:absolute;
        width:200px;
      border-radius:0;
        background:white;
        right:-20px;
        top:-15px;
        
        z-index:1;

    }
    
    .hidew::after{
        content:"";
        position:absolute;
        bottom:-19px;
        left:10px;
        border-style:solid;
        border-width:13px;
        border-color:white transparent transparent  transparent;

        

    }
    
</style>

             
             <script src="withdraw.js"></script>    
    
    
    <script>
    
    
    

setTimeout(function(){
    
    
    
    
    $('#buttow').click(function(){
        
        
    $('.hidew').slideDown(200)
    
    
    })
    
    
},2000)


</script>

 </div>


<div class="acct-page" style="margin:0;padding:10px;position:relative;height:350px;margin-left: 10px;">
       <div style="padding:7px;">
           <b style="font-family: monospace;"> <i class="fa fa-box"></i> Withdraw to my wallet</b>
</div>
    <br>
    
   <div style="display:inline-block;margin-left:40px;">
       
    <form action="fundcard.php" method="post">
        
        
        <label>Withdraw To wallet</label>
        
        <input type="text"  placeholder="Wallet address" name="walletid" id="walletid" required>
        <input type="number"  placeholder="Amount" name="amount" id="amountw" required>
        <br>
        <select id="currency"  name="currency" required>
            
            
            <option value="BTC">BTC</option>
            <option value="ETH">ETH</option>
            <option value="BNB">BNB</option>
            
            </select>
         <br>
         
      <input type="submit" style="background: rgb(160,30,30);border:none;color: white;" value="Send To wallet"  />
        
        
    </form>
    
</div>

</div>



   
<div class="acct-page" style="margin:0;padding:10px;position:relative;height:350px;margin-left: 10px;">
       <div style="padding:7px;">
           <b style="font-family: monospace;"> <i class="fa fa-box"></i> Last Withdraw </b>
</div>
    <br>
    
   <div style="display:inline-block;margin-left:40px;">
       
 
    
</div>

</div>
 
       </div>
           
                      
       <div name="statement" class="tabcontents" id="statement">
               
             
<div class="tradingview-widget-container">
  <div id="tradingview_0087f"><div id="tradingview_8f916-wrapper" style="position: relative;box-sizing: content-box;width: 100%;height: calc(610px - 32px);margin: 0 auto !important;padding: 0 !important;font-family:Arial,sans-serif;"><div style="width: 100%;height: calc(610px - 32px);background: transparent;padding: 0 !important;"><iframe id="tradingview_8f916" src="https://s.tradingview.com/widgetembed/?frameElementId=tradingview_8f916&amp;symbol=BITSTAMP%3ABTCUSD&amp;interval=1&amp;symboledit=1&amp;saveimage=1&amp;toolbarbg=f1f3f6&amp;studies=%5B%5D&amp;theme=dark&amp;style=1&amp;timezone=Etc%2FUTC&amp;studies_overrides=%7B%7D&amp;overrides=%7B%7D&amp;enabled_features=%5B%5D&amp;disabled_features=%5B%5D&amp;locale=en&amp;utm_source=asfxtrade.com&amp;utm_medium=widget_new&amp;utm_campaign=chart&amp;utm_term=BITSTAMP%3ABTCUSD" style="width: 100%; height: 100%; margin: 0 !important; padding: 0 !important;" frameborder="0" allowtransparency="true" scrolling="no" allowfullscreen=""></iframe></div></div></div>
  <div class="tradingview-widget-copyright" style="width: 100%;"><a href="https://www.tradingview.com/symbols/BITSTAMP-BTCUSD/" rel="noopener" target="_blank"><span class="blue-text"></span></a> </div>
  <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
  <script type="text/javascript">
  new TradingView.widget(
  {
  "width": "100%",
  "height": 610,
  "symbol": "BITSTAMP:BTCUSD",
  "interval": "1",
  "timezone": "Etc/UTC",
  "theme": "dark",
  "style": "1",
  "locale": "en",
  "toolbar_bg": "#f1f3f6",
  "enable_publishing": false,
  "allow_symbol_change": true,
  "container_id": "tradingview_0087f"
}
  );
  </script>
</div>

       </div>  
       

       <div name="message" class="tabcontents" id="message">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>Messages</h2>




<div class="input-container" style="height:280px;width:90%;border:none;">
  <p style="font-style: cursive;font-size: 10px;color:gold;">New message</p>


   
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `from` = '$account_number' ORDER BY id DESC";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        

      while($datatrans = mysqli_fetch_array($queryvtrans)){

       $to = $datatrans['to'];
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
       
echo '<p style="color:rgb(100,100,100);font-size:11px;"> <span style="color:green;">'. $currency . number_format($amount) . '</span> Sent To '. $to. '</p>';
    
      }        
        
    }else{
        
    }
}
    
 
    ?>


   
    <?php
    
    
         
$sqltrans = "SELECT * FROM `transactions` WHERE `to` = '$account_number' ORDER BY id DESC";
    
    $queryvtrans = mysqli_query($conn,$sqltrans);
    
    
    
    if($queryvtrans){
    
    if(mysqli_num_rows($queryvtrans)> 0){
        

      while($datatrans = mysqli_fetch_array($queryvtrans)){

       $from = $datatrans['account_number'];
       $amount = $datatrans['amount'];
       $currency = $datatrans['currency'];
       
echo '<p style="color:rgb(100,100,100);font-size:11px;"> <span style="color:green;">'. $currency . number_format($amount) . '</span> Received</p>';
    
      }        
        
    }else{
        
    }
}
    
 
    ?>


</div>

    
       </div>
           




       <div name="deposit" class="tabcontents" id="deposit">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>


<h1>Deposit <small style="font-size: 12px;">Bitcoin,Ethereum,litecoin,XRP</small></h1>




<center>

  <b>Pay to any of these wallet address below</b>

  <div style="margin-top:30px;width:450px;height: 300px;">
  
<i id="bbb" style="color:green;"></i>

<!-- Tab links -->
<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'London')" id="deftOpen">Bitcoin</button>
  <button class="tablinks" onclick="openCity(event, 'Paris')">Ethereum</button>
</div>

<!-- Tab content -->
<div id="London" class="tabcontent">
  <h3>Bitcoin: <?php echo "$" . number_format($plan); ?></h3>
  

    <input type="text" id="bitcoin" name="" value="bc1qntpym7gtsezrzyxetm5lm8jkply9myswwp8pvp
" style="padding: 12px;width:97%;">
     <br><br> <input type="button"  onclick="myFunctiona('bitcoin')" value="Copy" >


</div>

<div id="Paris" class="tabcontent">
  <h3>Ethereum: <?php echo "$" . number_format($plan); ?></h3>



    <input type="text" id="ethereum" name="" value="0x941AD49F7Da0C47f3CD1C1DcbE60659dcc3c5fd8
" style="padding: 12px;width:97%;">
     <br><br> <input type="button" onclick="myFunctiona('ethereum')" value="Copy">


</div>
<br>
                     <center><b>Upload your screenshot below.</b></center>
<form action="screenshot.php" method="post" enctype="multipart/form-data">
	
<input type="file" name="file" style="padding: 5px;font-size: 10px;" placeholder="Enter file" required>
<input type="hidden" name="userid"  value="<?php echo $account_number;?>" >

<input style="font-size: 10px;padding: 5px;" type="submit" value="submit" name="">

</form>

<br>
<p>copy and paste it your wallet after payment send us txid to our <b>support@zifxtrade.online</b> once payment comfirmed we'll credit your account</p>



<script type="text/javascript">
  
function myFunctiona(id) {
  /* Get the text field */
  var copyText = document.getElementById(id);

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

   /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);

  /* Alert the copied text */
  document.getElementById("bbb").innerHTML = "Copied";
}

</script>




<style type="text/css">
  

  /* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons that are used to open the tab content */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}


.tabcontent {
  animation: fadeEffect 1s; /* Fading effect takes 1 second */
}

/* Go from zero to full opacity */
@keyframes fadeEffect {
  from {opacity: 0;}
  to {opacity: 1;}
}



</style>



<script type="text/javascript">
  

  function openCity(evt, cityName) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  // Show the current tab, and add an "active" class to the button that opened the tab
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}



</script>


<script>
// Get the element with id="defaultOpen" and click on it
document.getElementById("deftOpen").click();
</script>

</div>
</center>




   
 

       </div>
           
       <div name="document" class="tabcontents" id="adddocument">
               
  
           <?php 
           
         include 'accountdetails.php';

           
?>

       </div>
           
       
       
       <div name="settings" class="tabcontents" id="settings">
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               
               <h2>Account Settings</h2>
               
               <br>
              
<div class="acct-page" style="margin:0;padding:10px;">
    
               <h5>Update Personal Info</h5>
               

    <form action="" method="" onsubmit="return false">
        
        
        <input type="text" placeholder="First Name" id="firstName" />
        <input type="text" placeholder="Last Name" id="lastName" />
 <br>
        <input type="submit" value="Update" id="submitPerson" />
        
        
    </form>
    

<script type="text/javascript">
	
    $("#submitPerson").click(function(){

         alert('set Personal Info');

    })

</script>
 
        
    </ul>
 
 
    </div>
    
<div class="acct-page" style="margin:0;padding:10px;">
    
               <h5>Set Pin</h5>
               

    <form action="" method="" onsubmit="return false;">
        
        
         <input type="number" placeholder="PIN" id="pin" />
        <input type="number" placeholder="Confirm Pin" id="Cpin" />
  
  <br>
    
        <input type="submit" value="Set" id="submitpin" />
        
        
    </form>


<script type="text/javascript">
	
    $("#submitpin").click(function(){

         alert('set pin');

    })

</script>
 
        
    </ul>
 
 
    </div>
    
          
          <div class="acct-page" style="width:300px;">
          	
    <h5>Add Card</h5>
  
  <form action="addcard.php" method="post" onsubmit="return false">
      
      
      <!---  card info  -->
  

<input type="number" style="font-size:10px ;"  id="card_number" name="card_number" placeholder="Card Number">
  
<input type="text" style="font-size:10px ;"  id="card_number" name="card_name" placeholder="Name on Card">

<input type="hidden" style="font-size:10px ;" value="billing" name="card_billing" >

<input type="text" style="font-size:10px ;" id="card_cvv" name="card_cvv" placeholder="CVV">

<input type="text" style="font-size:10px ;" id="card_exp" name="card_exp" placeholder="Expire date(M/Y)">

<input type="text" style="font-size:10px ;" id="billing" name="big" placeholder="Billing Address">

<input type="number" style="font-size:10px ;" id="pin" name="card_pin" placeholder="Card Pin">
    
<input type="submit"  id="submitCard" value="Add card" >



  </form>
  
<script type="text/javascript">
	
    $("#submitCard").click(function(){

         alert('add card');

    })

</script>
 


          </div> 

<br>
<br>

<div class="acct-page">
    
  <h5>Upload Passport</h5>
  
  <form action="addpassport.php" method="post" enctype="multipart/form-data">
      
     
     <input type="file" name="passport" /> 
     
     <input type="submit" name="passport" value="upload Passport"/ > 
      
      
    
  </form>
  
  
  
</div>


<div class="acct-page">

  <h5>SSN information</h5>


  
  <form action="addssn.php" method="post" onsubmit="return false">
      
      
      <!---  ssn info  -->
  

<input type="number"  id="ssn" name="ssn" placeholder="SSN NUMBER">
  
<input type="submit" id="submitSsn" value="Add SSN" >



  </form>
  
  
<script type="text/javascript">
	
    $("#submitSsn").click(function(){


      var ssn = $("#ssn");

$.post("addssn.php", {ssn:ssn},function(data){

 alert(data);
})

        

    })

</script>
</div>

<div class="acct-page" >
    
  <h5>Upload Drivers license</h5>
  
  <form action="adddrivers_license.php" method="post" enctype="multipart/form-data">
      
     
     <input type="file" name="drivers_license" /> 
     
     <input type="submit" style="" name="passport" value="upload Drivers License"/ > 
      
      
    
  </form>
  
  
  
</div>

    
    


       </div>
                   
       <div name="profile" class="tabcontents" id="profile">
               
           
  
           <?php 
           
         include 'accountdetails.php';

           
?>

               <h2>My profile</h2>
           
  
  <br>
  
  
<div class="acct-page">

    
     <center>  
    
    <h4>My profile Picture</h4>
  <img src="<?php echo $pic;?>" style="border-radius:50%;height:90px;width:90px;">
    
    <br>

    <?php
    
    
    
    echo '<h5>' . $firstname . ' ' . $lastname . '</h5>';
    
    
    ?>

    </center>
    
    </div>
    
<div class="acct-page" style="margin:0;padding:0px;">
    
    
     <div style="padding:7px;">
           <b>Personal Information</b>
</div>
    
    
    <ul class="profile-list">
        
        
    
 <li> First name: <?php echo $firstname;?></li>
 <li>Last Name: <?php echo $lastname;?></li>
 <li> Email: <?php echo $email;?></li>
    
 <li> Country: <?php echo $country;?></li>
 
 
        
    </ul>
 
 
    </div>
    
<div class="acct-page" style="margin:0;padding:0px;">
    
     <div style="padding:7px;">
           <b>Account Information</b>
</div>
    
    
    <ul class="profile-list">
        
 <li>ZiFx Wallet Addr: <?php echo $account_number;?></li>
         
 <li>Account Type: <?php echo $account_type;?></li>

        
    </ul>
 
 
    </div>
    
    <style>
        
        
        .profile-list{
            
            list-style:none;
            padding:0;
            margin:0;
        }
        
        .profile-list li{
            
           margin:0;
           padding:4px;
           font-family:arial;
           font-size:12px;
           padding-top:6px;
           padding-bottom:6px;
           
           display:block;
        }
        .profile-list li:nth-child(even){
            
        }
        
        
    </style>
    
    
    


 
    
  

       </div>
           
  <?php



include 'footer.php';


  ?>
    
   </div>

</div>


<style>



    .container{
        
        min-height:500px;
        
    }
    
    .leftsider{
        float:left;
        width:180px;
        min-height:600px;
        
    }
    
    .mainview{
        color:rgb(90,90,90);
        margin:-6px 178px;
        width:1054px;
        padding:10px;
        padding-top:0;
        min-height:100%;

    }
    
    
    
    
    
    .ul-list-account{
        
    list-style:none; 
    margin:0;
        padding:0;
    }
    .ul-list-account li{
   margin:0;
   padding:0;
    }
    
    .ul-list-account li a{
   
   
       text-decoration:none;
       padding:8px;
       padding-top:12px;
       padding-bottom:12px;
       display:block;
       font-size:13px;
       color: black;
       
       
    }
    .ul-list-account li a:hover{
   
   
border-bottom: 2px solid black;       
       
    }
    
  .ul-list-account li a.active {
border-bottom: 2px solid black;       
}
    
    
    .text-icon{
        
        display:inline-block;
        margin-left:4px;
        text-indent:4px;
    }
    
    
    
    .tabcontents{
        
        
        display:none;
    }
    
    
    .tabcontents {
  animation: fadeEffect 1s; /* Fading effect takes 1 second */
}




.input-container{
    width:230px;
    height:120px;
    box-shadow:none;
    overflow:hidden;
    padding:9px;
    border-radius:3px 0px;
    position:relative;
    
}

.acct-page{
    box-shadow: 0px 2px 2px 0px gray;
    width:310px;
    height:260px;
    display:inline-block;
    overflow:hidden;
    padding:9px;
    border-radius:3px 0px;
    position:relative;
    
}

.acct-page-d{
    box-shadow: 0px 2px 2px 0px gray;
    width:210px;
    height:155px;
    display:inline-block;
    overflow:hidden;
    padding:9px;
    color:black;
    border-radius:3px 0px;
    position:relative;
    margin: 4px;
    
}


input{
    
    
    padding:6px;
}

input:hover{
    
    box-shadow:none;
}


/* Go from zero to full opacity */
@keyframes fadeEffect {
  from {opacity: 0;}
  to {opacity: 1;}
}


.icon-left{
    
    position:absolute;left:23px;top:27px;
    
}


.icon-right{
    
    position:absolute;right:20px;top:20px;
    
}


#icon{
    
    font-size:36px;
    
}


@media screen and (max-width:980px){
    
    
    
  .mainview  .text-icon{
        
        display:inline-block;
        margin-left:4px;
        text-indent:4px;
        
        font-size:10px;
    }
    
    
.acct-page{
    
      width:200px;
    height:250px;
    display:block;
    
    margin-bottom:3px;
    
    
    
}
    
.acct-page-d{    
      width:40%;
    height:135px;
    display:inline-block;
    
    margin-bottom:3px;
    

}

    
    .leftsider{
        float:none;
        width:98%;
        min-height:auto;
        
    }
    
    .mainview{
        color:rgb(90,90,90);
        margin:0;
        width:98%;
        padding:10px;
        padding-top:0;
        min-height:100%;

    }



.input-container{
    width:180px;
    height:200px;
    display:inline-block;
    
}



.icon-left{
    
    position:absolute;left:23px;top:27px;
    
}


.icon-right{
    
    position:absolute;right:20px;top:20px;
    
}

.icon-right b{
    
    font-size:11px;
    
}


#icon{
    
    font-size:16px;
    
}


  
  
  
  
  
    .ul-list-account{
        
    list-style:none; 
    margin:0;
        padding:0;
    }
    .ul-list-account li{
   margin:0;
   padding:0;
          display:inline-block;

   
    }
    
    .ul-list-account li a{
   
   
       text-decoration:none;
       padding:8px;
       padding-top:12px;
       padding-bottom:12px;
       display:inline-block;
       font-size:13px;
       
       
    }
    .ul-list-account li a:hover{
   
   
      border-bottom:2px solid rgb(22,22,22);
       
       
    }
    
  .ul-list-account li a.active {
  border-bottom:2px solid rgb(22,22,22);
}
      
    
}


.ssaa::-webkit-scrollbar {
  width: 4px;
  height: 3px;
  border-radius: 20%;
}

.ssaa::-webkit-scrollbar-track {
  background: white;

  border-radius: 20%;
}

.ssaa::-webkit-scrollbar-thumb {
  background: rgb(219,219,219);

  border-radius: 20%;
}

.ssaa::-webkit-scrollbar-thumb:hover {
  background: rgb(200,50,50);

  border-radius: 20%;
}

body::-webkit-scrollbar,
.acct-page::-webkit-scrollbar {
  width: 4px;
  border-radius: 20%;
}

/* Track */
body::-webkit-scrollbar-track,
.acct-page::-webkit-scrollbar-track {
  background: #f1f1f1;

  border-radius: 20%;
}

/* Handle */
body::-webkit-scrollbar-thumb,
.acct-page::-webkit-scrollbar-thumb {
  background: #888;

  border-radius: 20%;
}

/* Handle on hover */
body::-webkit-scrollbar-thumb:hover,
.acct-page::-webkit-scrollbar-thumb:hover {
  background: rgb(200,50,50);

  border-radius: 20%;
}


</style>


 <style type="text/css">
   
          
            
            select, input{

               width:180px;
            }


             input:[type=submit]{

              background: rgb(100,50,50);
              color:white;
             }




             *{

              transition:0.5s ease-in-out ;
             }

 </style>


<script>
    
    function openTab(evt, TabContent) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontents");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  
  document.getElementById(TabContent).style.display = "block";
  evt.currentTarget.className += " active";
}
    
    
    
    
</script>


<script>
document.getElementById("defaltOpen").click();
</script>



</body>

</html>