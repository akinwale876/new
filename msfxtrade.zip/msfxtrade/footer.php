 <div class="footer">
   
   <script type="text/javascript" src="jquery.js"></script>

<p style="color:rgb(100,100,100);font-weight:400;">
    
    
   
<small style="font-size:9px;">

<script language="JavaScript">

document.write('&copy;' );
document.write(' <b><i>ZiFX</i> ');
document.write(new Date().getFullYear());
document.write(' </b> Alright Reserved   <a style="color:red;margin-left:20px;" href="https://zifxtrade.online/privacy-policy">Privacy Policy</a>  <a style="color:black;margin-left:20px;" href="https://zifxtrade.online/tos.php">Terms of use</a>');

</script>

</small>
 
</p>
    


<div id="supportcontainer" style="position: fixed;right: 25px;bottom: 90px;background:white;width:0;height:0;overflow:hidden;box-shadow: 0px 3px 3px 0px gray;border-radius:0px 12px">
  


  <div style="background:rgb(53, 31, 100);color: white;position: relative;padding: 15px;"><h5 style="display: inline-block;margin: 5px;">Contact Support</h5>
    
    <span title="close window." style="font-size:26px;font-weight:700;position: absolute;right: 7px;top: 6px;color:white;text-shadow:0px 3px red;cursor: pointer;" id="close">&times;</span>
  </div>




<div>
  

<div style="padding: 14px;">

<div style="margin:0 10px;font-size: 13px;font-family: monospace;"><b>Hi</b> Ask us anything we are here to help you</div>

</div>





<div style="padding: 12px;">
  <img src="https://slasafe.godsso.xyz/sophia.jpg"  style="width:35px;height:35px;border-radius:50%;float: left;font-size: 30px;">

<div style="margin:0 42px;width: 230px;font-size: 11px;font-family: arial;"><p id="talk"><img src="hloading.gif" style="height:40px;width:60px;" />
    </p></div>

</div>


<?php 

if (isset($firstname)) {
  echo '<input type="hidden" id="namedata" value="'. $firstname. '">';
}else{

  echo '<input type="hidden" id="namedata" value="Guest">';


}


    ?>





</div>


    <div id="mainmessage" style="width: 300px;height:160px;overflow:auto;padding: 5px;position: relative;">
      


    </div>



<div style="width:98%;position: absolute;padding: 8px;bottom: 0;background: rgb(240,240,240);">

<form id="fform" action="/" method="" onsubmit="return false;">
  
<input type="text" id="mailmessage" placeholder="Reply a Message" style="border: none;outline: none;background: rgb(240,240,240);" name="">

<button id="ssmail" style="display:inline-block;margin-left:57px;font-size:13px;cursor:pointer;border: none;outline: none;color:rgb(103, 61, 230);font-weight: 800;"><i style="display: inline-block;" class="fas fa-paper-plane"></i></button>


</form>

<script type="text/javascript">
  

       $("#ssmail").click(function(){

           

           var input = $("#mailmessage").val();


           $.post("supportcontact.php",{message:input}, function(data){
                         

            $("#mainmessage").html(data);
  });  


        
         $("#fform").trigger('reset');
  
              

       });

</script>



<script type="text/javascript">
  
          



</script>


</div>










</div>








    <span style="cursor:pointer;display:inline-block;position: fixed;z-index:1;right: 26px;bottom:28px;padding: 10px;border-radius:50%;color:rgb(103, 61, 230);background:white;box-shadow: 0px 2px 2px gray;"
class="support" id="support" 
    >
      <i style="font-size: 20px;" class="fas fa-comments"></i>

    </span>



    

<script type="text/javascript">
  
var userdata = $('#namedata').val();


$('#support').click(function(){


  $('#supportcontainer').animate({height: "470px",width: "300px"});


  setInterval(function(){ 
          $('#talk').html("welcome to ZiFXTRADE, <b>Hi " + userdata + " </b>  drop your email and your message someone will attend to you");
        
}, 5000);

})


$('#close').click(function(){


  $('#supportcontainer').animate({height: "0",width: "0"});

})





</script>




<a style="color:black;display:none;position:fixed;bottom:14px;right:10px;font-weight:bold;
text-decoration:none;font-size:19px;" href="javascript:void(0);" id="upp" onclick="gg()">
    <span style="font-size:10px;color:black;margin-right:4px;box-shadow: 0px 3px 3px 0px gray;padding: 8px;border-radius: 40px;background: rgb(190,80,80);color: white;" id="dd">Top &uArr;</span></a>


<script>



       $('#upp').click(function(){
           
           
                   $('html,body').animate({scrollTop:0},600);

           
       })

  




</script>


<script>



    setInterval(function(){

          $('.main').fadeIn(1000);

 
        
    },1000);
   

var nnn;


nnn = 0;


    setInterval(function(){

if(nnn == 0){
            
           
          $('.container').fadeIn(2200);

          $('.imm').slideUp(500);
          $('.stories').fadeIn(500);
}
 
        
    },100);
   
    

    
    $('#remove').click(function(){
        

                    $('.container').fadeOut(1010);

    
    nnn = 1;    
    });
    
    
    
    $('#rem').click(function(){
        
            $('html').animate({opacity: '1'});
                    $('.container').animate({left:"0",top:"0"}, 'fast');

                    $('.container').slideUp(10);

    
    nnn = 1;    
    });
    
    

</script>



<script type="text/javascript">


var body = window;
 
 body.addEventListener('scroll', callMe);


   function callMe(){

       
if(document.documentElement.scrollTop > 400){
    
              $('#upp').fadeIn(1500);

}
  
if(document.documentElement.scrollTop < 400){
    
              $('#upp').fadeOut(1500);

}



   }


</script>


