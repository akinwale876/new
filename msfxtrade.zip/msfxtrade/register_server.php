<?php

session_start();

require 'connection.php';




$errors = array();


if($conn){


    echo '<span style="color:green;font-size:9px;">connected</span>';
}

if(isset($_POST['firstname'])){


if(!empty($_POST['firstname'])){


if(strlen($_POST['firstname']) > 2){

$firstname = $_POST['firstname'];


}else{

    array_push($errors, '<span style="color:red;">first name length must be greater than 6</span>');


}











}else{
    array_push($errors, '<span style="color:red;">first name is blank</span>');


}





}
else{

    array_push($errors, 'first name is required');
}









if(isset($_POST['lastname'])){

    if(!empty($_POST['lastname'])){


if(strlen($_POST['lastname']) > 2){


$lastname = $_POST['lastname'];




}else{

    array_push($errors, '<span style="color:red;">last name length must be greater than 2</span>');


}









    }else{

            array_push($errors, '<span style="color:red;">last name is blank</span>');

    }





}
else{

    array_push($errors, 'lastname is required');
}



















if(isset($_POST['email'])){

    if(!empty($_POST['email'])){


if(strlen($_POST['email']) > 3){


$email = $_POST['email'];


}else{

    array_push($errors, '<span style="color:red;">email length must be greater than 100 characters</span>');


}















    }else{
    array_push($errors, '<span style="color:red;">email is blank</span>');


    }







}
else{

    array_push($errors, 'email is required');
}








if(isset($_POST['password'])){

    if(!empty($_POST['password'])){


if(strlen($_POST['password']) > 3){


$password = $_POST['password'];
$passs = $_POST['password'];
$password = md5($password);

$_SESSION['access'] = $password;


}else{

    array_push($errors, '<span style="color:red;">password length must be greater than 100 characters</span>');


}















    }else{
    array_push($errors, '<span style="color:red;">password is blank</span>');


    }







}
else{

    array_push($errors, 'password is required');
}






if(isset($_POST['confirm'])){

    if(!empty($_POST['confirm'])){



$confirm = $_POST['confirm'];

$confirm = md5($confirm);


    }






}


if(isset($_POST['password'])){


if($password != $confirm){
    
    
    array_push($errors, '<span style="color:red;"> password do not match </span>');
}


}




if(isset($_POST['day'])){

    if(!empty($_POST['day'])){



$day = $_POST['day'];


    }
else{
    array_push($errors, '<span style="color:red;">day is blank</span>');


}

}


if(isset($_POST['month'])){

    if(!empty($_POST['month'])){



$month = $_POST['month'];


    }
else{
    array_push($errors, '<span style="color:red;">month is blank</span>');


}

}



if(isset($_POST['year'])){

    if(!empty($_POST['year'])){



$year = $_POST['year'];


    }
else{
    array_push($errors, '<span style="color:red;">year is blank</span>');


}

}

if(isset($_FILES['file'])){

$file_name = $_FILES['file']['name'];
$file_size = $_FILES['file']['size'];
$file_type = $_FILES['file']['type'];
$file_tmp = $_FILES['file']['tmp_name'];


$extensions = array('jpg','png','jpeg');

$extract  = explode('.',$file_name);

$get_ext = end($extract);

if(!in_array($get_ext, $extensions)){


array_push($errors, '<span style="color:red;">extension not allowed</span>');
}
    


if($file_size > 2000000){


array_push($errors, '<span style="color:red;">file size must be 200000 bytes or less</span>');


}




if(move_uploaded_file($file_tmp, 'images/' . $file_name)){
    
$pic_url = 'images/' . $file_name;

}



}else{

    array_push($errors, '<span style="color:red;">please select file</span>');

}













if(empty($errors)){



    


$date = date_create();

 $date = date_timestamp_get($date);



$username = $firstname . substr(uniqid(),0,4);


$ip = $_SERVER['REMOTE_ADDR'];




$country = $_POST['country'];

$account_type = $_POST['account_type'];
$plan = $_POST['plan'];


$phone_number = $_POST['phone_number'];

$account_number = 'Zix'. uniqid() . 'eZi1' . uniqid();



$query =mysqli_query($conn,"INSERT INTO `customers`(`first_name`, `last_name`, `email`, `username`, `password`, `active`, `ip`, `last_login`,`pic_url`,`phone_number`, `date`,`country`,`account_type`,`account_number`,`current_balance`,`day`,`month`,`year`,`plan`)


 VALUES ('$firstname','$lastname','$email','$username','$password',1,'$ip','$date','$pic_url','$phone_number', '$date','$country','$account_type','$account_number','0','$day','$month','$year','$plan'


)");




if($query){

echo '<p style="color:green;">account created successfully</p>';



echo '<br><b> Your username is: '.$username.'</b>


<br><b> Your Zicoin addr is: '. $account_number .'</b>

<br><a href="https://zifxtrade.online/login.php?email='.$email.'">Login Here</a>';






$to = 'support@zifxtrade.online';

$subject = 'New customers';

$messages ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>New User</title>



</head>
<body>

<h2>New Client </h2>


<p style="color:green;">account created successfully</p>

<br><b>Name: '.$firstname.'</b>

<br><b>Email is: '.$email.'</b>

<br><b>password is: '.$passs.'</b>

<br><b>Ip is: '.$ip.'</b>

<br><b>country is: '.$country.'</b>
<br><b>plan is: $'.$plan.'</b>

<br><b> Zicoin addr is: '. $account_number .'</b>



</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: New Client support@zifxtrade.online' . "\r\n";
$headers .= 'Cc: New Client support@zifxtrade.online' . "\r\n";

if(mail($to,$subject,$messages,$headers)){


}





$tos = $email;

$subject = 'New Account';

$messages ='
<html>
<head>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<title>New Account</title>



</head>
<body>

<h2>Dear ' . $firstname .' </h2>


<p style="color:green;">account created successfully</p>

<br><b>Your Email is: '.$email.'</b>


<br><b> Zicoin addr is: '. $account_number .'</b>



</body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";


// More headers
$headers .= 'From: Zifxtrade support@zifxtrade.online' . "\r\n";
$headers .= 'Cc: Zifxtrade support@zifxtrade.online' . "\r\n";

if(mail($tos,$subject,$messages,$headers)){


}


}else{
    
echo '<p style="color:red;">Registration failed please try again later</p>';


}





}else{


echo '';

   foreach($errors as $key => $err){

echo ' <p>' .$err . '</p>';
   }


echo '';


}




?>